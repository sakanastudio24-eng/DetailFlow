import { motion } from 'motion/react';

export function PrivacyPolicy() {
  return (
    <div className="min-h-screen pt-20 pb-20 md:pb-8 bg-[#f8f8f8]">
      {/* Header */}
      <section className="bg-gradient-to-br from-[#10150f] to-[#10150f]/90 py-12 md:py-16 px-6 sm:px-8 lg:px-12 relative overflow-hidden">
        <div className="absolute inset-0 opacity-5">
          <div className="absolute inset-0" style={{
            backgroundImage: 'radial-gradient(circle at 2px 2px, white 1px, transparent 0)',
            backgroundSize: '40px 40px'
          }} />
        </div>
        <div className="max-w-4xl mx-auto text-center relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <h1 className="text-3xl sm:text-4xl md:text-5xl text-white mb-4">
              Privacy Policy
            </h1>
            <p className="text-base sm:text-lg text-gray-300 max-w-2xl mx-auto">
              Last Updated: October 25, 2025
            </p>
          </motion.div>
        </div>
      </section>

      {/* Content */}
      <section className="py-8 md:py-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="bg-white rounded-2xl shadow-xl p-6 sm:p-8 md:p-12 space-y-8"
          >
            {/* Introduction */}
            <div>
              <h2 className="text-2xl text-[#10150f] mb-4">1. Introduction</h2>
              <p className="text-gray-700 leading-relaxed">
                Cruzn Clean ("we," "our," or "us") is committed to protecting your privacy. This Privacy Policy explains how we collect, use, disclose, and safeguard your information when you use our services or visit our website. Please read this policy carefully to understand our practices regarding your personal data.
              </p>
            </div>

            {/* Information We Collect */}
            <div>
              <h2 className="text-2xl text-[#10150f] mb-4">2. Information We Collect</h2>
              
              <h3 className="text-xl text-[#10150f] mb-3 mt-4">Personal Information</h3>
              <p className="text-gray-700 leading-relaxed mb-3">
                We may collect the following personal information when you book our services or interact with our website:
              </p>
              <ul className="list-disc list-inside space-y-2 text-gray-700 ml-4 mb-4">
                <li>Name and contact information (email address, phone number, mailing address)</li>
                <li>Vehicle information (make, model, year, color, license plate)</li>
                <li>Payment information (credit card details, billing address)</li>
                <li>Appointment history and service preferences</li>
                <li>Communications with our customer service team</li>
              </ul>

              <h3 className="text-xl text-[#10150f] mb-3 mt-4">Automatically Collected Information</h3>
              <p className="text-gray-700 leading-relaxed mb-3">
                When you visit our website, we may automatically collect:
              </p>
              <ul className="list-disc list-inside space-y-2 text-gray-700 ml-4">
                <li>IP address and browser type</li>
                <li>Device information and operating system</li>
                <li>Pages visited and time spent on our site</li>
                <li>Referring website addresses</li>
                <li>Cookies and similar tracking technologies</li>
              </ul>
            </div>

            {/* How We Use Your Information */}
            <div>
              <h2 className="text-2xl text-[#10150f] mb-4">3. How We Use Your Information</h2>
              <p className="text-gray-700 leading-relaxed mb-3">
                We use the information we collect to:
              </p>
              <ul className="list-disc list-inside space-y-2 text-gray-700 ml-4">
                <li>Provide and manage our detailing services</li>
                <li>Process your bookings and payments</li>
                <li>Send appointment confirmations and reminders</li>
                <li>Communicate with you about your service requests</li>
                <li>Improve our services and customer experience</li>
                <li>Send promotional offers and marketing communications (with your consent)</li>
                <li>Comply with legal obligations and resolve disputes</li>
                <li>Prevent fraud and enhance security</li>
              </ul>
            </div>

            {/* Information Sharing */}
            <div>
              <h2 className="text-2xl text-[#10150f] mb-4">4. How We Share Your Information</h2>
              <p className="text-gray-700 leading-relaxed mb-3">
                We may share your information with:
              </p>
              <ul className="list-disc list-inside space-y-2 text-gray-700 ml-4 mb-4">
                <li><strong>Service Providers:</strong> Third-party companies that help us operate our business (payment processors, scheduling software, email services)</li>
                <li><strong>Legal Requirements:</strong> When required by law, court order, or government authority</li>
                <li><strong>Business Transfers:</strong> In connection with a merger, acquisition, or sale of assets</li>
                <li><strong>With Your Consent:</strong> When you explicitly authorize us to share your information</li>
              </ul>
              <p className="text-gray-700 leading-relaxed">
                We do not sell your personal information to third parties for their marketing purposes.
              </p>
            </div>

            {/* Cookies and Tracking */}
            <div>
              <h2 className="text-2xl text-[#10150f] mb-4">5. Cookies and Tracking Technologies</h2>
              <p className="text-gray-700 leading-relaxed mb-3">
                We use cookies and similar technologies to enhance your browsing experience, analyze site traffic, and personalize content. You can control cookies through your browser settings, though disabling cookies may affect your ability to use certain features of our website.
              </p>
              <p className="text-gray-700 leading-relaxed">
                We may also use analytics services like Google Analytics to understand how visitors interact with our site.
              </p>
            </div>

            {/* Data Security */}
            <div>
              <h2 className="text-2xl text-[#10150f] mb-4">6. Data Security</h2>
              <p className="text-gray-700 leading-relaxed mb-3">
                We implement appropriate technical and organizational security measures to protect your personal information from unauthorized access, disclosure, alteration, or destruction. These measures include:
              </p>
              <ul className="list-disc list-inside space-y-2 text-gray-700 ml-4 mb-4">
                <li>Encryption of sensitive data during transmission</li>
                <li>Secure storage of customer information</li>
                <li>Regular security assessments and updates</li>
                <li>Limited access to personal data by authorized personnel only</li>
              </ul>
              <p className="text-gray-700 leading-relaxed">
                However, no method of transmission over the internet or electronic storage is 100% secure. While we strive to protect your information, we cannot guarantee absolute security.
              </p>
            </div>

            {/* Data Retention */}
            <div>
              <h2 className="text-2xl text-[#10150f] mb-4">7. Data Retention</h2>
              <p className="text-gray-700 leading-relaxed">
                We retain your personal information for as long as necessary to fulfill the purposes outlined in this Privacy Policy, unless a longer retention period is required or permitted by law. When we no longer need your information, we will securely delete or anonymize it.
              </p>
            </div>

            {/* Your Privacy Rights */}
            <div>
              <h2 className="text-2xl text-[#10150f] mb-4">8. Your Privacy Rights</h2>
              <p className="text-gray-700 leading-relaxed mb-3">
                Depending on your location, you may have the following rights:
              </p>
              <ul className="list-disc list-inside space-y-2 text-gray-700 ml-4 mb-4">
                <li><strong>Access:</strong> Request a copy of the personal information we hold about you</li>
                <li><strong>Correction:</strong> Request correction of inaccurate or incomplete information</li>
                <li><strong>Deletion:</strong> Request deletion of your personal information</li>
                <li><strong>Opt-Out:</strong> Unsubscribe from marketing communications</li>
                <li><strong>Data Portability:</strong> Request transfer of your data to another service</li>
                <li><strong>Objection:</strong> Object to certain types of data processing</li>
              </ul>
              <p className="text-gray-700 leading-relaxed">
                To exercise these rights, please contact us using the information provided at the end of this policy.
              </p>
            </div>

            {/* Third-Party Links */}
            <div>
              <h2 className="text-2xl text-[#10150f] mb-4">9. Third-Party Links</h2>
              <p className="text-gray-700 leading-relaxed">
                Our website may contain links to third-party websites. We are not responsible for the privacy practices of these external sites. We encourage you to read their privacy policies before providing any personal information.
              </p>
            </div>

            {/* Children's Privacy */}
            <div>
              <h2 className="text-2xl text-[#10150f] mb-4">10. Children's Privacy</h2>
              <p className="text-gray-700 leading-relaxed">
                Our services are not directed to individuals under the age of 18. We do not knowingly collect personal information from children. If we become aware that we have collected information from a child, we will take steps to delete it promptly.
              </p>
            </div>

            {/* Changes to This Policy */}
            <div>
              <h2 className="text-2xl text-[#10150f] mb-4">11. Changes to This Privacy Policy</h2>
              <p className="text-gray-700 leading-relaxed">
                We may update this Privacy Policy from time to time to reflect changes in our practices or legal requirements. We will notify you of any material changes by posting the updated policy on our website with a new "Last Updated" date. Your continued use of our services after changes are posted constitutes acceptance of the updated policy.
              </p>
            </div>

            {/* Payment Information */}
            <div className="bg-[#8cc0d6]/10 border-l-4 border-[#8cc0d6] p-6 rounded-r-lg">
              <h2 className="text-2xl text-[#10150f] mb-3">Payment Processing</h2>
              <p className="text-gray-700 leading-relaxed">
                Payment will be accepted on site after work has been completed. We use secure payment processing systems to protect your financial information during transactions.
              </p>
            </div>

            {/* Contact */}
            <div className="pt-6 border-t border-gray-200">
              <h2 className="text-2xl text-[#10150f] mb-4">Contact Us</h2>
              <p className="text-gray-700 leading-relaxed mb-2">
                If you have any questions about this Privacy Policy or wish to exercise your privacy rights, please contact us:
              </p>
              <ul className="space-y-2 text-gray-700">
                <li><strong>Email:</strong> privacy@cruznclean.com</li>
                <li><strong>Phone:</strong> +1 (555) 123-4567</li>
                <li><strong>Address:</strong> 123 Detail Street, Auto City, AC 12345</li>
              </ul>
            </div>
          </motion.div>
        </div>
      </section>
    </div>
  );
}
