import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Sparkles, Droplet, Shield, Check, ArrowRight, ArrowLeft, Zap, Star, Wind, Calendar, User, Mail, Phone, MapPin, Palette, Clock, HelpCircle, ExternalLink, Car } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { Textarea } from '../components/ui/textarea';
import { Button } from '../components/ui/button';
import { Checkbox } from '../components/ui/checkbox';
import { useCart } from '../context/CartContext';
import { Progress } from '../components/ui/progress';
import { RippleButton } from '../components/ui/ripple-button';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from '../components/ui/accordion';

const packages = [
  {
    id: 'basic',
    name: 'Basic Detail',
    icon: Sparkles,
    duration: '2-3 hrs',
    description: 'Essential maintenance for everyday shine.',
    basePrice: 99,
    color: '#8cc0d6'
  },
  {
    id: 'standard',
    name: 'Standard Detail',
    icon: Droplet,
    duration: '4 hrs',
    description: 'Full-service refresh inside & out.',
    basePrice: 189,
    color: '#56070f'
  },
  {
    id: 'premium',
    name: 'Premium Detail',
    icon: Shield,
    duration: '6 hrs',
    description: 'Ultimate protection & showroom finish.',
    basePrice: 349,
    color: '#1a3a52'
  }
];

const vehicleSizes = [
  { id: 'small', label: 'Small', examples: 'Sedan / Coupe', multiplier: 1 },
  { id: 'medium', label: 'Medium', examples: 'SUV / Crossover', multiplier: 1.2 },
  { id: 'large', label: 'Large', examples: 'Truck / Van', multiplier: 1.4 }
];

const additionalServices = [
  {
    id: 'ceramic',
    name: 'Ceramic Coating',
    icon: Shield,
    price: 500,
    description: 'Hydrophobic protection lasting 6+ months.',
    color: '#8cc0d6'
  },
  {
    id: 'headlight',
    name: 'Headlight Restoration',
    icon: Zap,
    price: 75,
    description: 'Improved visibility and safety.',
    color: '#56070f'
  },
  {
    id: 'airfresh',
    name: 'Air Freshening Treatment',
    icon: Wind,
    price: 125,
    description: 'Removes odors using ozone treatment.',
    color: '#8cc0d6'
  },
  {
    id: 'engine',
    name: 'Engine Bay Detail',
    icon: Star,
    price: 100,
    description: 'Deep clean and dressing.',
    color: '#56070f'
  }
];

const steps = [
  { number: 1, title: 'Your Details', icon: User },
  { number: 2, title: 'Enhancements', icon: Star },
  { number: 3, title: 'Schedule', icon: Calendar }
];

export function Booking() {
  const { vehicles, activeVehicleId, getTotalPrice } = useCart();
  const [currentStep, setCurrentStep] = useState(1);
  const [selectedPackage, setSelectedPackage] = useState<string>('standard');
  const [selectedSize, setSelectedSize] = useState<string>('small');
  const [selectedAddons, setSelectedAddons] = useState<string[]>([]);
  const [agreedToTerms, setAgreedToTerms] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    vehicleMake: '',
    vehicleModel: '',
    vehicleYear: '',
    vehicleColor: '',
    zipCode: '',
    notes: ''
  });

  // Load Setmore script
  useEffect(() => {
    const script = document.createElement('script');
    script.id = 'setmore_script';
    script.type = 'text/javascript';
    script.src = 'https://assets.setmore.com/integration/static/setmoreIframeLive.js';
    script.async = true;
    document.body.appendChild(script);

    return () => {
      const existingScript = document.getElementById('setmore_script');
      if (existingScript) {
        document.body.removeChild(existingScript);
      }
    };
  }, []);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData(prev => ({
      ...prev,
      [e.target.name]: e.target.value
    }));
  };

  const toggleAddon = (addonId: string) => {
    setSelectedAddons(prev => 
      prev.includes(addonId) 
        ? prev.filter(id => id !== addonId)
        : [...prev, addonId]
    );
  };

  const isStep1Valid = !!(
    formData.name.trim() && 
    formData.email.trim() && 
    formData.phone.trim() && 
    formData.vehicleMake.trim() && 
    formData.vehicleModel.trim() && 
    formData.vehicleYear.trim() && 
    formData.zipCode.trim().length >= 5 &&
    agreedToTerms
  );

  const handleNextStep = () => {
    if (currentStep === 1 && isStep1Valid) {
      setCurrentStep(2);
    } else if (currentStep === 2) {
      setCurrentStep(3);
    }
  };

  const handlePrevStep = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1);
    }
  };

  const selectedPackageData = packages.find(p => p.id === selectedPackage);
  const selectedSizeData = vehicleSizes.find(s => s.id === selectedSize);
  
  const calculatePrice = () => {
    const basePrice = selectedPackageData?.basePrice || 0;
    const sizeMultiplier = selectedSizeData?.multiplier || 1;
    const packageTotal = Math.round(basePrice * sizeMultiplier);
    const addonsTotal = selectedAddons.reduce((sum, addonId) => {
      const addon = additionalServices.find(s => s.id === addonId);
      return sum + (addon?.price || 0);
    }, 0);
    return packageTotal + addonsTotal;
  };

  const progress = (currentStep / steps.length) * 100;

  return (
    <>
      <div className="min-h-screen pt-20 pb-32 md:pb-8 bg-gradient-to-b from-white via-[#f8f8f8] to-white">
        {/* Header with Glass Panel */}
        <section className="bg-[#10150f] py-12 md:py-16 px-6 sm:px-8 lg:px-12 relative overflow-hidden">
          <div className="absolute inset-0 opacity-5">
            <div className="absolute inset-0" style={{
              backgroundImage: 'radial-gradient(circle at 2px 2px, white 1px, transparent 0)',
              backgroundSize: '40px 40px'
            }} />
          </div>
          <div className="max-w-5xl mx-auto relative z-10 backdrop-blur-[8px] bg-white/[0.06] rounded-3xl p-8 md:p-12 border border-white/10">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="text-center mb-8"
            >
              <h1 className="text-3xl sm:text-4xl md:text-5xl text-white mb-4">
                Book Your Appointment
              </h1>
              <p className="text-base sm:text-lg text-gray-300 max-w-2xl mx-auto mb-6">
                Three simple steps to a pristine vehicle.
              </p>
            </motion.div>

            {/* Progress Steps */}
            <div className="max-w-3xl mx-auto mt-6">
              <div className="mb-4">
                <Progress value={progress} className="h-2 [&>div]:bg-[#56070f]" />
              </div>
              <div className="grid grid-cols-3 gap-4">
                {steps.map((step) => {
                  const Icon = step.icon;
                  const isActive = currentStep === step.number;
                  const isCompleted = currentStep > step.number;

                  return (
                    <div
                      key={step.number}
                      className={`flex flex-col items-center gap-2 transition-all ${
                        isActive ? 'scale-105' : 'opacity-60'
                      }`}
                    >
                      <div
                        className={`w-12 h-12 rounded-full flex items-center justify-center transition-all ${
                          isCompleted
                            ? 'bg-green-500'
                            : isActive
                            ? 'bg-[#8cc0d6] shadow-lg'
                            : 'bg-white/20'
                        }`}
                      >
                        {isCompleted ? (
                          <Check className="w-6 h-6 text-white" />
                        ) : (
                          <Icon className={`w-6 h-6 ${isActive ? 'text-white' : 'text-white/60'}`} />
                        )}
                      </div>
                      <div className="text-center">
                        <p className={`text-xs sm:text-sm ${isActive ? 'text-white' : 'text-white/60'}`}>
                          {step.title}
                        </p>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        </section>

        {/* Main Content */}
        <section className="py-8 md:py-12 px-4 sm:px-6 lg:px-8">
          <div className="max-w-6xl mx-auto">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              {/* Main Form Area */}
              <div className="lg:col-span-2">
                <AnimatePresence mode="wait">
                  {/* Step 1: Your Details */}
                  {currentStep === 1 && (
                    <motion.div
                      key="step1"
                      initial={{ opacity: 0, x: 20 }}
                      animate={{ opacity: 1, x: 0 }}
                      exit={{ opacity: 0, x: -20 }}
                      transition={{ duration: 0.3 }}
                    >
                      <Card>
                        <CardHeader>
                          <CardTitle className="flex items-center gap-2 text-[#10150f]">
                            <User className="w-5 h-5 text-[#8cc0d6]" />
                            Your Details
                          </CardTitle>
                        </CardHeader>
                        <CardContent className="space-y-6">
                          {/* Package Selection */}
                          <div>
                            <Label className="mb-3 block">Select Package</Label>
                            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                              {packages.map((pkg) => {
                                const Icon = pkg.icon;
                                const isSelected = selectedPackage === pkg.id;

                                return (
                                  <button
                                    key={pkg.id}
                                    onClick={() => setSelectedPackage(pkg.id)}
                                    className={`p-4 rounded-lg border-2 transition-all text-left ${
                                      isSelected && pkg.id === 'premium'
                                        ? 'border-[#1a3a52] bg-gradient-to-br from-[#1a3a52] to-[#0f2540] shadow-md'
                                        : isSelected
                                        ? 'border-[#56070f] bg-[#56070f]/5 shadow-md'
                                        : 'border-gray-200 hover:border-[#8cc0d6]'
                                    }`}
                                  >
                                    <div className="flex items-center gap-2 mb-2">
                                      <div
                                        className={`w-8 h-8 rounded-full flex items-center justify-center ${pkg.id === 'premium' && isSelected ? 'bg-[#8cc0d6]' : ''}`}
                                        style={!(pkg.id === 'premium' && isSelected) ? { backgroundColor: pkg.color } : {}}
                                      >
                                        <Icon className={`w-4 h-4 ${pkg.id === 'premium' && isSelected ? 'text-[#10150f]' : 'text-white'}`} />
                                      </div>
                                      <div className="flex-1 min-w-0">
                                        <h4 className={`text-sm truncate ${pkg.id === 'premium' && isSelected ? 'text-white' : ''}`}>{pkg.name}</h4>
                                      </div>
                                    </div>
                                    <p className={`text-xs ${pkg.id === 'premium' && isSelected ? 'text-gray-300' : 'text-gray-600'}`}>{pkg.description}</p>
                                  </button>
                                );
                              })}
                            </div>

                            {/* Not Sure Help */}
                            <div className="mt-4 p-4 bg-[#8cc0d6]/10 border border-[#8cc0d6]/30 rounded-lg">
                              <div className="flex items-start gap-3">
                                <HelpCircle className="w-5 h-5 text-[#8cc0d6] flex-shrink-0 mt-0.5" />
                                <div className="flex-1">
                                  <p className="text-sm text-gray-700 mb-2">
                                    <strong>Not sure which package?</strong> Check out our{' '}
                                    <a 
                                      href="#/faq" 
                                      className="text-[#56070f] hover:text-[#8cc0d6] underline inline-flex items-center gap-1"
                                    >
                                      FAQ page
                                      <ExternalLink className="w-3 h-3" />
                                    </a>
                                    {' '}for detailed package comparisons.
                                  </p>
                                </div>
                              </div>
                            </div>
                          </div>

                          {/* Vehicle Size */}
                          <div>
                            <Label className="mb-3 block">Vehicle Size</Label>
                            <div className="grid grid-cols-1 [@media(min-width:769px)]:grid-cols-3 gap-3">
                              {vehicleSizes.map((size, index) => {
                                const isSelected = selectedSize === size.id;

                                return (
                                  <button
                                    key={size.id}
                                    onClick={() => setSelectedSize(size.id)}
                                    className={`p-3 rounded-lg border-2 transition-all ${
                                      isSelected
                                        ? 'border-[#56070f] bg-[#56070f]/5'
                                        : 'border-gray-200 hover:border-[#8cc0d6]'
                                    } ${
                                      index === 2 ? '[@media(min-width:769px)and(max-width:1163px)]:col-span-3' : ''
                                    }`}
                                  >
                                    <div className="text-center">
                                      <p className="text-sm mb-1">{size.label}</p>
                                      <p className="text-xs text-gray-500">{size.examples}</p>
                                    </div>
                                  </button>
                                );
                              })}
                            </div>

                            {/* Vehicle Size Guide */}
                            <Accordion type="single" collapsible className="mt-4">
                              <AccordionItem value="size-guide" className="border rounded-lg px-4 bg-white">
                                <AccordionTrigger className="text-sm hover:no-underline">
                                  <div className="flex items-center gap-2">
                                    <Car className="w-4 h-4 text-[#8cc0d6]" />
                                    <span>Vehicle Size Guide - Find Your Vehicle</span>
                                  </div>
                                </AccordionTrigger>
                                <AccordionContent>
                                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-2">
                                    {/* Small Vehicles */}
                                    <div>
                                      <p className="text-xs text-[#56070f] mb-2">Small Vehicles</p>
                                      <ul className="text-xs text-gray-600 space-y-1">
                                        <li>• Honda Civic</li>
                                        <li>• Toyota Corolla</li>
                                        <li>• Mazda3</li>
                                        <li>• BMW 3 Series</li>
                                        <li>• Audi A4</li>
                                        <li>• Ford Focus</li>
                                        <li>• Volkswagen Jetta</li>
                                      </ul>
                                    </div>

                                    {/* Medium Vehicles */}
                                    <div>
                                      <p className="text-xs text-[#56070f] mb-2">Medium Vehicles</p>
                                      <ul className="text-xs text-gray-600 space-y-1">
                                        <li>• Honda CR-V</li>
                                        <li>• Toyota RAV4</li>
                                        <li>• Mazda CX-5</li>
                                        <li>• Jeep Grand Cherokee</li>
                                        <li>• Tesla Model Y</li>
                                        <li>• Ford Explorer</li>
                                        <li>• Nissan Rogue</li>
                                      </ul>
                                    </div>

                                    {/* Large Vehicles */}
                                    <div>
                                      <p className="text-xs text-[#56070f] mb-2">Large Vehicles</p>
                                      <ul className="text-xs text-gray-600 space-y-1">
                                        <li>• Ford F-150</li>
                                        <li>• Chevy Silverado</li>
                                        <li>• Ram 1500</li>
                                        <li>• GMC Yukon</li>
                                        <li>• Chevy Suburban</li>
                                        <li>• Toyota Tundra</li>
                                        <li>• Ford Expedition</li>
                                      </ul>
                                    </div>
                                  </div>

                                  {/* Still Not Sure */}
                                  <div className="mt-4 pt-4 border-t">
                                    <div className="flex flex-col sm:flex-row items-center justify-between gap-3 bg-[#f8f8f8] rounded-lg p-3">
                                      <p className="text-xs text-gray-600 text-center sm:text-left">
                                        <strong>Still not sure?</strong> We're here to help!
                                      </p>
                                      <a
                                        href="tel:+1234567890"
                                        className="inline-flex items-center gap-2 text-xs bg-[#56070f] text-white px-4 py-2 rounded-lg hover:bg-[#6e0912] transition-colors whitespace-nowrap"
                                      >
                                        <Phone className="w-3 h-3" />
                                        Give Us a Call
                                      </a>
                                    </div>
                                  </div>
                                </AccordionContent>
                              </AccordionItem>
                            </Accordion>
                          </div>

                          {/* Personal Info */}
                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                            <div>
                              <Label htmlFor="name">Full Name *</Label>
                              <div className="relative">
                                <User className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                                <Input
                                  id="name"
                                  name="name"
                                  value={formData.name}
                                  onChange={handleChange}
                                  placeholder="John Doe"
                                  className="pl-10"
                                />
                              </div>
                            </div>
                            <div>
                              <Label htmlFor="email">Email *</Label>
                              <div className="relative">
                                <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                                <Input
                                  id="email"
                                  name="email"
                                  type="email"
                                  value={formData.email}
                                  onChange={handleChange}
                                  placeholder="john@example.com"
                                  className="pl-10"
                                />
                              </div>
                            </div>
                          </div>

                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                            <div>
                              <Label htmlFor="phone">Phone *</Label>
                              <div className="relative">
                                <Phone className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                                <Input
                                  id="phone"
                                  name="phone"
                                  type="tel"
                                  value={formData.phone}
                                  onChange={handleChange}
                                  placeholder="(555) 123-4567"
                                  className="pl-10"
                                />
                              </div>
                            </div>
                            <div>
                              <Label htmlFor="zipCode">ZIP Code *</Label>
                              <div className="relative">
                                <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                                <Input
                                  id="zipCode"
                                  name="zipCode"
                                  value={formData.zipCode}
                                  onChange={handleChange}
                                  placeholder="12345"
                                  className="pl-10"
                                  maxLength={5}
                                />
                              </div>
                            </div>
                          </div>

                          {/* Vehicle Info */}
                          <div className="border-t pt-6">
                            <h4 className="text-sm mb-4 text-gray-700">Vehicle Information</h4>
                            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                              <div>
                                <Label htmlFor="vehicleMake">Make *</Label>
                                <Input
                                  id="vehicleMake"
                                  name="vehicleMake"
                                  value={formData.vehicleMake}
                                  onChange={handleChange}
                                  placeholder="Toyota"
                                />
                              </div>
                              <div>
                                <Label htmlFor="vehicleModel">Model *</Label>
                                <Input
                                  id="vehicleModel"
                                  name="vehicleModel"
                                  value={formData.vehicleModel}
                                  onChange={handleChange}
                                  placeholder="Camry"
                                />
                              </div>
                              <div>
                                <Label htmlFor="vehicleYear">Year *</Label>
                                <Input
                                  id="vehicleYear"
                                  name="vehicleYear"
                                  value={formData.vehicleYear}
                                  onChange={handleChange}
                                  placeholder="2020"
                                  maxLength={4}
                                />
                              </div>
                            </div>
                            <div className="mt-4">
                              <Label htmlFor="vehicleColor">Color (optional)</Label>
                              <div className="relative">
                                <Palette className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                                <Input
                                  id="vehicleColor"
                                  name="vehicleColor"
                                  value={formData.vehicleColor}
                                  onChange={handleChange}
                                  placeholder="Silver"
                                  className="pl-10"
                                />
                              </div>
                            </div>
                          </div>

                          {/* Terms */}
                          <div className="flex items-start gap-2">
                            <Checkbox
                              id="terms"
                              checked={agreedToTerms}
                              onCheckedChange={(checked) => setAgreedToTerms(checked === true)}
                            />
                            <label htmlFor="terms" className="text-xs text-gray-600 leading-tight cursor-pointer">
                              I agree to the terms of service and privacy policy. I understand pricing may vary based on vehicle condition.
                            </label>
                          </div>

                          {/* Navigation */}
                          <div className="flex justify-end pt-4">
                            <RippleButton
                              onClick={handleNextStep}
                              disabled={!isStep1Valid}
                              className="bg-[#56070f] hover:bg-[#6e0912] px-8"
                            >
                              Continue to Enhancements
                              <ArrowRight className="w-4 h-4 ml-2" />
                            </RippleButton>
                          </div>
                        </CardContent>
                      </Card>
                    </motion.div>
                  )}

                  {/* Step 2: Enhancements */}
                  {currentStep === 2 && (
                    <motion.div
                      key="step2"
                      initial={{ opacity: 0, x: 20 }}
                      animate={{ opacity: 1, x: 0 }}
                      exit={{ opacity: 0, x: -20 }}
                      transition={{ duration: 0.3 }}
                    >
                      <Card>
                        <CardHeader>
                          <CardTitle className="flex items-center gap-2 text-[#10150f]">
                            <Star className="w-5 h-5 text-[#8cc0d6]" />
                            Add Enhancements
                          </CardTitle>
                          <p className="text-sm text-gray-600">Optional services to maximize your detail (tap to add)</p>
                        </CardHeader>
                        <CardContent className="space-y-4">
                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                            {additionalServices.map((service) => {
                              const Icon = service.icon;
                              const isSelected = selectedAddons.includes(service.id);

                              return (
                                <button
                                  key={service.id}
                                  onClick={() => toggleAddon(service.id)}
                                  className={`p-4 rounded-lg border-2 transition-all text-left relative ${
                                    isSelected
                                      ? 'border-[#8cc0d6] bg-[#8cc0d6]/10 shadow-md'
                                      : 'border-gray-200 hover:border-[#8cc0d6]/50'
                                  }`}
                                >
                                  {isSelected && (
                                    <div className="absolute top-2 right-2 w-6 h-6 bg-green-500 rounded-full flex items-center justify-center">
                                      <Check className="w-4 h-4 text-white" />
                                    </div>
                                  )}
                                  <div className="flex items-start gap-3">
                                    <div
                                      className="w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0"
                                      style={{ backgroundColor: `${service.color}20` }}
                                    >
                                      <Icon className="w-5 h-5" style={{ color: service.color }} />
                                    </div>
                                    <div className="flex-1 min-w-0">
                                      <h4 className="text-sm mb-1">{service.name}</h4>
                                      <p className="text-xs text-gray-600 mb-2">{service.description}</p>
                                      <p className="text-lg" style={{ color: service.color }}>
                                        ${service.price}
                                      </p>
                                    </div>
                                  </div>
                                </button>
                              );
                            })}
                          </div>

                          {/* Notes */}
                          <div className="border-t pt-4">
                            <Label htmlFor="notes">Special Requests or Notes (optional)</Label>
                            <Textarea
                              id="notes"
                              name="notes"
                              value={formData.notes}
                              onChange={handleChange}
                              placeholder="Any specific concerns or requests? (pet hair, stains, etc.)"
                              rows={3}
                              className="mt-2"
                            />
                          </div>

                          {/* Navigation */}
                          <div className="flex justify-between pt-4">
                            <RippleButton
                              onClick={handlePrevStep}
                              variant="outline"
                              className="border-[#8cc0d6] text-[#8cc0d6] hover:bg-[#8cc0d6]/10"
                            >
                              <ArrowLeft className="w-4 h-4 mr-2" />
                              Back
                            </RippleButton>
                            <RippleButton
                              onClick={handleNextStep}
                              className="bg-[#56070f] hover:bg-[#6e0912] px-8"
                            >
                              Continue to Schedule
                              <ArrowRight className="w-4 h-4 ml-2" />
                            </RippleButton>
                          </div>
                        </CardContent>
                      </Card>
                    </motion.div>
                  )}

                  {/* Step 3: Schedule */}
                  {currentStep === 3 && (
                    <motion.div
                      key="step3"
                      initial={{ opacity: 0, x: 20 }}
                      animate={{ opacity: 1, x: 0 }}
                      exit={{ opacity: 0, x: -20 }}
                      transition={{ duration: 0.3 }}
                    >
                      <Card>
                        <CardHeader>
                          <CardTitle className="flex items-center gap-2 text-[#10150f]">
                            <Calendar className="w-5 h-5 text-[#8cc0d6]" />
                            Choose Your Date & Time
                          </CardTitle>
                          <p className="text-sm md:text-base leading-relaxed text-gray-600 mb-5">Select a convenient appointment slot</p>
                          
                          {/* Microcopy - 24px below intro */}
                          <div className="flex flex-wrap items-center justify-center gap-2 text-xs text-[#8cc0d6]">
                            <span>Instant confirmation</span>
                            <span>•</span>
                            <span>Email receipt</span>
                            <span>•</span>
                            <span>Reschedule anytime</span>
                          </div>
                        </CardHeader>
                        <CardContent className="space-y-6">
                          {/* 80px spacing above calendar block */}
                          <div className="mt-20">
                            {/* Calendar Placeholder - 960x720 with 12px corner radius and soft shadow */}
                            <div className="mx-auto max-w-[960px] aspect-[4/3] bg-gradient-to-br from-[#f8f8f8] to-white rounded-xl border-2 border-gray-200 shadow-lg overflow-hidden">
                              {/* Setmore Embedded Widget */}
                              <div id="setmore" className="setmore-iframe-wrapper h-full">
                                <a
                                  id="Setmore_button_iframe"
                                  style={{ display: 'none' }}
                                  href="https://booking.setmore.com/scheduleappointment/cruzn-clean"
                                >
                                  Book an appointment
                                </a>
                                <iframe
                                  src="https://booking.setmore.com/scheduleappointment/cruzn-clean?source=website"
                                  className="w-full h-full border-0"
                                  title="Setmore Booking"
                                />
                              </div>
                            </div>
                          </div>

                          <div className="bg-[#8cc0d6]/10 border border-[#8cc0d6]/30 rounded-lg p-4">
                            <div className="flex items-start gap-3">
                              <Clock className="w-5 h-5 text-[#8cc0d6] flex-shrink-0 mt-0.5" />
                              <div>
                                <h5 className="text-sm mb-1 text-[#10150f]">What to Expect</h5>
                                <p className="text-xs text-gray-600">
                                  You'll receive a confirmation email with appointment details. Our team will contact you 24 hours before your scheduled time.
                                </p>
                              </div>
                            </div>
                          </div>

                          {/* Navigation */}
                          <div className="flex justify-between pt-4">
                            <RippleButton
                              onClick={handlePrevStep}
                              variant="outline"
                              className="border-[#8cc0d6] text-[#8cc0d6] hover:bg-[#8cc0d6]/10"
                            >
                              <ArrowLeft className="w-4 h-4 mr-2" />
                              Back
                            </RippleButton>
                          </div>
                        </CardContent>
                      </Card>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>

              {/* Your Selection Summary - Desktop */}
              <div className="hidden lg:block">
                <div className="sticky top-24">
                  <Card className="border-2 border-[#8cc0d6]/30 shadow-lg">
                    <CardHeader className="bg-gradient-to-br from-[#10150f] to-[#1a1f1a] text-white">
                      <CardTitle className="flex items-center gap-2">
                        <Check className="w-5 h-5 text-[#8cc0d6]" />
                        Your Selection
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="p-6 space-y-4">
                      {/* Package */}
                      {selectedPackageData && (
                        <div>
                          <p className="text-xs text-gray-500 mb-1">Package</p>
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-2">
                              <div
                                className={`w-8 h-8 rounded-full flex items-center justify-center ${selectedPackageData.id === 'premium' ? 'bg-[#8cc0d6]' : ''}`}
                                style={selectedPackageData.id !== 'premium' ? { backgroundColor: selectedPackageData.color } : {}}
                              >
                                {selectedPackageData.icon && <selectedPackageData.icon className={`w-4 h-4 ${selectedPackageData.id === 'premium' ? 'text-[#10150f]' : 'text-white'}`} />}
                              </div>
                              <div>
                                <p className={`text-sm ${selectedPackageData.id === 'premium' ? 'text-[#1a3a52]' : ''}`}>{selectedPackageData.name}</p>
                                <p className="text-xs text-gray-500">{selectedSizeData?.label} Vehicle</p>
                              </div>
                            </div>
                            <p className={`text-sm ${selectedPackageData.id === 'premium' ? 'text-[#1a3a52]' : ''}`}>
                              ${Math.round((selectedPackageData.basePrice || 0) * (selectedSizeData?.multiplier || 1))}
                            </p>
                          </div>
                        </div>
                      )}

                      {/* Add-ons */}
                      {selectedAddons.length > 0 && (
                        <div className="border-t pt-4">
                          <p className="text-xs text-gray-500 mb-2">Add-ons</p>
                          <div className="space-y-2">
                            {selectedAddons.map(addonId => {
                              const addon = additionalServices.find(s => s.id === addonId);
                              if (!addon) return null;
                              
                              return (
                                <div key={addonId} className="flex items-center justify-between text-sm">
                                  <span className="text-gray-700">{addon.name}</span>
                                  <span className="text-gray-900">${addon.price}</span>
                                </div>
                              );
                            })}
                          </div>
                        </div>
                      )}

                      {/* Customer Info */}
                      {formData.name && (
                        <div className="border-t pt-4">
                          <p className="text-xs text-gray-500 mb-2">Customer</p>
                          <p className="text-sm text-gray-900">{formData.name}</p>
                          {formData.vehicleMake && formData.vehicleModel && (
                            <p className="text-xs text-gray-600">
                              {formData.vehicleYear} {formData.vehicleMake} {formData.vehicleModel}
                            </p>
                          )}
                        </div>
                      )}

                      {/* Total */}
                      <div className="border-t pt-4">
                        <div className="flex items-center justify-between mb-1">
                          <p className="text-sm text-gray-600">Subtotal</p>
                          <p className="text-lg text-[#56070f]">${calculatePrice()}</p>
                        </div>
                        <p className="text-xs text-gray-500">Final price confirmed on-site</p>
                      </div>

                      {/* Progress Indicator */}
                      <div className="bg-[#f8f8f8] rounded-lg p-3">
                        <div className="flex items-center justify-between mb-2">
                          <p className="text-xs text-gray-600">Booking Progress</p>
                          <p className="text-xs text-[#8cc0d6]">Step {currentStep} of 3</p>
                        </div>
                        <Progress value={progress} className="h-1.5" />
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </div>
            </div>
          </div>
        </section>
      </div>

      {/* Mobile Summary - Sticky Bottom */}
      <div className="lg:hidden fixed bottom-0 left-0 right-0 z-30 bg-white border-t border-gray-200 shadow-2xl">
        <div className="p-4">
          <div className="flex items-center justify-between mb-2">
            <div>
              <p className="text-xs text-gray-500">Your Selection</p>
              <p className="text-sm">
                {selectedPackageData?.name} • {selectedSizeData?.label}
              </p>
            </div>
            <div className="text-right">
              <p className="text-lg text-[#56070f]">${calculatePrice()}</p>
              <p className="text-xs text-gray-500">Step {currentStep}/3</p>
            </div>
          </div>
          <Progress value={progress} className="h-1.5" />
        </div>
      </div>
    </>
  );
}
