import { useState } from 'react';
import { motion } from 'motion/react';
import { HelpCircle, Droplet, Clock, Car, CloudRain, CreditCard, MapPin, Shield, Calendar, Users, Sparkles, Phone } from 'lucide-react';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from '../components/ui/accordion';
import { Card, CardContent } from '../components/ui/card';
import { Button } from '../components/ui/button';

interface FAQItem {
  question: string;
  answer: string;
  icon: any;
  category: string;
}

const faqs: FAQItem[] = [
  {
    category: 'Booking & Scheduling',
    question: 'How long does a detail take?',
    answer: 'Timing varies by package: Basic Detail takes 2-3 hours, Standard Detail takes about 4 hours, and Premium Detail takes 6+ hours. We recommend allowing extra time for larger vehicles or heavily soiled interiors. We\'ll provide a more accurate estimate when you book.',
    icon: Clock
  },
  {
    category: 'Booking & Scheduling',
    question: 'Can I book multiple cars at once?',
    answer: 'Absolutely! Our multi-vehicle booking system allows you to add multiple cars to your appointment. Each vehicle can have its own package and add-ons. You\'ll receive a combined quote and can schedule them for the same day or different days based on availability.',
    icon: Car
  },
  {
    category: 'Booking & Scheduling',
    question: 'How far in advance should I book?',
    answer: 'We recommend booking at least 3-5 days in advance, especially during peak seasons (spring and summer). However, we often have same-day or next-day availability. Check our online calendar or call us at (555) 123-4567 for the most current openings.',
    icon: Calendar
  },
  {
    category: 'Service Details',
    question: 'Do I need to provide water or power on-site?',
    answer: 'No! We are completely self-contained. Our mobile units come equipped with their own water tanks (up to 50 gallons) and generators. All we need is a flat parking space near your vehicle. However, if you have access to water and electricity, it can help us work more efficiently.',
    icon: Droplet
  },
  {
    category: 'Service Details',
    question: 'What if it rains on my appointment day?',
    answer: 'Light rain isn\'t a problem for interior details. For exterior work, we\'ll monitor the forecast and contact you 24 hours before if rescheduling is needed. We never apply coatings or wax in wet conditions as it affects the final result. Rescheduling is free and easy!',
    icon: CloudRain
  },
  {
    category: 'Service Details',
    question: 'Do you detail at my home or business?',
    answer: 'Yes! We\'re a fully mobile detailing service. We come to your home, office, or any location within our service area. Just ensure there\'s adequate space to work around your vehicle (about 10 feet clearance on all sides is ideal).',
    icon: MapPin
  },
  {
    category: 'Service Details',
    question: 'What\'s included in each package?',
    answer: 'Basic Detail includes exterior wash, wheels, tire shine, windows, vacuum, and interior wipe-down. Standard Detail adds clay bar treatment, wax, deep interior cleaning, and leather conditioning. Premium Detail includes everything plus paint correction, ceramic coating, engine bay detail, and premium protection treatments.',
    icon: Sparkles
  },
  {
    category: 'Payment & Pricing',
    question: 'What forms of payment do you accept?',
    answer: 'We accept all major credit cards (Visa, Mastercard, American Express, Discover), debit cards, cash, Venmo, Zelle, and Apple Pay. Payment is due upon completion of service. We also offer pre-payment options when booking online.',
    icon: CreditCard
  },
  {
    category: 'Payment & Pricing',
    question: 'Are prices guaranteed or can they change?',
    answer: 'Our quoted prices are estimates based on average vehicle condition. The final price may vary if your vehicle requires significantly more time due to excessive dirt, pet hair, stains, or neglect. We\'ll always communicate any pricing adjustments before proceeding with extra work.',
    icon: Shield
  },
  {
    category: 'Payment & Pricing',
    question: 'Do you offer discounts for multiple vehicles?',
    answer: 'Yes! We offer 10% off when you book 2 vehicles, and 15% off for 3 or more vehicles scheduled on the same day. Fleet and commercial accounts receive custom pricing. Ask about our monthly maintenance plans for even better savings.',
    icon: Users
  },
  {
    category: 'Preparation & Tips',
    question: 'Do I need to clean my car before you arrive?',
    answer: 'Not at all! That\'s our job. However, please remove all personal belongings, valuables, and loose items from the vehicle. Check the trunk, glove box, under seats, and door pockets. This helps us work faster and ensures nothing gets misplaced.',
    icon: Car
  },
  {
    category: 'Preparation & Tips',
    question: 'Can I wait in my car during the detail?',
    answer: 'We ask that you don\'t remain in the vehicle during service so our technicians can work efficiently and access all areas. Most customers drop off their keys and go about their day, or if we\'re at your home/office, you can relax nearby. We\'ll text when we\'re finished!',
    icon: Users
  },
  {
    category: 'Preparation & Tips',
    question: 'What about pet hair removal?',
    answer: 'We specialize in pet hair removal! It\'s included in all our packages, though excessive amounts may require additional time and a small surcharge. Our specialized tools and techniques can remove even the most stubborn fur from fabric, carpet, and crevices.',
    icon: Sparkles
  },
  {
    category: 'Results & Maintenance',
    question: 'How long will the results last?',
    answer: 'With proper maintenance, Basic Details stay fresh for 2-3 weeks, Standard Details last 4-6 weeks, and Premium Details with ceramic coating can last 6+ months. We provide maintenance tips and recommend regular touch-ups to keep your vehicle looking showroom-fresh.',
    icon: Shield
  },
  {
    category: 'Results & Maintenance',
    question: 'Do you offer maintenance plans?',
    answer: 'Yes! Our monthly maintenance plans include scheduled details at discounted rates. Choose from weekly, bi-weekly, or monthly services. It\'s perfect for keeping your daily driver pristine without the hassle of booking each time. Ask about our VIP membership benefits!',
    icon: Calendar
  }
];

const categories = [
  { id: 'all', label: 'All Questions', icon: HelpCircle },
  { id: 'Booking & Scheduling', label: 'Booking', icon: Calendar },
  { id: 'Service Details', label: 'Services', icon: Sparkles },
  { id: 'Payment & Pricing', label: 'Pricing', icon: CreditCard },
  { id: 'Preparation & Tips', label: 'Preparation', icon: Car },
  { id: 'Results & Maintenance', label: 'Maintenance', icon: Shield }
];

export function FAQ() {
  const [selectedCategory, setSelectedCategory] = useState('all');

  const filteredFAQs = selectedCategory === 'all' 
    ? faqs 
    : faqs.filter(faq => faq.category === selectedCategory);

  return (
    <div className="min-h-screen pt-20 pb-20 md:pb-0 bg-gradient-to-b from-white via-[#f8f8f8] to-white">
      {/* Header */}
      <section className="relative bg-gradient-to-br from-[#10150f] to-[#1a1f1a] py-16 md:py-20 px-6 sm:px-8 lg:px-12">
        <div className="absolute inset-0 opacity-5">
          <div className="absolute inset-0" style={{
            backgroundImage: 'radial-gradient(circle at 2px 2px, white 1px, transparent 0)',
            backgroundSize: '40px 40px'
          }} />
        </div>
        <div className="max-w-4xl mx-auto text-center relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <div className="inline-flex items-center justify-center w-16 h-16 bg-[#8cc0d6]/20 rounded-full mb-6">
              <HelpCircle className="w-8 h-8 text-[#8cc0d6]" />
            </div>
            <h1 className="text-3xl sm:text-4xl md:text-5xl text-white mb-4">
              Frequently Asked Questions
            </h1>
            <p className="text-base sm:text-lg text-gray-300 max-w-2xl mx-auto">
              Get answers to common questions about our mobile detailing services.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Main Content */}
      <section className="py-12 md:py-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto">
          {/* Category Filter */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="mb-8"
          >
            <div className="flex flex-wrap justify-center gap-2 mb-8">
              {categories.map((category) => {
                const Icon = category.icon;
                const isActive = selectedCategory === category.id;
                const count = category.id === 'all' 
                  ? faqs.length 
                  : faqs.filter(f => f.category === category.id).length;

                return (
                  <button
                    key={category.id}
                    onClick={() => setSelectedCategory(category.id)}
                    className={`
                      flex items-center gap-2 px-4 py-2 rounded-full transition-all duration-300 text-sm
                      ${isActive 
                        ? 'bg-[#56070f] text-white shadow-lg scale-105' 
                        : 'bg-white text-[#10150f] border-2 border-gray-200 hover:border-[#8cc0d6] hover:shadow-md'
                      }
                    `}
                  >
                    <Icon className="w-4 h-4" />
                    <span>{category.label}</span>
                    <span className={`
                      px-2 py-0.5 rounded-full text-xs
                      ${isActive ? 'bg-white/20' : 'bg-gray-100'}
                    `}>
                      {count}
                    </span>
                  </button>
                );
              })}
            </div>
          </motion.div>

          {/* FAQ Accordion */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.3 }}
          >
            <Card className="shadow-lg border-2 border-gray-100">
              <CardContent className="p-4 sm:p-6">
                <Accordion type="single" collapsible className="w-full space-y-3">
                  {filteredFAQs.map((faq, index) => {
                    const Icon = faq.icon;
                    
                    return (
                      <AccordionItem 
                        key={index} 
                        value={`item-${index}`}
                        className="border-2 border-gray-100 rounded-lg px-4 sm:px-6 data-[state=open]:border-[#8cc0d6] data-[state=open]:bg-[#8cc0d6]/5 transition-all"
                      >
                        <AccordionTrigger className="hover:no-underline py-4">
                          <div className="flex items-start gap-3 text-left pr-4">
                            <div className="w-10 h-10 bg-[#8cc0d6]/10 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                              <Icon className="w-5 h-5 text-[#8cc0d6]" />
                            </div>
                            <div className="flex-1">
                              <p className="text-[#10150f] pr-2">{faq.question}</p>
                              <span className="text-xs text-gray-500 mt-1 inline-block">
                                {faq.category}
                              </span>
                            </div>
                          </div>
                        </AccordionTrigger>
                        <AccordionContent className="pt-2 pb-4">
                          <div className="pl-[52px] pr-4">
                            <p className="text-gray-700 leading-relaxed">
                              {faq.answer}
                            </p>
                          </div>
                        </AccordionContent>
                      </AccordionItem>
                    );
                  })}
                </Accordion>
              </CardContent>
            </Card>
          </motion.div>

          {/* Still Have Questions CTA */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.4 }}
            className="mt-12"
          >
            <Card className="border-2 border-[#8cc0d6]/30 bg-gradient-to-br from-[#8cc0d6]/10 to-white shadow-lg">
              <CardContent className="p-8 text-center">
                <div className="inline-flex items-center justify-center w-14 h-14 bg-[#8cc0d6] rounded-full mb-4">
                  <Phone className="w-7 h-7 text-white" />
                </div>
                <h3 className="text-2xl text-[#10150f] mb-3">
                  Still Have Questions?
                </h3>
                <p className="text-gray-600 mb-6 max-w-md mx-auto">
                  Our team is here to help! Give us a call or send us a message and we'll get back to you within 24 hours.
                </p>
                <div className="flex flex-col sm:flex-row gap-3 justify-center">
                  <Button 
                    asChild
                    className="bg-[#56070f] hover:bg-[#6e0912] text-white px-8 py-6"
                  >
                    <a href="tel:+15551234567">
                      <Phone className="w-4 h-4 mr-2" />
                      Call (555) 123-4567
                    </a>
                  </Button>
                  <Button 
                    asChild
                    variant="outline"
                    className="border-2 border-[#8cc0d6] text-[#8cc0d6] hover:bg-[#8cc0d6]/10 px-8 py-6"
                  >
                    <a href="#quote">
                      Request a Quote
                    </a>
                  </Button>
                </div>
              </CardContent>
            </Card>
          </motion.div>

          {/* Quick Tips */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.5 }}
            className="mt-8"
          >
            <div className="bg-gradient-to-r from-[#10150f] to-[#1a1f1a] rounded-2xl p-6 sm:p-8 text-white">
              <h4 className="text-xl mb-4 flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-[#8cc0d6]" />
                Pro Tips for Your First Detail
              </h4>
              <ul className="space-y-3 text-sm text-gray-300">
                <li className="flex items-start gap-3">
                  <span className="text-[#8cc0d6] mt-1">•</span>
                  <span>Remove all personal items including trunk, glove box, and center console</span>
                </li>
                <li className="flex items-start gap-3">
                  <span className="text-[#8cc0d6] mt-1">•</span>
                  <span>Ensure your vehicle has at least a quarter tank of fuel (we may need to move it)</span>
                </li>
                <li className="flex items-start gap-3">
                  <span className="text-[#8cc0d6] mt-1">•</span>
                  <span>Park in a shaded area if possible — direct sunlight can affect exterior work</span>
                </li>
                <li className="flex items-start gap-3">
                  <span className="text-[#8cc0d6] mt-1">•</span>
                  <span>Let us know about any existing damage so we can document it before starting</span>
                </li>
                <li className="flex items-start gap-3">
                  <span className="text-[#8cc0d6] mt-1">•</span>
                  <span>Book during off-peak hours (weekday mornings) for faster scheduling</span>
                </li>
              </ul>
            </div>
          </motion.div>
        </div>
      </section>
    </div>
  );
}
