import { Booking } from '../components/Booking';
import { WaveDivider } from '../components/WaveDivider';
import { motion } from 'motion/react';
import { MapPin, Phone, Mail, Clock, Instagram, Facebook, Send } from 'lucide-react';
import { Input } from '../components/ui/input';
import { Textarea } from '../components/ui/textarea';
import { RippleButton } from '../components/ui/ripple-button';
import { useState } from 'react';

export function Contact() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    message: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log('Contact form submitted:', formData);
    alert('Thank you for reaching out! We\'ll get back to you within 24 hours.');
    setFormData({ name: '', email: '', message: '' });
  };

  return (
    <div className="min-h-screen pt-20 pb-20 md:pb-0">
      {/* Hero Header */}
      <section className="relative bg-[#10150f] py-16 md:py-20 px-6 sm:px-8 lg:px-12">
        <div className="max-w-4xl mx-auto text-center">
          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="text-3xl sm:text-4xl md:text-5xl text-white mb-4"
          >
            Get In Touch
          </motion.h1>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="text-base sm:text-lg text-gray-300"
          >
            Book your appointment or reach out with any questions
          </motion.p>
        </div>
      </section>

      {/* Wave Divider */}
      <WaveDivider color="#ffffff" />

      {/* Contact Info */}
      <section className="py-16 md:py-20 px-6 sm:px-8 lg:px-12 bg-white">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-16">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="text-center group"
            >
              <div className="w-16 h-16 bg-[#8cc0d6]/10 rounded-full flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform duration-300">
                <MapPin className="w-8 h-8 text-[#8cc0d6] transition-transform duration-300 group-hover:rotate-[5deg]" />
              </div>
              <h3 className="text-lg text-[#10150f] mb-2">Location</h3>
              <p className="text-gray-600">
                123 Auto Street
                <br />
                Auto City, AC 12345
              </p>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.1 }}
              className="text-center group"
            >
              <div className="w-16 h-16 bg-[#56070f]/10 rounded-full flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform duration-300">
                <Phone className="w-8 h-8 text-[#56070f] transition-transform duration-300 group-hover:rotate-[5deg]" />
              </div>
              <h3 className="text-lg text-[#10150f] mb-2">Phone</h3>
              <a href="tel:+15551234567" className="text-gray-600 hover:text-[#56070f]">
                (555) 123-4567
              </a>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.2 }}
              className="text-center group"
            >
              <div className="w-16 h-16 bg-[#8cc0d6]/10 rounded-full flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform duration-300">
                <Mail className="w-8 h-8 text-[#8cc0d6] transition-transform duration-300 group-hover:rotate-[5deg]" />
              </div>
              <h3 className="text-lg text-[#10150f] mb-2">Email</h3>
              <a href="mailto:info@cruznclean.com" className="text-gray-600 hover:text-[#8cc0d6]">
                info@cruznclean.com
              </a>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.3 }}
              className="text-center"
            >
              <div className="w-16 h-16 bg-[#56070f]/10 rounded-full flex items-center justify-center mx-auto mb-4">
                <Clock className="w-8 h-8 text-[#56070f]" />
              </div>
              <h3 className="text-lg text-[#10150f] mb-2">Hours</h3>
              <p className="text-gray-600">
                Mon-Fri: 8AM - 6PM
                <br />
                Sat: 9AM - 5PM
              </p>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Quick Contact Form */}
      <section className="py-16 px-4 bg-[#f8f8f8]">
        <div className="max-w-3xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-12"
          >
            <h2 className="text-3xl md:text-4xl text-[#10150f] mb-4">
              Questions before booking?
            </h2>
            <p className="text-gray-600 max-w-xl mx-auto">
              Send us a quick message and we'll get back to you within 24 hours
            </p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.2 }}
            className="bg-white rounded-2xl shadow-lg p-8 md:p-10"
          >
            <form onSubmit={handleSubmit} className="space-y-6">
              <div>
                <label htmlFor="name" className="block text-sm text-gray-700 mb-2">
                  Name
                </label>
                <Input
                  id="name"
                  type="text"
                  placeholder="Your name"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  required
                  className="w-full"
                />
              </div>

              <div>
                <label htmlFor="email" className="block text-sm text-gray-700 mb-2">
                  Email
                </label>
                <Input
                  id="email"
                  type="email"
                  placeholder="your.email@example.com"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  required
                  className="w-full"
                />
              </div>

              <div>
                <label htmlFor="message" className="block text-sm text-gray-700 mb-2">
                  Message
                </label>
                <Textarea
                  id="message"
                  placeholder="What would you like to know?"
                  value={formData.message}
                  onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                  required
                  className="w-full min-h-[150px]"
                />
              </div>

              <RippleButton
                type="submit"
                className="w-full bg-[#56070f] hover:bg-[#56070f]/90 text-white py-6"
              >
                <Send className="w-5 h-5 mr-2" />
                Send Message
              </RippleButton>
            </form>

            {/* Social Links & Phone */}
            <div className="mt-8 pt-8 border-t border-gray-200">
              <div className="flex flex-col md:flex-row items-center justify-between gap-6">
                <div className="flex items-center gap-2 text-gray-700">
                  <Phone className="w-5 h-5 text-[#56070f]" />
                  <span>Or call us:</span>
                  <a href="tel:+15551234567" className="text-[#56070f] hover:underline">
                    (555) 123-4567
                  </a>
                </div>

                <div className="flex items-center gap-4">
                  <span className="text-sm text-gray-600">Follow us:</span>
                  <a
                    href="https://instagram.com"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-10 h-10 rounded-full bg-gradient-to-br from-purple-600 to-pink-500 flex items-center justify-center text-white hover:scale-110 transition-transform"
                  >
                    <Instagram className="w-5 h-5" />
                  </a>
                  <a
                    href="https://facebook.com"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-10 h-10 rounded-full bg-[#1877f2] flex items-center justify-center text-white hover:scale-110 transition-transform"
                  >
                    <Facebook className="w-5 h-5" />
                  </a>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Booking Section */}
      <Booking />
    </div>
  );
}
