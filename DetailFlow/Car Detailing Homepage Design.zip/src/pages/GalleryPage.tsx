import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Sparkles, Droplet, Shield, ArrowLeftRight, Grid3x3 } from 'lucide-react';
import { WaveDivider } from '../components/WaveDivider';
import { ImageWithFallback } from '../components/figma/ImageWithFallback';

interface GalleryImage {
  id: number;
  url: string;
  alt: string;
  caption: string;
  category: 'exterior' | 'interior' | 'premium' | 'before-after';
  packageType: string;
}

const galleryImages: GalleryImage[] = [
  {
    id: 1,
    url: 'https://images.unsplash.com/photo-1708805282683-50a060eba80f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjYXIlMjBleHRlcmlvciUyMGRldGFpbGluZyUyMHNoaW5lfGVufDF8fHx8MTc2MTM4NjEwOXww&ixlib=rb-4.1.0&q=80&w=1080',
    alt: 'Exterior detailing shine',
    caption: 'Mirror-like finish after premium ceramic coating',
    category: 'exterior',
    packageType: 'Premium Detail'
  },
  {
    id: 2,
    url: 'https://images.unsplash.com/photo-1705079483667-844c6e5c6085?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjYXIlMjBpbnRlcmlvciUyMGRldGFpbGluZyUyMGxlYXRoZXJ8ZW58MXx8fHwxNzYxMzg2MTA5fDA&ixlib=rb-4.1.0&q=80&w=1080',
    alt: 'Interior leather detailing',
    caption: 'Luxury leather conditioning and restoration',
    category: 'interior',
    packageType: 'Standard Detail'
  },
  {
    id: 3,
    url: 'https://images.unsplash.com/photo-1714436825865-93bdb8050bdf?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxsdXh1cnklMjBjYXIlMjBwYWludCUyMGNlcmFtaWN8ZW58MXx8fHwxNzYxMzg2MTEwfDA&ixlib=rb-4.1.0&q=80&w=1080',
    alt: 'Luxury car ceramic coating',
    caption: 'Ceramic coating provides 6+ months protection',
    category: 'premium',
    packageType: 'Premium Detail'
  },
  {
    id: 4,
    url: 'https://images.unsplash.com/photo-1746079074371-e28f14c76e37?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjYXIlMjBkZXRhaWxpbmclMjBwb2xpc2h8ZW58MXx8fHwxNzYxMzg2MTEwfDA&ixlib=rb-4.1.0&q=80&w=1080',
    alt: 'Paint correction polishing',
    caption: 'Paint correction removes swirls and scratches',
    category: 'exterior',
    packageType: 'Premium Detail'
  },
  {
    id: 5,
    url: 'https://images.unsplash.com/photo-1739755678899-107b78b9deb6?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjbGVhbiUyMGNhciUyMGludGVyaW9yJTIwc2VhdHN8ZW58MXx8fHwxNzYxMzg2MTEwfDA&ixlib=rb-4.1.0&q=80&w=1080',
    alt: 'Clean interior seats',
    caption: 'Deep cleaned and sanitized interior surfaces',
    category: 'interior',
    packageType: 'Standard Detail'
  },
  {
    id: 6,
    url: 'https://images.unsplash.com/photo-1665585637851-19f1e1dc0e81?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjYXIlMjBoZWFkbGlnaHQlMjByZXN0b3JhdGlvbnxlbnwxfHx8fDE3NjEzODAxMTl8MA&ixlib=rb-4.1.0&q=80&w=1080',
    alt: 'Headlight restoration',
    caption: 'Crystal clear headlight restoration',
    category: 'before-after',
    packageType: 'Add-on Service'
  },
  {
    id: 7,
    url: 'https://images.unsplash.com/photo-1740744356759-4b4ff55c479e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzcG9ydHMlMjBjYXIlMjB3YXh8ZW58MXx8fHwxNzYxMzg2MTExfDA&ixlib=rb-4.1.0&q=80&w=1080',
    alt: 'Sports car wax finish',
    caption: 'Show-quality wax application on exotic vehicles',
    category: 'premium',
    packageType: 'Premium Detail'
  },
  {
    id: 8,
    url: 'https://images.unsplash.com/photo-1595879038763-969b6e17e093?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjYXIlMjBkYXNoYm9hcmQlMjBjbGVhbmluZ3xlbnwxfHx8fDE3NjEzODYxMTF8MA&ixlib=rb-4.1.0&q=80&w=1080',
    alt: 'Dashboard detailing',
    caption: 'Dashboard treated with UV protectant',
    category: 'interior',
    packageType: 'Basic Detail'
  },
  {
    id: 9,
    url: 'https://images.unsplash.com/photo-1638223222137-4ca13c7306a7?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjYXIlMjB3aGVlbCUyMGRldGFpbGluZ3xlbnwxfHx8fDE3NjEzODYxMTJ8MA&ixlib=rb-4.1.0&q=80&w=1080',
    alt: 'Wheel detailing',
    caption: 'Wheels deep cleaned and protected',
    category: 'exterior',
    packageType: 'Standard Detail'
  },
  {
    id: 10,
    url: 'https://images.unsplash.com/photo-1587350811935-ee13e79e068d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxsdXh1cnklMjB2ZWhpY2xlJTIwY2xlYW58ZW58MXx8fHwxNzYxMzg2MTEyfDA&ixlib=rb-4.1.0&q=80&w=1080',
    alt: 'Luxury vehicle detail',
    caption: 'Complete exterior transformation',
    category: 'premium',
    packageType: 'Premium Detail'
  },
  {
    id: 11,
    url: 'https://images.unsplash.com/photo-1694678505383-676d78ea3b96?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjYXIlMjB3YXNoJTIwZGV0YWlsaW5nJTIwc2VydmljZXxlbnwxfHx8fDE3NjEzODYxMTN8MA&ixlib=rb-4.1.0&q=80&w=1080',
    alt: 'Professional car wash',
    caption: 'Gentle hand wash and foam treatment',
    category: 'exterior',
    packageType: 'Basic Detail'
  },
  {
    id: 12,
    url: 'https://images.unsplash.com/photo-1662815826264-b7163581bb1c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx2ZWhpY2xlJTIwaW50ZXJpb3IlMjB2YWN1dW18ZW58MXx8fHwxNzYxMzg2MTEzfDA&ixlib=rb-4.1.0&q=80&w=1080',
    alt: 'Interior vacuum service',
    caption: 'Thorough vacuuming and carpet shampooing',
    category: 'interior',
    packageType: 'Standard Detail'
  }
];

const categories = [
  { id: 'all', label: 'All Work', icon: null },
  { id: 'exterior', label: 'Exterior', icon: Sparkles },
  { id: 'interior', label: 'Interior', icon: Droplet },
  { id: 'premium', label: 'Premium', icon: Shield },
  { id: 'before-after', label: 'Before/After', icon: ArrowLeftRight }
];

export function GalleryPage() {
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [lightboxImage, setLightboxImage] = useState<GalleryImage | null>(null);

  const filteredImages = selectedCategory === 'all' 
    ? galleryImages 
    : galleryImages.filter(img => img.category === selectedCategory);

  // Group images by category for sectioned view
  const groupedImages = {
    exterior: galleryImages.filter(img => img.category === 'exterior'),
    interior: galleryImages.filter(img => img.category === 'interior'),
    premium: galleryImages.filter(img => img.category === 'premium'),
    'before-after': galleryImages.filter(img => img.category === 'before-after'),
  };

  return (
    <div className="min-h-screen pt-20 pb-20 md:pb-0">
      {/* Hero Header */}
      <section className="relative bg-gradient-to-br from-[#10150f] to-[#1a1f1a] py-16 md:py-20 px-6 sm:px-8 lg:px-12">
        <div className="absolute inset-0 opacity-5">
          <div className="absolute inset-0" style={{
            backgroundImage: 'radial-gradient(circle at 2px 2px, white 1px, transparent 0)',
            backgroundSize: '40px 40px'
          }} />
        </div>
        <div className="max-w-4xl mx-auto text-center relative z-10">
          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="text-3xl sm:text-4xl md:text-5xl text-white mb-4"
          >
            Our Work
          </motion.h1>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="text-base sm:text-lg text-gray-300"
          >
            Real results from real clients — see the difference Cruzn Clean delivers.
          </motion.p>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.3 }}
            className="text-sm text-gray-400 mt-2"
          >
            Every project showcases our precision and care.
          </motion.p>
        </div>
      </section>

      {/* Wave Divider */}
      <WaveDivider color="#ffffff" />

      {/* Gallery Section */}
      <section className="relative py-12 md:py-16 px-4 sm:px-6 lg:px-8 bg-gradient-to-b from-white via-[#f8f8f8] to-white">
        <div className="max-w-7xl mx-auto">
          {/* Filter Chips */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="mb-12"
          >
            <div className="flex flex-wrap justify-center gap-2 md:gap-3">
              {categories.map((category) => {
                const Icon = category.icon;
                const isActive = selectedCategory === category.id;

                return (
                  <button
                    key={category.id}
                    onClick={() => setSelectedCategory(category.id)}
                    className={`
                      flex items-center gap-2 px-4 md:px-6 py-2.5 rounded-full transition-all duration-300
                      ${isActive 
                        ? 'bg-[#56070f] text-white shadow-lg scale-105' 
                        : 'bg-white text-[#10150f] border-2 border-gray-200 hover:border-[#8cc0d6] hover:shadow-md'
                      }
                    `}
                  >
                    {Icon && <Icon className="w-4 h-4" />}
                    <span className="text-sm">{category.label}</span>
                    {isActive && (
                      <span className="ml-1 px-2 py-0.5 bg-white/20 rounded-full text-xs">
                        {filteredImages.length}
                      </span>
                    )}
                  </button>
                );
              })}
            </div>
          </motion.div>

          {/* Filtered View - Consistent Grid */}
          {selectedCategory !== 'all' && (
            <AnimatePresence mode="wait">
              <motion.div
                key={selectedCategory}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                transition={{ duration: 0.4 }}
              >
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                  {filteredImages.map((image, index) => (
                    <motion.div
                      key={image.id}
                      initial={{ opacity: 0, scale: 0.9 }}
                      animate={{ opacity: 1, scale: 1 }}
                      transition={{ duration: 0.4, delay: index * 0.05 }}
                      className="group relative cursor-pointer rounded-xl overflow-hidden shadow-md hover:shadow-2xl transition-all duration-300 aspect-[4/3]"
                      onClick={() => setLightboxImage(image)}
                    >
                      <ImageWithFallback
                        src={image.url}
                        alt={image.alt}
                        className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                      />
                      
                      {/* Overlay on Hover */}
                      <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                        <div className="absolute bottom-0 left-0 right-0 p-4 transform translate-y-2 group-hover:translate-y-0 transition-transform duration-300">
                          <p className="text-white text-sm mb-1">{image.caption}</p>
                          <p className="text-[#8cc0d6] text-xs">{image.packageType}</p>
                        </div>
                      </div>

                      {/* Shimmer Effect */}
                      <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-300 overflow-hidden pointer-events-none">
                        <div
                          className="absolute inset-0 animate-shimmer"
                          style={{
                            background: 'linear-gradient(90deg, transparent 0%, rgba(140, 192, 214, 0.3) 50%, transparent 100%)',
                          }}
                        />
                      </div>
                    </motion.div>
                  ))}
                </div>

                {/* No Results */}
                {filteredImages.length === 0 && (
                  <motion.div
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    className="text-center py-16"
                  >
                    <p className="text-gray-500 text-lg">No images found in this category.</p>
                  </motion.div>
                )}
              </motion.div>
            </AnimatePresence>
          )}

          {/* Sectioned View - All Work */}
          {selectedCategory === 'all' && (
            <div className="space-y-16">
              {/* Exterior Section */}
              {groupedImages.exterior.length > 0 && (
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6 }}
                >
                  <div className="flex items-center gap-3 mb-6">
                    <div className="w-12 h-12 rounded-xl bg-[#8cc0d6]/10 flex items-center justify-center">
                      <Sparkles className="w-6 h-6 text-[#8cc0d6]" />
                    </div>
                    <div>
                      <h3 className="text-2xl text-[#10150f]">Exterior Detailing</h3>
                      <p className="text-sm text-gray-600">{groupedImages.exterior.length} projects</p>
                    </div>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                    {groupedImages.exterior.map((image, index) => (
                      <motion.div
                        key={image.id}
                        initial={{ opacity: 0, scale: 0.9 }}
                        animate={{ opacity: 1, scale: 1 }}
                        transition={{ duration: 0.4, delay: index * 0.05 }}
                        className="group relative cursor-pointer rounded-xl overflow-hidden shadow-md hover:shadow-2xl transition-all duration-300 aspect-square"
                        onClick={() => setLightboxImage(image)}
                      >
                        <ImageWithFallback
                          src={image.url}
                          alt={image.alt}
                          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                        />
                        <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                          <div className="absolute bottom-0 left-0 right-0 p-3">
                            <p className="text-white text-xs mb-0.5 line-clamp-2">{image.caption}</p>
                            <p className="text-[#8cc0d6] text-xs">{image.packageType}</p>
                          </div>
                        </div>
                      </motion.div>
                    ))}
                  </div>
                </motion.div>
              )}

              {/* Interior Section */}
              {groupedImages.interior.length > 0 && (
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: 0.1 }}
                >
                  <div className="flex items-center gap-3 mb-6">
                    <div className="w-12 h-12 rounded-xl bg-[#8cc0d6]/10 flex items-center justify-center">
                      <Droplet className="w-6 h-6 text-[#8cc0d6]" />
                    </div>
                    <div>
                      <h3 className="text-2xl text-[#10150f]">Interior Detailing</h3>
                      <p className="text-sm text-gray-600">{groupedImages.interior.length} projects</p>
                    </div>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                    {groupedImages.interior.map((image, index) => (
                      <motion.div
                        key={image.id}
                        initial={{ opacity: 0, scale: 0.9 }}
                        animate={{ opacity: 1, scale: 1 }}
                        transition={{ duration: 0.4, delay: index * 0.05 }}
                        className="group relative cursor-pointer rounded-xl overflow-hidden shadow-md hover:shadow-2xl transition-all duration-300 aspect-square"
                        onClick={() => setLightboxImage(image)}
                      >
                        <ImageWithFallback
                          src={image.url}
                          alt={image.alt}
                          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                        />
                        <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                          <div className="absolute bottom-0 left-0 right-0 p-3">
                            <p className="text-white text-xs mb-0.5 line-clamp-2">{image.caption}</p>
                            <p className="text-[#8cc0d6] text-xs">{image.packageType}</p>
                          </div>
                        </div>
                      </motion.div>
                    ))}
                  </div>
                </motion.div>
              )}

              {/* Premium Section */}
              {groupedImages.premium.length > 0 && (
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: 0.2 }}
                >
                  <div className="flex items-center gap-3 mb-6">
                    <div className="w-12 h-12 rounded-xl bg-[#56070f]/10 flex items-center justify-center">
                      <Shield className="w-6 h-6 text-[#56070f]" />
                    </div>
                    <div>
                      <h3 className="text-2xl text-[#10150f]">Premium Services</h3>
                      <p className="text-sm text-gray-600">{groupedImages.premium.length} projects</p>
                    </div>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                    {groupedImages.premium.map((image, index) => (
                      <motion.div
                        key={image.id}
                        initial={{ opacity: 0, scale: 0.9 }}
                        animate={{ opacity: 1, scale: 1 }}
                        transition={{ duration: 0.4, delay: index * 0.05 }}
                        className="group relative cursor-pointer rounded-xl overflow-hidden shadow-md hover:shadow-2xl transition-all duration-300 aspect-[4/3]"
                        onClick={() => setLightboxImage(image)}
                      >
                        <ImageWithFallback
                          src={image.url}
                          alt={image.alt}
                          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                        />
                        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                          <div className="absolute bottom-0 left-0 right-0 p-4 transform translate-y-2 group-hover:translate-y-0 transition-transform duration-300">
                            <p className="text-white text-sm mb-1">{image.caption}</p>
                            <p className="text-[#8cc0d6] text-xs">{image.packageType}</p>
                          </div>
                        </div>
                        <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-300 overflow-hidden pointer-events-none">
                          <div
                            className="absolute inset-0 animate-shimmer"
                            style={{
                              background: 'linear-gradient(90deg, transparent 0%, rgba(140, 192, 214, 0.3) 50%, transparent 100%)',
                            }}
                          />
                        </div>
                      </motion.div>
                    ))}
                  </div>
                </motion.div>
              )}

              {/* Before/After Section */}
              {groupedImages['before-after'].length > 0 && (
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: 0.3 }}
                >
                  <div className="flex items-center gap-3 mb-6">
                    <div className="w-12 h-12 rounded-xl bg-[#8cc0d6]/10 flex items-center justify-center">
                      <ArrowLeftRight className="w-6 h-6 text-[#8cc0d6]" />
                    </div>
                    <div>
                      <h3 className="text-2xl text-[#10150f]">Before & After</h3>
                      <p className="text-sm text-gray-600">{groupedImages['before-after'].length} transformations</p>
                    </div>
                  </div>
                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                    {groupedImages['before-after'].map((image, index) => (
                      <motion.div
                        key={image.id}
                        initial={{ opacity: 0, scale: 0.9 }}
                        animate={{ opacity: 1, scale: 1 }}
                        transition={{ duration: 0.4, delay: index * 0.05 }}
                        className="group relative cursor-pointer rounded-xl overflow-hidden shadow-md hover:shadow-2xl transition-all duration-300 aspect-video"
                        onClick={() => setLightboxImage(image)}
                      >
                        <ImageWithFallback
                          src={image.url}
                          alt={image.alt}
                          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                        />
                        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                          <div className="absolute bottom-0 left-0 right-0 p-5 transform translate-y-2 group-hover:translate-y-0 transition-transform duration-300">
                            <p className="text-white mb-1">{image.caption}</p>
                            <p className="text-[#8cc0d6] text-sm">{image.packageType}</p>
                          </div>
                        </div>
                      </motion.div>
                    ))}
                  </div>
                </motion.div>
              )}
            </div>
          )}
        </div>
      </section>

      {/* Lightbox */}
      <AnimatePresence>
        {lightboxImage && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
            className="fixed inset-0 z-50 bg-black/95 flex items-center justify-center p-4"
            onClick={() => setLightboxImage(null)}
          >
            {/* Close Button */}
            <button
              className="absolute top-4 right-4 w-10 h-10 bg-white/10 backdrop-blur-sm rounded-full flex items-center justify-center text-white hover:bg-white/20 transition-colors"
              onClick={() => setLightboxImage(null)}
            >
              <X className="w-6 h-6" />
            </button>

            {/* Image Container */}
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              transition={{ duration: 0.3 }}
              className="max-w-5xl w-full"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="bg-white rounded-2xl overflow-hidden shadow-2xl">
                <div className="relative aspect-video">
                  <ImageWithFallback
                    src={lightboxImage.url}
                    alt={lightboxImage.alt}
                    className="w-full h-full object-contain bg-[#10150f]"
                  />
                </div>
                
                {/* Caption */}
                <div className="p-6 bg-white">
                  <div className="flex items-start justify-between gap-4">
                    <div className="flex-1">
                      <h3 className="text-xl text-[#10150f] mb-2">
                        {lightboxImage.caption}
                      </h3>
                      <div className="flex items-center gap-2">
                        <span className="inline-flex items-center gap-1.5 px-3 py-1 bg-[#8cc0d6]/10 text-[#8cc0d6] rounded-full text-sm">
                          {categories.find(c => c.id === lightboxImage.category)?.label}
                        </span>
                        <span className="text-sm text-gray-600">
                          {lightboxImage.packageType}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
