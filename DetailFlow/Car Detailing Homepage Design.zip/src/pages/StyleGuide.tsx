import { motion } from 'motion/react';
import { 
  Droplet, 
  Sparkles, 
  Car, 
  Shield, 
  Clock, 
  Star,
  ArrowRight,
  CheckCircle2,
  Info,
  AlertCircle,
  Copy,
  Check
} from 'lucide-react';
import { Button } from '../components/ui/button';
import { Badge } from '../components/ui/badge';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '../components/ui/card';
import { Separator } from '../components/ui/separator';
import { WaveDivider } from '../components/WaveDivider';
import { useState } from 'react';

export function StyleGuide() {
  const [copiedColor, setCopiedColor] = useState<string | null>(null);

  const colors = [
    { name: 'Deep Red', hex: '#56070f', var: 'primary', usage: 'Primary actions, CTAs, accents' },
    { name: 'Water Blue', hex: '#8cc0d6', var: 'secondary', usage: 'Secondary elements, highlights' },
    { name: 'Deep Black', hex: '#10150f', var: 'dark', usage: 'Headers, primary text' },
    { name: 'Neutral Gray', hex: '#f8f8f8', var: 'light', usage: 'Backgrounds, subtle sections' }
  ];

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedColor(text);
    setTimeout(() => setCopiedColor(null), 2000);
  };

  return (
    <div className="min-h-screen pt-20 bg-white">
      {/* Header */}
      <section className="relative bg-[#10150f] py-24 px-4">
        <div className="max-w-6xl mx-auto text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <h1 className="text-4xl md:text-6xl text-white mb-6">
              Cruzn Clean <span className="text-[#8cc0d6]">Style Guide</span>
            </h1>
            <p className="text-xl text-gray-300 max-w-2xl mx-auto">
              A comprehensive design system for premium car detailing experiences
            </p>
          </motion.div>
        </div>
      </section>

      <WaveDivider color="#ffffff" />

      <div className="max-w-6xl mx-auto px-4 py-16 space-y-24">
        {/* Color Palette */}
        <section>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="mb-12"
          >
            <h2 className="text-3xl md:text-4xl text-[#10150f] mb-3">Color Palette</h2>
            <p className="text-gray-600">
              Our color system evokes premium quality, water clarity, and automotive excellence
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {colors.map((color, index) => (
              <motion.div
                key={color.hex}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
              >
                <Card className="overflow-hidden hover:shadow-lg transition-shadow">
                  <div 
                    className="h-32 cursor-pointer relative group"
                    style={{ backgroundColor: color.hex }}
                    onClick={() => copyToClipboard(color.hex)}
                  >
                    <div className="absolute inset-0 bg-black/0 group-hover:bg-black/10 transition-colors flex items-center justify-center">
                      {copiedColor === color.hex ? (
                        <Check className="w-6 h-6 text-white opacity-0 group-hover:opacity-100 transition-opacity" />
                      ) : (
                        <Copy className="w-6 h-6 text-white opacity-0 group-hover:opacity-100 transition-opacity" />
                      )}
                    </div>
                  </div>
                  <CardContent className="pt-4">
                    <h3 className="text-lg text-[#10150f] mb-2">{color.name}</h3>
                    <p className="text-sm text-gray-600 mb-2 font-mono">{color.hex}</p>
                    <p className="text-xs text-gray-500">{color.usage}</p>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </section>

        <Separator />

        {/* Typography */}
        <section>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="mb-12"
          >
            <h2 className="text-3xl md:text-4xl text-[#10150f] mb-3">Typography</h2>
            <p className="text-gray-600">
              Manrope for headers, Outfit for body text
            </p>
          </motion.div>

          <div className="space-y-8">
            {/* Headers - Manrope */}
            <Card>
              <CardHeader>
                <CardTitle>Headers - Manrope</CardTitle>
                <CardDescription>Clean, modern geometric sans-serif for impact</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div>
                  <p className="text-xs text-gray-500 mb-2">H1 - 3.75rem (60px)</p>
                  <h1 className="text-[60px] leading-tight text-[#10150f]">Every Detail. Every Drive.</h1>
                </div>
                <div>
                  <p className="text-xs text-gray-500 mb-2">H2 - 3rem (48px)</p>
                  <h2 className="text-[48px] leading-tight text-[#10150f]">Premium Detail Packages</h2>
                </div>
                <div>
                  <p className="text-xs text-gray-500 mb-2">H3 - 2.25rem (36px)</p>
                  <h3 className="text-[36px] leading-tight text-[#10150f]">Additional Services</h3>
                </div>
                <div>
                  <p className="text-xs text-gray-500 mb-2">H4 - 1.5rem (24px)</p>
                  <h4 className="text-[24px] leading-tight text-[#10150f]">Customer Testimonials</h4>
                </div>
              </CardContent>
            </Card>

            {/* Body - Outfit */}
            <Card>
              <CardHeader>
                <CardTitle>Body Text - Outfit</CardTitle>
                <CardDescription>Readable, friendly, and approachable</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <p className="text-xs text-gray-500 mb-2">Large - 1.25rem (20px)</p>
                  <p className="text-[20px] text-gray-700">
                    Transform your vehicle with our premium detailing services
                  </p>
                </div>
                <div>
                  <p className="text-xs text-gray-500 mb-2">Base - 1rem (16px)</p>
                  <p className="text-[16px] text-gray-600">
                    Our professional team uses industry-leading techniques and products to restore your car's showroom shine.
                  </p>
                </div>
                <div>
                  <p className="text-xs text-gray-500 mb-2">Small - 0.875rem (14px)</p>
                  <p className="text-[14px] text-gray-600">
                    Available Monday through Saturday. Book your appointment today.
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        </section>

        <Separator />

        {/* Buttons */}
        <section>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="mb-12"
          >
            <h2 className="text-3xl md:text-4xl text-[#10150f] mb-3">Button Variants</h2>
            <p className="text-gray-600">
              Three main variants for different interaction levels
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {/* Primary */}
            <Card>
              <CardHeader>
                <CardTitle>Primary</CardTitle>
                <CardDescription>Solid red for main CTAs</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <Button className="w-full bg-[#56070f] hover:bg-[#56070f]/90 text-white">
                  Book Now
                </Button>
                <Button className="w-full bg-[#56070f] hover:bg-[#56070f]/90 text-white" size="lg">
                  <ArrowRight className="w-5 h-5 mr-2" />
                  Get Started
                </Button>
                <Button className="w-full bg-[#56070f] hover:bg-[#56070f]/90 text-white" size="sm">
                  Learn More
                </Button>
                <div className="pt-2">
                  <code className="text-xs text-gray-600 bg-gray-100 px-2 py-1 rounded">
                    bg-[#56070f] hover:bg-[#56070f]/90
                  </code>
                </div>
              </CardContent>
            </Card>

            {/* Secondary */}
            <Card>
              <CardHeader>
                <CardTitle>Secondary</CardTitle>
                <CardDescription>Outline blue for secondary actions</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <Button 
                  variant="outline" 
                  className="w-full border-2 border-[#8cc0d6] text-[#8cc0d6] hover:bg-[#8cc0d6] hover:text-white"
                >
                  View Gallery
                </Button>
                <Button 
                  variant="outline" 
                  className="w-full border-2 border-[#8cc0d6] text-[#8cc0d6] hover:bg-[#8cc0d6] hover:text-white"
                  size="lg"
                >
                  <Sparkles className="w-5 h-5 mr-2" />
                  Explore Services
                </Button>
                <Button 
                  variant="outline" 
                  className="w-full border-2 border-[#8cc0d6] text-[#8cc0d6] hover:bg-[#8cc0d6] hover:text-white"
                  size="sm"
                >
                  Contact Us
                </Button>
                <div className="pt-2">
                  <code className="text-xs text-gray-600 bg-gray-100 px-2 py-1 rounded">
                    border-[#8cc0d6] hover:bg-[#8cc0d6]
                  </code>
                </div>
              </CardContent>
            </Card>

            {/* Ghost */}
            <Card>
              <CardHeader>
                <CardTitle>Ghost</CardTitle>
                <CardDescription>Transparent for subtle interactions</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <Button 
                  variant="ghost" 
                  className="w-full hover:bg-gray-100 text-[#10150f]"
                >
                  View Details
                </Button>
                <Button 
                  variant="ghost" 
                  className="w-full hover:bg-gray-100 text-[#10150f]"
                  size="lg"
                >
                  <Info className="w-5 h-5 mr-2" />
                  More Info
                </Button>
                <Button 
                  variant="ghost" 
                  className="w-full hover:bg-gray-100 text-[#10150f]"
                  size="sm"
                >
                  Skip
                </Button>
                <div className="pt-2">
                  <code className="text-xs text-gray-600 bg-gray-100 px-2 py-1 rounded">
                    variant="ghost" hover:bg-gray-100
                  </code>
                </div>
              </CardContent>
            </Card>
          </div>
        </section>

        <Separator />

        {/* Icons */}
        <section>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="mb-12"
          >
            <h2 className="text-3xl md:text-4xl text-[#10150f] mb-3">Icon Set</h2>
            <p className="text-gray-600">
              Lucide icons for consistent, clean visuals
            </p>
          </motion.div>

          <Card>
            <CardContent className="pt-6">
              <div className="grid grid-cols-3 md:grid-cols-6 lg:grid-cols-8 gap-6">
                {[
                  { icon: Droplet, name: 'Droplet' },
                  { icon: Sparkles, name: 'Sparkles' },
                  { icon: Car, name: 'Car' },
                  { icon: Shield, name: 'Shield' },
                  { icon: Clock, name: 'Clock' },
                  { icon: Star, name: 'Star' },
                  { icon: ArrowRight, name: 'ArrowRight' },
                  { icon: CheckCircle2, name: 'Check' },
                ].map(({ icon: Icon, name }) => (
                  <div key={name} className="flex flex-col items-center gap-2 group">
                    <div className="w-12 h-12 rounded-lg bg-[#f8f8f8] group-hover:bg-[#8cc0d6]/10 flex items-center justify-center transition-colors">
                      <Icon className="w-6 h-6 text-[#56070f] group-hover:text-[#8cc0d6] transition-colors" />
                    </div>
                    <span className="text-xs text-gray-600">{name}</span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </section>

        <Separator />

        {/* Components */}
        <section>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="mb-12"
          >
            <h2 className="text-3xl md:text-4xl text-[#10150f] mb-3">Component Library</h2>
            <p className="text-gray-600">
              Reusable components for consistent experiences
            </p>
          </motion.div>

          <div className="space-y-8">
            {/* Cards */}
            <div>
              <h3 className="text-2xl text-[#10150f] mb-6">Cards</h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {/* Basic Card */}
                <Card className="hover:shadow-lg transition-shadow">
                  <CardHeader>
                    <CardTitle>Basic Card</CardTitle>
                    <CardDescription>Standard card with header</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <p className="text-gray-600">
                      Simple content container with consistent padding and borders.
                    </p>
                  </CardContent>
                </Card>

                {/* Icon Card */}
                <Card className="hover:shadow-lg transition-shadow">
                  <CardContent className="pt-6">
                    <div className="w-12 h-12 bg-[#8cc0d6]/10 rounded-full flex items-center justify-center mb-4">
                      <Sparkles className="w-6 h-6 text-[#8cc0d6]" />
                    </div>
                    <h4 className="text-lg text-[#10150f] mb-2">Icon Card</h4>
                    <p className="text-gray-600 text-sm">
                      Card with icon accent for service highlights.
                    </p>
                  </CardContent>
                </Card>

                {/* Pricing Card */}
                <Card className="border-2 border-[#56070f] hover:shadow-lg transition-shadow">
                  <CardContent className="pt-6">
                    <div className="text-center">
                      <h4 className="text-lg text-[#10150f] mb-2">Premium</h4>
                      <p className="text-4xl text-[#56070f] mb-4">$349</p>
                      <p className="text-sm text-gray-600">
                        Featured pricing card with border accent.
                      </p>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>

            {/* Badges/Tags */}
            <div>
              <h3 className="text-2xl text-[#10150f] mb-6">Badges & Tags</h3>
              <div className="flex flex-wrap gap-3">
                <Badge className="bg-[#56070f] hover:bg-[#56070f]/90">Popular</Badge>
                <Badge variant="secondary" className="bg-[#8cc0d6]/10 text-[#8cc0d6] hover:bg-[#8cc0d6]/20">
                  New
                </Badge>
                <Badge variant="outline" className="border-[#10150f] text-[#10150f]">
                  Premium
                </Badge>
                <Badge className="bg-green-100 text-green-700 hover:bg-green-200">
                  Available
                </Badge>
                <Badge className="bg-yellow-100 text-yellow-700 hover:bg-yellow-200">
                  Limited Time
                </Badge>
              </div>
            </div>

            {/* Dividers */}
            <div>
              <h3 className="text-2xl text-[#10150f] mb-6">Dividers</h3>
              <div className="space-y-8">
                <div>
                  <p className="text-sm text-gray-600 mb-3">Standard Separator</p>
                  <Separator />
                </div>
                <div>
                  <p className="text-sm text-gray-600 mb-3">Wave Divider</p>
                  <div className="relative h-24 bg-[#10150f] rounded-lg overflow-hidden">
                    <WaveDivider color="#ffffff" />
                  </div>
                </div>
              </div>
            </div>

            {/* Info Boxes */}
            <div>
              <h3 className="text-2xl text-[#10150f] mb-6">Info Boxes</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* Success */}
                <div className="p-4 bg-green-50 border border-green-200 rounded-lg flex items-start gap-3">
                  <CheckCircle2 className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
                  <div>
                    <h4 className="text-sm text-green-900 mb-1">Booking Confirmed</h4>
                    <p className="text-sm text-green-700">
                      Your appointment has been successfully scheduled.
                    </p>
                  </div>
                </div>

                {/* Info */}
                <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg flex items-start gap-3">
                  <Info className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
                  <div>
                    <h4 className="text-sm text-blue-900 mb-1">Service Note</h4>
                    <p className="text-sm text-blue-700">
                      Additional services can be added during checkout.
                    </p>
                  </div>
                </div>

                {/* Warning */}
                <div className="p-4 bg-yellow-50 border border-yellow-200 rounded-lg flex items-start gap-3">
                  <AlertCircle className="w-5 h-5 text-yellow-600 flex-shrink-0 mt-0.5" />
                  <div>
                    <h4 className="text-sm text-yellow-900 mb-1">Limited Availability</h4>
                    <p className="text-sm text-yellow-700">
                      Only 3 slots remaining for this weekend.
                    </p>
                  </div>
                </div>

                {/* Premium */}
                <div className="p-4 bg-[#56070f]/5 border border-[#56070f]/20 rounded-lg flex items-start gap-3">
                  <Shield className="w-5 h-5 text-[#56070f] flex-shrink-0 mt-0.5" />
                  <div>
                    <h4 className="text-sm text-[#56070f] mb-1">Satisfaction Guaranteed</h4>
                    <p className="text-sm text-gray-700">
                      100% money-back guarantee on all services.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        <Separator />

        {/* Effects & Motion */}
        <section>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="mb-12"
          >
            <h2 className="text-3xl md:text-4xl text-[#10150f] mb-3">Effects & Motion</h2>
            <p className="text-gray-600">
              Subtle animations that bring the brand to life
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Hover Effects */}
            <Card>
              <CardHeader>
                <CardTitle>Hover States</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="p-4 bg-white border border-gray-200 rounded-lg hover:shadow-lg hover:scale-105 transition-all cursor-pointer">
                  Scale + Shadow on hover
                </div>
                <div className="p-4 bg-[#f8f8f8] rounded-lg hover:bg-[#8cc0d6]/10 transition-colors cursor-pointer">
                  Background color transition
                </div>
              </CardContent>
            </Card>

            {/* Animations */}
            <Card>
              <CardHeader>
                <CardTitle>Entry Animations</CardTitle>
              </CardHeader>
              <CardContent>
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: false }}
                  transition={{ duration: 0.6 }}
                  className="p-4 bg-gradient-to-br from-[#8cc0d6]/10 to-[#56070f]/10 rounded-lg text-center"
                >
                  <p className="text-gray-700">Fade in + slide up animation</p>
                  <p className="text-sm text-gray-500 mt-2">Scroll to replay</p>
                </motion.div>
              </CardContent>
            </Card>
          </div>
        </section>

        {/* Usage Guidelines */}
        <section className="bg-[#f8f8f8] rounded-2xl p-8 md:p-12">
          <h2 className="text-3xl md:text-4xl text-[#10150f] mb-6">Usage Guidelines</h2>
          <div className="space-y-4 text-gray-700">
            <div className="flex items-start gap-3">
              <CheckCircle2 className="w-5 h-5 text-green-600 flex-shrink-0 mt-1" />
              <p>Use Deep Red (#56070f) sparingly for primary CTAs and important accents</p>
            </div>
            <div className="flex items-start gap-3">
              <CheckCircle2 className="w-5 h-5 text-green-600 flex-shrink-0 mt-1" />
              <p>Water Blue (#8cc0d6) represents clarity and premium service quality</p>
            </div>
            <div className="flex items-start gap-3">
              <CheckCircle2 className="w-5 h-5 text-green-600 flex-shrink-0 mt-1" />
              <p>Maintain consistent 12px border radius for modern, cohesive feel</p>
            </div>
            <div className="flex items-start gap-3">
              <CheckCircle2 className="w-5 h-5 text-green-600 flex-shrink-0 mt-1" />
              <p>Use Manrope for all headers, Outfit for body text and descriptions</p>
            </div>
            <div className="flex items-start gap-3">
              <CheckCircle2 className="w-5 h-5 text-green-600 flex-shrink-0 mt-1" />
              <p>Apply subtle motion and hover states for interactive elements</p>
            </div>
            <div className="flex items-start gap-3">
              <CheckCircle2 className="w-5 h-5 text-green-600 flex-shrink-0 mt-1" />
              <p>Ensure minimum 4.5:1 contrast ratio for accessibility compliance</p>
            </div>
          </div>
        </section>
      </div>
    </div>
  );
}
