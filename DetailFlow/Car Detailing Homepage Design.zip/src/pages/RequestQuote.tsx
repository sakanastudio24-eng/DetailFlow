import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Phone, Mail, Clock, MapPin, CheckCircle2, X, ChevronDown } from 'lucide-react';
import { Card, CardContent } from '../components/ui/card';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { Textarea } from '../components/ui/textarea';
import { RippleButton } from '../components/ui/ripple-button';
import { Checkbox } from '../components/ui/checkbox';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from '../components/ui/accordion';
import { useCart } from '../context/CartContext';

export function RequestQuote() {
  const { items, totalPrice } = useCart();
  const [showConfirmation, setShowConfirmation] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    address: '',
    vehicleMake: '',
    vehicleModel: '',
    vehicleYear: '',
    vehicleColor: '',
    services: [] as string[],
    description: ''
  });

  const serviceOptions = [
    { id: 'basic', label: 'Basic Detail', price: 99 },
    { id: 'standard', label: 'Standard Detail', price: 189 },
    { id: 'premium', label: 'Premium Detail', price: 349 },
    { id: 'ceramic', label: 'Ceramic Coating', price: 500 },
    { id: 'headlight', label: 'Headlight Restoration', price: 75 },
    { id: 'engine', label: 'Engine Bay Detail', price: 100 },
  ];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log('Quote request:', formData, items);
    
    // Show confirmation banner
    setShowConfirmation(true);
    
    // Reset form
    setFormData({
      name: '',
      email: '',
      phone: '',
      address: '',
      vehicleMake: '',
      vehicleModel: '',
      vehicleYear: '',
      vehicleColor: '',
      services: [],
      description: ''
    });

    // Auto-hide after 8 seconds
    setTimeout(() => {
      setShowConfirmation(false);
    }, 8000);
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData(prev => ({
      ...prev,
      [e.target.name]: e.target.value
    }));
  };

  const toggleService = (serviceId: string) => {
    setFormData(prev => ({
      ...prev,
      services: prev.services.includes(serviceId)
        ? prev.services.filter(id => id !== serviceId)
        : [...prev.services, serviceId]
    }));
  };

  const estimatedTotal = formData.services.reduce((sum, serviceId) => {
    const service = serviceOptions.find(s => s.id === serviceId);
    return sum + (service?.price || 0);
  }, 0);

  return (
    <div className="min-h-screen pt-20 pb-20 md:pb-0 bg-gradient-to-b from-white via-[#f8f8f8] to-white">
      {/* Floating Confirmation Banner */}
      <AnimatePresence>
        {showConfirmation && (
          <motion.div
            initial={{ y: -100, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: -100, opacity: 0 }}
            transition={{ type: 'spring', damping: 25, stiffness: 300 }}
            className="fixed top-24 left-1/2 -translate-x-1/2 z-50 w-full max-w-md px-4"
          >
            <div className="bg-gradient-to-r from-green-500 to-green-600 text-white rounded-2xl shadow-2xl p-6 relative overflow-hidden">
              {/* Background Pattern */}
              <div className="absolute inset-0 opacity-10">
                <div className="absolute inset-0" style={{
                  backgroundImage: 'radial-gradient(circle at 2px 2px, white 1px, transparent 0)',
                  backgroundSize: '24px 24px'
                }} />
              </div>

              {/* Content */}
              <div className="relative z-10 flex items-start gap-4">
                <div className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center flex-shrink-0">
                  <CheckCircle2 className="w-7 h-7 text-white" />
                </div>
                <div className="flex-1">
                  <h3 className="text-lg mb-1">Request Received!</h3>
                  <p className="text-sm text-white/90">
                    We received your quote request and will reply within 24 hours.
                  </p>
                </div>
                <button
                  onClick={() => setShowConfirmation(false)}
                  className="text-white/80 hover:text-white transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Progress bar */}
              <motion.div
                initial={{ scaleX: 1 }}
                animate={{ scaleX: 0 }}
                transition={{ duration: 8, ease: 'linear' }}
                className="absolute bottom-0 left-0 right-0 h-1 bg-white/40 origin-left"
              />
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Header */}
      <section className="relative bg-gradient-to-br from-[#10150f] to-[#1a1f1a] py-16 md:py-20 px-6 sm:px-8 lg:px-12">
        <div className="absolute inset-0 opacity-5">
          <div className="absolute inset-0" style={{
            backgroundImage: 'radial-gradient(circle at 2px 2px, white 1px, transparent 0)',
            backgroundSize: '40px 40px'
          }} />
        </div>
        <div className="max-w-7xl mx-auto relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="text-center"
          >
            <h1 className="text-3xl sm:text-4xl md:text-5xl text-white mb-4">
              Request a Custom Quote
            </h1>
            <p className="text-base sm:text-lg text-gray-300 max-w-2xl mx-auto">
              Tell us about your vehicle and the services you need. We'll respond with a tailored estimate within 24 hours.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Main Content */}
      <section className="py-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Unified Form - Left Side */}
            <div className="lg:col-span-2">
              <Card className="shadow-lg border-2 border-gray-100">
                <CardContent className="p-6 md:p-8">
                  <form onSubmit={handleSubmit} className="space-y-8">
                    {/* Personal Info */}
                    <div>
                      <h3 className="text-xl text-[#10150f] mb-4 flex items-center gap-2">
                        <span className="w-8 h-8 bg-[#8cc0d6] text-white rounded-full flex items-center justify-center text-sm">
                          1
                        </span>
                        Personal Information
                      </h3>
                      <div className="space-y-4">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div>
                            <Label htmlFor="name">Full Name *</Label>
                            <Input
                              id="name"
                              name="name"
                              value={formData.name}
                              onChange={handleChange}
                              placeholder="John Doe"
                              required
                              className="mt-1"
                            />
                          </div>
                          <div>
                            <Label htmlFor="email">Email *</Label>
                            <Input
                              id="email"
                              name="email"
                              type="email"
                              value={formData.email}
                              onChange={handleChange}
                              placeholder="john@example.com"
                              required
                              className="mt-1"
                            />
                          </div>
                        </div>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div>
                            <Label htmlFor="phone">Phone *</Label>
                            <Input
                              id="phone"
                              name="phone"
                              type="tel"
                              value={formData.phone}
                              onChange={handleChange}
                              placeholder="(555) 123-4567"
                              required
                              className="mt-1"
                            />
                          </div>
                          <div>
                            <Label htmlFor="address">Address *</Label>
                            <Input
                              id="address"
                              name="address"
                              value={formData.address}
                              onChange={handleChange}
                              placeholder="123 Main St, City, ST 12345"
                              required
                              className="mt-1"
                            />
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* Vehicle Info */}
                    <div className="border-t pt-6">
                      <h3 className="text-xl text-[#10150f] mb-4 flex items-center gap-2">
                        <span className="w-8 h-8 bg-[#8cc0d6] text-white rounded-full flex items-center justify-center text-sm">
                          2
                        </span>
                        Vehicle Information
                      </h3>
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                        <div>
                          <Label htmlFor="vehicleYear">Year *</Label>
                          <Input
                            id="vehicleYear"
                            name="vehicleYear"
                            value={formData.vehicleYear}
                            onChange={handleChange}
                            placeholder="2020"
                            required
                            className="mt-1"
                            maxLength={4}
                          />
                        </div>
                        <div>
                          <Label htmlFor="vehicleMake">Make *</Label>
                          <Input
                            id="vehicleMake"
                            name="vehicleMake"
                            value={formData.vehicleMake}
                            onChange={handleChange}
                            placeholder="Toyota"
                            required
                            className="mt-1"
                          />
                        </div>
                        <div>
                          <Label htmlFor="vehicleModel">Model *</Label>
                          <Input
                            id="vehicleModel"
                            name="vehicleModel"
                            value={formData.vehicleModel}
                            onChange={handleChange}
                            placeholder="Camry"
                            required
                            className="mt-1"
                          />
                        </div>
                        <div>
                          <Label htmlFor="vehicleColor">Color *</Label>
                          <Input
                            id="vehicleColor"
                            name="vehicleColor"
                            value={formData.vehicleColor}
                            onChange={handleChange}
                            placeholder="Silver"
                            required
                            className="mt-1"
                          />
                        </div>
                      </div>
                    </div>

                    {/* Service Selection */}
                    <div className="border-t pt-6">
                      <h3 className="text-xl text-[#10150f] mb-4 flex items-center gap-2">
                        <span className="w-8 h-8 bg-[#8cc0d6] text-white rounded-full flex items-center justify-center text-sm">
                          3
                        </span>
                        Services Needed
                      </h3>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                        {serviceOptions.map((service) => (
                          <div
                            key={service.id}
                            className={`
                              p-4 rounded-lg border-2 transition-all cursor-pointer
                              ${formData.services.includes(service.id)
                                ? 'border-[#56070f] bg-[#56070f]/5 shadow-md'
                                : 'border-gray-200 hover:border-[#8cc0d6]'
                              }
                            `}
                            onClick={() => toggleService(service.id)}
                          >
                            <div className="flex items-center justify-between">
                              <div className="flex items-center gap-3">
                                <Checkbox
                                  checked={formData.services.includes(service.id)}
                                  onCheckedChange={() => toggleService(service.id)}
                                  onClick={(e) => e.stopPropagation()}
                                />
                                <div>
                                  <p className="text-sm text-[#10150f]">{service.label}</p>
                                </div>
                              </div>
                              <span className="text-sm text-[#56070f]">${service.price}</span>
                            </div>
                          </div>
                        ))}
                      </div>

                      {/* Estimated Total */}
                      {formData.services.length > 0 && (
                        <motion.div
                          initial={{ opacity: 0, height: 0 }}
                          animate={{ opacity: 1, height: 'auto' }}
                          className="mt-4 p-4 bg-[#8cc0d6]/10 rounded-lg border border-[#8cc0d6]/30"
                        >
                          <div className="flex items-center justify-between">
                            <span className="text-sm text-gray-700">Estimated Total:</span>
                            <span className="text-2xl text-[#56070f]">${estimatedTotal}</span>
                          </div>
                          <p className="text-xs text-gray-500 mt-1">
                            Final price may vary based on vehicle condition
                          </p>
                        </motion.div>
                      )}
                    </div>

                    {/* Additional Details */}
                    <div className="border-t pt-6">
                      <Label htmlFor="description">Additional Details (Optional)</Label>
                      <Textarea
                        id="description"
                        name="description"
                        value={formData.description}
                        onChange={handleChange}
                        placeholder="Tell us about any specific concerns, stains, pet hair, or special requests..."
                        rows={4}
                        className="mt-2"
                      />
                    </div>

                    {/* Submit Button */}
                    <RippleButton
                      type="submit"
                      className="w-full bg-[#56070f] hover:bg-[#6e0912] text-white py-6 shadow-lg hover:shadow-xl transition-all"
                    >
                      Get My Custom Quote
                    </RippleButton>
                    <p className="text-xs text-gray-500 text-center">
                      By submitting, you agree to our terms of service. We'll respond within 24 hours.
                    </p>
                  </form>
                </CardContent>
              </Card>
            </div>

            {/* Contact Info - Right Side (Desktop) */}
            <div className="hidden lg:block space-y-6">
              {/* Phone */}
              <Card className="hover:shadow-lg transition-shadow border-2 border-transparent hover:border-[#8cc0d6]/30 group">
                <CardContent className="p-6">
                  <div className="flex items-start gap-4">
                    <div className="w-12 h-12 bg-[#8cc0d6]/10 rounded-full flex items-center justify-center flex-shrink-0 group-hover:scale-110 transition-transform duration-300">
                      <Phone className="w-6 h-6 text-[#8cc0d6] transition-transform duration-300 group-hover:rotate-[5deg]" />
                    </div>
                    <div>
                      <h3 className="text-lg text-[#10150f] mb-1">Call us</h3>
                      <a href="tel:+15551234567" className="text-[#56070f] hover:underline">
                        (555) 123-4567
                      </a>
                      <p className="text-sm text-gray-500 mt-1">Mon–Sat 8 AM–6 PM</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Email */}
              <Card className="hover:shadow-lg transition-shadow border-2 border-transparent hover:border-[#8cc0d6]/30 group">
                <CardContent className="p-6">
                  <div className="flex items-start gap-4">
                    <div className="w-12 h-12 bg-[#8cc0d6]/10 rounded-full flex items-center justify-center flex-shrink-0 group-hover:scale-110 transition-transform duration-300">
                      <Mail className="w-6 h-6 text-[#8cc0d6] transition-transform duration-300 group-hover:rotate-[5deg]" />
                    </div>
                    <div>
                      <h3 className="text-lg text-[#10150f] mb-1">Email</h3>
                      <a href="mailto:info@cruznclean.com" className="text-[#56070f] hover:underline break-all">
                        info@cruznclean.com
                      </a>
                      <p className="text-sm text-gray-500 mt-1">We reply within 24 hrs</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Hours */}
              <Card className="hover:shadow-lg transition-shadow border-2 border-transparent hover:border-[#8cc0d6]/30 group">
                <CardContent className="p-6">
                  <div className="flex items-start gap-4">
                    <div className="w-12 h-12 bg-[#8cc0d6]/10 rounded-full flex items-center justify-center flex-shrink-0 group-hover:scale-110 transition-transform duration-300">
                      <Clock className="w-6 h-6 text-[#8cc0d6] transition-transform duration-300 group-hover:rotate-[5deg]" />
                    </div>
                    <div>
                      <h3 className="text-lg text-[#10150f] mb-2">Business Hours</h3>
                      <div className="space-y-1 text-sm">
                        <div className="flex justify-between gap-4">
                          <span className="text-gray-600">Mon - Fri:</span>
                          <span className="text-[#10150f]">8am - 6pm</span>
                        </div>
                        <div className="flex justify-between gap-4">
                          <span className="text-gray-600">Saturday:</span>
                          <span className="text-[#10150f]">9am - 5pm</span>
                        </div>
                        <div className="flex justify-between gap-4">
                          <span className="text-gray-600">Sunday:</span>
                          <span className="text-[#10150f]">Closed</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Location */}
              <Card className="hover:shadow-lg transition-shadow border-2 border-transparent hover:border-[#8cc0d6]/30 group">
                <CardContent className="p-6">
                  <div className="flex items-start gap-4">
                    <div className="w-12 h-12 bg-[#8cc0d6]/10 rounded-full flex items-center justify-center flex-shrink-0 group-hover:scale-110 transition-transform duration-300">
                      <MapPin className="w-6 h-6 text-[#8cc0d6] transition-transform duration-300 group-hover:rotate-[5deg]" />
                    </div>
                    <div>
                      <h3 className="text-lg text-[#10150f] mb-1">Visit</h3>
                      <p className="text-gray-600 text-sm">
                        123 Auto Detail Lane<br />
                        Auto City, AC 12345
                      </p>
                      <a 
                        href="https://maps.google.com" 
                        target="_blank" 
                        rel="noopener noreferrer"
                        className="text-[#56070f] hover:underline text-sm mt-2 inline-block"
                      >
                        Get Directions →
                      </a>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Contact Info - Mobile Accordion */}
            <div className="lg:hidden">
              <Card className="shadow-lg">
                <CardContent className="p-0">
                  <Accordion type="single" collapsible className="w-full">
                    <AccordionItem value="contact" className="border-0">
                      <AccordionTrigger className="px-6 py-4 hover:no-underline hover:bg-gray-50">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 bg-[#8cc0d6]/10 rounded-full flex items-center justify-center">
                            <Phone className="w-5 h-5 text-[#8cc0d6]" />
                          </div>
                          <span className="text-[#10150f]">Contact Information</span>
                        </div>
                      </AccordionTrigger>
                      <AccordionContent className="px-6 pb-6">
                        <div className="space-y-6">
                          {/* Phone */}
                          <div className="flex items-start gap-4 pb-6 border-b">
                            <div className="w-10 h-10 bg-[#8cc0d6]/10 rounded-full flex items-center justify-center flex-shrink-0">
                              <Phone className="w-5 h-5 text-[#8cc0d6]" />
                            </div>
                            <div>
                              <h4 className="text-sm text-gray-500 mb-1">Call us</h4>
                              <a href="tel:+15551234567" className="text-[#56070f] hover:underline">
                                (555) 123-4567
                              </a>
                              <p className="text-xs text-gray-500 mt-1">Mon–Sat 8 AM–6 PM</p>
                            </div>
                          </div>

                          {/* Email */}
                          <div className="flex items-start gap-4 pb-6 border-b">
                            <div className="w-10 h-10 bg-[#8cc0d6]/10 rounded-full flex items-center justify-center flex-shrink-0">
                              <Mail className="w-5 h-5 text-[#8cc0d6]" />
                            </div>
                            <div>
                              <h4 className="text-sm text-gray-500 mb-1">Email</h4>
                              <a href="mailto:info@cruznclean.com" className="text-[#56070f] hover:underline break-all">
                                info@cruznclean.com
                              </a>
                              <p className="text-xs text-gray-500 mt-1">We reply within 24 hrs</p>
                            </div>
                          </div>

                          {/* Hours */}
                          <div className="flex items-start gap-4 pb-6 border-b">
                            <div className="w-10 h-10 bg-[#8cc0d6]/10 rounded-full flex items-center justify-center flex-shrink-0">
                              <Clock className="w-5 h-5 text-[#8cc0d6]" />
                            </div>
                            <div>
                              <h4 className="text-sm text-gray-500 mb-2">Business Hours</h4>
                              <div className="space-y-1 text-sm">
                                <div className="flex justify-between gap-8">
                                  <span className="text-gray-600">Mon - Fri:</span>
                                  <span className="text-[#10150f]">8am - 6pm</span>
                                </div>
                                <div className="flex justify-between gap-8">
                                  <span className="text-gray-600">Saturday:</span>
                                  <span className="text-[#10150f]">9am - 5pm</span>
                                </div>
                                <div className="flex justify-between gap-8">
                                  <span className="text-gray-600">Sunday:</span>
                                  <span className="text-[#10150f]">Closed</span>
                                </div>
                              </div>
                            </div>
                          </div>

                          {/* Location */}
                          <div className="flex items-start gap-4">
                            <div className="w-10 h-10 bg-[#8cc0d6]/10 rounded-full flex items-center justify-center flex-shrink-0">
                              <MapPin className="w-5 h-5 text-[#8cc0d6]" />
                            </div>
                            <div>
                              <h4 className="text-sm text-gray-500 mb-1">Visit</h4>
                              <p className="text-gray-600 text-sm">
                                123 Auto Detail Lane<br />
                                Auto City, AC 12345
                              </p>
                              <a 
                                href="https://maps.google.com" 
                                target="_blank" 
                                rel="noopener noreferrer"
                                className="text-[#56070f] hover:underline text-sm mt-2 inline-block"
                              >
                                Get Directions →
                              </a>
                            </div>
                          </div>
                        </div>
                      </AccordionContent>
                    </AccordionItem>
                  </Accordion>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
