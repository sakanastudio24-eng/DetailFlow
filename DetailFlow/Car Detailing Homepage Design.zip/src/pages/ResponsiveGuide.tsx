import { motion } from 'motion/react';
import { Monitor, Tablet, Smartphone, CheckCircle2 } from 'lucide-react';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '../components/ui/card';
import { Separator } from '../components/ui/separator';
import { Badge } from '../components/ui/badge';

export function ResponsiveGuide() {
  const breakpoints = [
    { 
      name: 'Desktop', 
      width: '1440px', 
      icon: Monitor,
      color: '#56070f',
      description: 'Full-width layouts, multi-column grids, all features visible'
    },
    { 
      name: 'Tablet', 
      width: '768px', 
      icon: Tablet,
      color: '#8cc0d6',
      description: '2-column grids, stacked navigation, optimized spacing'
    },
    { 
      name: 'Mobile', 
      width: '390px', 
      icon: Smartphone,
      color: '#10150f',
      description: 'Single-column layouts, larger buttons, full-width elements'
    }
  ];

  const responsiveBehaviors = [
    {
      component: 'Hero Section',
      behaviors: [
        'Text scales from 3xl → 4xl → 5xl → 6xl → 7xl → 8xl',
        'Buttons become full-width on mobile with larger tap targets (py-5)',
        'Quick stats reduce size and spacing on smaller screens',
        'Hero CTA stack vertically on mobile'
      ]
    },
    {
      component: 'Package Cards',
      behaviors: [
        'Grid: 1 column (mobile) → 2 columns (tablet) → 3 columns (desktop)',
        'Card padding reduces on mobile (p-6 → p-8)',
        'Price text scales responsively (text-4xl → text-5xl)',
        'Feature list spacing adjusts (space-y-3 → space-y-4)'
      ]
    },
    {
      component: 'Booking Widget',
      behaviors: [
        'Package filters stack vertically on mobile',
        'Package buttons show horizontal layout (price on right) on mobile',
        'Calendar widget single-column with reduced min-height',
        'Selected package indicator stacks on mobile',
        'Confirm button becomes full-width with larger padding'
      ]
    },
    {
      component: 'Navigation',
      behaviors: [
        'Desktop: Horizontal menu with all links visible',
        'Mobile: Hamburger menu with slide-down panel',
        'Mobile menu has larger touch targets (py-3-4)',
        '"Book Now" button emphasized in mobile menu'
      ]
    },
    {
      component: 'Services Grid',
      behaviors: [
        'Grid: 1 column (mobile) → 2 columns (tablet) → 3 columns (desktop)',
        'Service cards maintain consistent aspect ratio',
        'Add/Remove buttons adjust size on mobile'
      ]
    },
    {
      component: 'Button Sizes',
      behaviors: [
        'Mobile: py-4 to py-5 for better tap targets',
        'Desktop: py-3 standard size',
        'Text: text-base on mobile → text-sm on desktop',
        'Full-width buttons on mobile for primary CTAs'
      ]
    },
    {
      component: 'Typography',
      behaviors: [
        'H1: text-3xl (mobile) → text-8xl (desktop)',
        'Body: text-base (mobile) → text-lg (desktop)',
        'Line height increases proportionally',
        'Padding adjusts: px-4 (mobile) → no constraint (desktop)'
      ]
    }
  ];

  const interactionFeatures = [
    {
      feature: 'Smooth Scroll to Booking',
      description: 'All "Book Now" buttons smoothly scroll to the Contact page booking section',
      implementation: 'window.location.hash = "contact" triggers page navigation'
    },
    {
      feature: 'Touch-Friendly Targets',
      description: 'Minimum 44x44px tap targets on mobile for accessibility',
      implementation: 'py-4 or py-5 padding on mobile buttons'
    },
    {
      feature: 'Responsive Images',
      description: 'Images scale fluidly without breaking layouts',
      implementation: 'object-cover classes with proper aspect ratios'
    },
    {
      feature: 'Adaptive Grids',
      description: 'Grid layouts automatically adjust columns based on screen size',
      implementation: 'grid-cols-1 md:grid-cols-2 lg:grid-cols-3 pattern'
    }
  ];

  return (
    <div className="min-h-screen pt-20 bg-white">
      {/* Header */}
      <section className="relative bg-[#10150f] py-24 px-4">
        <div className="max-w-6xl mx-auto text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <h1 className="text-4xl md:text-6xl text-white mb-6">
              Responsive <span className="text-[#8cc0d6]">Design</span>
            </h1>
            <p className="text-xl text-gray-300 max-w-2xl mx-auto">
              Built with auto-layout for seamless experiences across all devices
            </p>
          </motion.div>
        </div>
      </section>

      <div className="max-w-6xl mx-auto px-4 py-16 space-y-16">
        {/* Breakpoints */}
        <section>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="mb-12"
          >
            <h2 className="text-3xl md:text-4xl text-[#10150f] mb-3">Target Breakpoints</h2>
            <p className="text-gray-600">
              Optimized layouts for three primary device categories
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {breakpoints.map((bp, index) => {
              const Icon = bp.icon;
              return (
                <motion.div
                  key={bp.name}
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: index * 0.1 }}
                >
                  <Card className="hover:shadow-lg transition-shadow h-full">
                    <CardContent className="pt-6">
                      <div 
                        className="w-16 h-16 rounded-full flex items-center justify-center mb-4 mx-auto"
                        style={{ backgroundColor: `${bp.color}15` }}
                      >
                        <Icon className="w-8 h-8" style={{ color: bp.color }} />
                      </div>
                      <h3 className="text-xl text-[#10150f] mb-2 text-center">{bp.name}</h3>
                      <div className="text-center mb-4">
                        <Badge variant="outline" className="text-sm">
                          {bp.width}
                        </Badge>
                      </div>
                      <p className="text-sm text-gray-600 text-center">
                        {bp.description}
                      </p>
                    </CardContent>
                  </Card>
                </motion.div>
              );
            })}
          </div>
        </section>

        <Separator />

        {/* Responsive Behaviors */}
        <section>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="mb-12"
          >
            <h2 className="text-3xl md:text-4xl text-[#10150f] mb-3">Component Behaviors</h2>
            <p className="text-gray-600">
              How each component adapts across breakpoints
            </p>
          </motion.div>

          <div className="space-y-6">
            {responsiveBehaviors.map((item, index) => (
              <motion.div
                key={item.component}
                initial={{ opacity: 0, x: -20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.05 }}
              >
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <span className="text-[#56070f]">•</span>
                      {item.component}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ul className="space-y-2">
                      {item.behaviors.map((behavior, idx) => (
                        <li key={idx} className="flex items-start gap-3">
                          <CheckCircle2 className="w-5 h-5 text-[#8cc0d6] flex-shrink-0 mt-0.5" />
                          <span className="text-gray-700 text-sm">{behavior}</span>
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </section>

        <Separator />

        {/* Interaction Features */}
        <section>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="mb-12"
          >
            <h2 className="text-3xl md:text-4xl text-[#10150f] mb-3">Interactive Features</h2>
            <p className="text-gray-600">
              Enhanced user experience through thoughtful interactions
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {interactionFeatures.map((item, index) => (
              <motion.div
                key={item.feature}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
              >
                <Card className="h-full hover:shadow-lg transition-shadow">
                  <CardHeader>
                    <CardTitle className="text-lg">{item.feature}</CardTitle>
                    <CardDescription>{item.description}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="bg-gray-50 p-3 rounded-lg">
                      <code className="text-xs text-gray-700">
                        {item.implementation}
                      </code>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </section>

        {/* Tailwind Classes Reference */}
        <section className="bg-[#f8f8f8] rounded-2xl p-8 md:p-12">
          <h2 className="text-3xl md:text-4xl text-[#10150f] mb-6">Responsive Utilities</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <h3 className="text-lg text-[#10150f] mb-3">Grid Patterns</h3>
              <div className="space-y-2 text-sm">
                <div className="flex items-center gap-2">
                  <code className="bg-white px-2 py-1 rounded text-xs">grid-cols-1</code>
                  <span className="text-gray-600">Mobile (390px)</span>
                </div>
                <div className="flex items-center gap-2">
                  <code className="bg-white px-2 py-1 rounded text-xs">md:grid-cols-2</code>
                  <span className="text-gray-600">Tablet (768px+)</span>
                </div>
                <div className="flex items-center gap-2">
                  <code className="bg-white px-2 py-1 rounded text-xs">lg:grid-cols-3</code>
                  <span className="text-gray-600">Desktop (1024px+)</span>
                </div>
              </div>
            </div>

            <div>
              <h3 className="text-lg text-[#10150f] mb-3">Text Scaling</h3>
              <div className="space-y-2 text-sm">
                <div className="flex items-center gap-2">
                  <code className="bg-white px-2 py-1 rounded text-xs">text-3xl</code>
                  <span className="text-gray-600">Mobile base</span>
                </div>
                <div className="flex items-center gap-2">
                  <code className="bg-white px-2 py-1 rounded text-xs">md:text-5xl</code>
                  <span className="text-gray-600">Tablet scale</span>
                </div>
                <div className="flex items-center gap-2">
                  <code className="bg-white px-2 py-1 rounded text-xs">lg:text-7xl</code>
                  <span className="text-gray-600">Desktop large</span>
                </div>
              </div>
            </div>

            <div>
              <h3 className="text-lg text-[#10150f] mb-3">Button Sizing</h3>
              <div className="space-y-2 text-sm">
                <div className="flex items-center gap-2">
                  <code className="bg-white px-2 py-1 rounded text-xs">py-5</code>
                  <span className="text-gray-600">Mobile (larger tap)</span>
                </div>
                <div className="flex items-center gap-2">
                  <code className="bg-white px-2 py-1 rounded text-xs">md:py-3</code>
                  <span className="text-gray-600">Desktop (standard)</span>
                </div>
                <div className="flex items-center gap-2">
                  <code className="bg-white px-2 py-1 rounded text-xs">w-full sm:w-auto</code>
                  <span className="text-gray-600">Adaptive width</span>
                </div>
              </div>
            </div>

            <div>
              <h3 className="text-lg text-[#10150f] mb-3">Spacing</h3>
              <div className="space-y-2 text-sm">
                <div className="flex items-center gap-2">
                  <code className="bg-white px-2 py-1 rounded text-xs">gap-4</code>
                  <span className="text-gray-600">Mobile spacing</span>
                </div>
                <div className="flex items-center gap-2">
                  <code className="bg-white px-2 py-1 rounded text-xs">md:gap-6</code>
                  <span className="text-gray-600">Tablet spacing</span>
                </div>
                <div className="flex items-center gap-2">
                  <code className="bg-white px-2 py-1 rounded text-xs">lg:gap-8</code>
                  <span className="text-gray-600">Desktop spacing</span>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Testing Instructions */}
        <section>
          <Card className="border-2 border-[#8cc0d6]">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <CheckCircle2 className="w-6 h-6 text-[#8cc0d6]" />
                Testing Guide
              </CardTitle>
              <CardDescription>
                How to validate responsive behavior
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ol className="space-y-3 list-decimal list-inside text-gray-700">
                <li>Open browser DevTools (F12 or Cmd+Opt+I)</li>
                <li>Enable device toolbar / responsive mode</li>
                <li>Test at 390px (iPhone), 768px (iPad), and 1440px (Desktop)</li>
                <li>Verify all "Book Now" buttons navigate to Contact page</li>
                <li>Check touch targets are at least 44x44px on mobile</li>
                <li>Ensure text scales proportionally without overflow</li>
                <li>Validate grids stack correctly at each breakpoint</li>
                <li>Test mobile navigation menu opens and closes smoothly</li>
              </ol>
            </CardContent>
          </Card>
        </section>
      </div>
    </div>
  );
}
