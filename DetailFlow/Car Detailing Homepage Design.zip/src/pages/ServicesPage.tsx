import { motion } from 'motion/react';
import { 
  Lightbulb, 
  Wind, 
  Sparkles, 
  Shield, 
  PawPrint, 
  Droplet, 
  Waves,
  Car,
  Paintbrush,
  AlertCircle,
  Scissors,
  ThermometerSun,
  Plus,
  Check
} from 'lucide-react';
import { Card, CardContent } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { useCart } from '../context/CartContext';

const services = [
  {
    id: 'headlight',
    name: 'Headlight Restoration',
    description: 'Crystal clear headlights with UV protection coating',
    icon: Lightbulb,
    price: 75,
    duration: '45 min',
    color: '#8cc0d6'
  },
  {
    id: 'engine-bay',
    name: 'Engine Bay Detail',
    description: 'Deep clean and dress engine compartment',
    icon: Wind,
    price: 100,
    duration: '1 hour',
    color: '#56070f'
  },
  {
    id: 'ceramic-coating',
    name: 'Ceramic Coating',
    description: 'Long-lasting paint protection with hydrophobic properties',
    icon: Shield,
    price: 500,
    duration: '4-6 hours',
    color: '#8cc0d6'
  },
  {
    id: 'odor-elimination',
    name: 'Odor Elimination',
    description: 'Ozone treatment removes smoke and pet odors',
    icon: Wind,
    price: 125,
    duration: '2 hours',
    color: '#56070f'
  },
  {
    id: 'pet-hair-removal',
    name: 'Pet Hair Removal',
    description: 'Specialized tools to remove stubborn pet hair',
    icon: PawPrint,
    price: 80,
    duration: '1 hour',
    color: '#8cc0d6'
  },
  {
    id: 'water-spot-removal',
    name: 'Water Spot Removal',
    description: 'Eliminate hard water stains from paint and glass',
    icon: Droplet,
    price: 90,
    duration: '1.5 hours',
    color: '#56070f'
  },
  {
    id: 'clay-bar-treatment',
    name: 'Clay Bar Treatment',
    description: 'Remove embedded contaminants for smooth paint',
    icon: Waves,
    price: 85,
    duration: '1 hour',
    color: '#8cc0d6'
  },
  {
    id: 'scratch-removal',
    name: 'Scratch Removal',
    description: 'Minor scratch buffing and paint correction',
    icon: AlertCircle,
    price: 150,
    duration: '2-3 hours',
    color: '#56070f'
  },
  {
    id: 'trim-restoration',
    name: 'Trim Restoration',
    description: 'Restore faded plastic and rubber trim pieces',
    icon: Paintbrush,
    price: 70,
    duration: '45 min',
    color: '#8cc0d6'
  },
  {
    id: 'wheel-ceramic',
    name: 'Wheel Ceramic Coating',
    description: 'Protect wheels with ceramic coating',
    icon: Car,
    price: 200,
    duration: '2 hours',
    color: '#56070f'
  },
  {
    id: 'leather-repair',
    name: 'Leather Repair',
    description: 'Professional restoration of tears and worn leather',
    icon: Scissors,
    price: 150,
    duration: '2 hours',
    color: '#8cc0d6'
  },
  {
    id: 'ac-sanitization',
    name: 'Climate Control Sanitization',
    description: 'Deep clean and sanitize AC vents and system',
    icon: ThermometerSun,
    price: 70,
    duration: '45 min',
    color: '#56070f'
  }
];

export function ServicesPage() {
  const { items, addItem, removeItem } = useCart();

  const isInCart = (serviceId: string) => {
    return items.some(item => item.id === serviceId);
  };

  const toggleService = (service: typeof services[0]) => {
    if (isInCart(service.id)) {
      removeItem(service.id);
    } else {
      addItem({
        id: service.id,
        name: service.name,
        price: service.price,
        type: 'service'
      });
    }
  };

  return (
    <div className="min-h-screen pt-20 bg-white">
      {/* Header */}
      <section className="bg-[#10150f] py-16 md:py-20 px-4">
        <div className="max-w-6xl mx-auto text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <h1 className="text-3xl sm:text-4xl md:text-5xl text-white mb-4">
              Additional Services
            </h1>
            <p className="text-base sm:text-lg text-gray-300 max-w-2xl mx-auto">
              Enhance your detail with our premium add-on services
            </p>
          </motion.div>
        </div>
      </section>

      {/* Services Grid */}
      <section className="py-16 px-4 bg-[#f8f8f8]">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {services.map((service, index) => {
              const Icon = service.icon;
              const inCart = isInCart(service.id);

              return (
                <motion.div
                  key={service.id}
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.5, delay: index * 0.05 }}
                >
                  <Card className={`h-full hover:shadow-xl transition-all ${inCart ? 'ring-2' : ''}`} style={inCart ? { ringColor: service.color } : {}}>
                    <CardContent className="p-6">
                      {/* Icon */}
                      <div 
                        className="w-16 h-16 rounded-xl flex items-center justify-center mb-4"
                        style={{ backgroundColor: `${service.color}15` }}
                      >
                        <Icon className="w-8 h-8" style={{ color: service.color }} />
                      </div>

                      {/* Name and Price */}
                      <h3 className="text-xl text-[#10150f] mb-2">
                        {service.name}
                      </h3>
                      <div className="flex items-center justify-between mb-3">
                        <span className="text-2xl" style={{ color: service.color }}>
                          ${service.price}
                        </span>
                        <span className="text-sm text-gray-500">{service.duration}</span>
                      </div>

                      {/* Description */}
                      <p className="text-gray-600 text-sm mb-4">
                        {service.description}
                      </p>

                      {/* Add/Remove Button */}
                      <Button
                        onClick={() => toggleService(service)}
                        className={`w-full ${
                          inCart
                            ? 'bg-green-600 hover:bg-green-700'
                            : 'bg-[#56070f] hover:bg-[#56070f]/90'
                        }`}
                      >
                        {inCart ? (
                          <>
                            <Check className="w-4 h-4 mr-2" />
                            Added to Cart
                          </>
                        ) : (
                          <>
                            <Plus className="w-4 h-4 mr-2" />
                            Add to Cart
                          </>
                        )}
                      </Button>
                    </CardContent>
                  </Card>
                </motion.div>
              );
            })}
          </div>
        </div>
      </section>
    </div>
  );
}
