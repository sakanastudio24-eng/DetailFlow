import { motion } from 'motion/react';

export function TermsOfService() {
  return (
    <div className="min-h-screen pt-20 pb-20 md:pb-8 bg-[#f8f8f8]">
      {/* Header */}
      <section className="bg-gradient-to-br from-[#10150f] to-[#10150f]/90 py-12 md:py-16 px-6 sm:px-8 lg:px-12 relative overflow-hidden">
        <div className="absolute inset-0 opacity-5">
          <div className="absolute inset-0" style={{
            backgroundImage: 'radial-gradient(circle at 2px 2px, white 1px, transparent 0)',
            backgroundSize: '40px 40px'
          }} />
        </div>
        <div className="max-w-4xl mx-auto text-center relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <h1 className="text-3xl sm:text-4xl md:text-5xl text-white mb-4">
              Terms of Service
            </h1>
            <p className="text-base sm:text-lg text-gray-300 max-w-2xl mx-auto">
              Last Updated: October 25, 2025
            </p>
          </motion.div>
        </div>
      </section>

      {/* Content */}
      <section className="py-8 md:py-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="bg-white rounded-2xl shadow-xl p-6 sm:p-8 md:p-12 space-y-8"
          >
            {/* Introduction */}
            <div>
              <h2 className="text-2xl text-[#10150f] mb-4">1. Agreement to Terms</h2>
              <p className="text-gray-700 leading-relaxed">
                By accessing and using Cruzn Clean's services, you agree to be bound by these Terms of Service and all applicable laws and regulations. If you do not agree with any of these terms, you are prohibited from using our services.
              </p>
            </div>

            {/* Services */}
            <div>
              <h2 className="text-2xl text-[#10150f] mb-4">2. Services Provided</h2>
              <p className="text-gray-700 leading-relaxed mb-3">
                Cruzn Clean provides professional automotive detailing services including but not limited to:
              </p>
              <ul className="list-disc list-inside space-y-2 text-gray-700 ml-4">
                <li>Exterior washing and detailing</li>
                <li>Interior cleaning and detailing</li>
                <li>Ceramic coating applications</li>
                <li>Paint correction and protection</li>
                <li>Headlight restoration</li>
                <li>Additional specialty services as listed on our website</li>
              </ul>
            </div>

            {/* Appointments and Cancellations */}
            <div>
              <h2 className="text-2xl text-[#10150f] mb-4">3. Appointments and Cancellations</h2>
              <p className="text-gray-700 leading-relaxed mb-3">
                <strong>Booking:</strong> All services must be scheduled in advance through our online booking system or by phone.
              </p>
              <p className="text-gray-700 leading-relaxed mb-3">
                <strong>Cancellation Policy:</strong> Appointments may be cancelled or rescheduled up to 24 hours before the scheduled time without penalty. Cancellations made less than 24 hours in advance may be subject to a cancellation fee of up to 50% of the service cost.
              </p>
              <p className="text-gray-700 leading-relaxed">
                <strong>No-Show Policy:</strong> Customers who fail to show up for their scheduled appointment without prior notice will be charged the full service fee.
              </p>
            </div>

            {/* Payment Terms */}
            <div>
              <h2 className="text-2xl text-[#10150f] mb-4">4. Payment Terms</h2>
              <p className="text-gray-700 leading-relaxed mb-3">
                Payment for all services is due upon completion of work. We accept cash, credit cards, and digital payment methods. All prices are subject to change without notice, though quoted prices will be honored for scheduled appointments.
              </p>
              <p className="text-gray-700 leading-relaxed">
                Payment will be accepted on site after work has been completed.
              </p>
            </div>

            {/* Vehicle Condition and Liability */}
            <div>
              <h2 className="text-2xl text-[#10150f] mb-4">5. Vehicle Condition and Liability</h2>
              <p className="text-gray-700 leading-relaxed mb-3">
                <strong>Pre-existing Damage:</strong> Customers must disclose any pre-existing damage, paint defects, or mechanical issues prior to service. Cruzn Clean is not responsible for damage that existed before service or damage resulting from poor previous repairs.
              </p>
              <p className="text-gray-700 leading-relaxed mb-3">
                <strong>Personal Property:</strong> Please remove all personal belongings from your vehicle before service. Cruzn Clean is not responsible for lost, stolen, or damaged personal items left in the vehicle.
              </p>
              <p className="text-gray-700 leading-relaxed">
                <strong>Insurance:</strong> Cruzn Clean maintains comprehensive liability insurance. In the unlikely event of damage during service, we will work with you to resolve the issue promptly and fairly.
              </p>
            </div>

            {/* Service Guarantee */}
            <div>
              <h2 className="text-2xl text-[#10150f] mb-4">6. Service Guarantee</h2>
              <p className="text-gray-700 leading-relaxed mb-3">
                We stand behind the quality of our work. If you are not satisfied with any service, please contact us within 48 hours of completion. We will either re-perform the service at no additional charge or provide a refund at our discretion.
              </p>
              <p className="text-gray-700 leading-relaxed">
                Warranty periods for specific services (such as ceramic coatings) will be provided in writing at the time of service.
              </p>
            </div>

            {/* Weather and Force Majeure */}
            <div>
              <h2 className="text-2xl text-[#10150f] mb-4">7. Weather and Force Majeure</h2>
              <p className="text-gray-700 leading-relaxed">
                Certain services may be weather-dependent. We reserve the right to reschedule appointments due to inclement weather, acts of God, or other circumstances beyond our control. In such cases, no cancellation fees will apply, and we will work with you to reschedule at your earliest convenience.
              </p>
            </div>

            {/* Limitation of Liability */}
            <div>
              <h2 className="text-2xl text-[#10150f] mb-4">8. Limitation of Liability</h2>
              <p className="text-gray-700 leading-relaxed">
                Cruzn Clean's liability for any claim related to our services shall not exceed the amount paid for the specific service in question. We are not liable for indirect, incidental, or consequential damages.
              </p>
            </div>

            {/* Intellectual Property */}
            <div>
              <h2 className="text-2xl text-[#10150f] mb-4">9. Intellectual Property</h2>
              <p className="text-gray-700 leading-relaxed">
                All content on the Cruzn Clean website, including text, graphics, logos, images, and software, is the property of Cruzn Clean and protected by copyright laws. Unauthorized use of any materials may violate copyright, trademark, and other laws.
              </p>
            </div>

            {/* Photography and Marketing */}
            <div>
              <h2 className="text-2xl text-[#10150f] mb-4">10. Photography and Marketing</h2>
              <p className="text-gray-700 leading-relaxed">
                By using our services, you grant Cruzn Clean permission to photograph your vehicle and use such photographs for marketing and promotional purposes unless you explicitly opt out in writing.
              </p>
            </div>

            {/* Modifications to Terms */}
            <div>
              <h2 className="text-2xl text-[#10150f] mb-4">11. Modifications to Terms</h2>
              <p className="text-gray-700 leading-relaxed">
                Cruzn Clean reserves the right to modify these Terms of Service at any time. Changes will be effective immediately upon posting to our website. Your continued use of our services after changes are posted constitutes acceptance of the modified terms.
              </p>
            </div>

            {/* Governing Law */}
            <div>
              <h2 className="text-2xl text-[#10150f] mb-4">12. Governing Law</h2>
              <p className="text-gray-700 leading-relaxed">
                These Terms of Service shall be governed by and construed in accordance with the laws of the state in which Cruzn Clean operates, without regard to its conflict of law provisions.
              </p>
            </div>

            {/* Contact */}
            <div className="pt-6 border-t border-gray-200">
              <h2 className="text-2xl text-[#10150f] mb-4">Contact Us</h2>
              <p className="text-gray-700 leading-relaxed mb-2">
                If you have any questions about these Terms of Service, please contact us:
              </p>
              <ul className="space-y-2 text-gray-700">
                <li><strong>Email:</strong> info@cruznclean.com</li>
                <li><strong>Phone:</strong> +1 (555) 123-4567</li>
                <li><strong>Address:</strong> 123 Detail Street, Auto City, AC 12345</li>
              </ul>
            </div>
          </motion.div>
        </div>
      </section>
    </div>
  );
}
