import { Hero } from '../components/Hero';
import { Services } from '../components/Services';
import { WaveDivider } from '../components/WaveDivider';
import BeforeAfterSlider from '../components/BeforeAfterSlider';

export function Home() {
  const scrollToBooking = () => {
    window.location.hash = 'booking';
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <>
      <div className="pb-8 md:pb-0">
      {/* Hero Section */}
      <Hero onBookNowClick={scrollToBooking} />

      {/* Services Section */}
      <Services />

      {/* Before & After Showcase */}
      <BeforeAfterSlider />
      </div>
    </>
  );
}
