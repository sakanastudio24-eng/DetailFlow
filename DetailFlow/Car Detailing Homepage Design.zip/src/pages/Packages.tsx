import { motion } from 'motion/react';
import { useState, useEffect } from 'react';
import { Check, Plus, ArrowRight, Sparkles, Droplet, Shield, Lightbulb, Wind, PawPrint, Waves, AlertCircle, Paintbrush, Car, Scissors, ThermometerSun, HelpCircle, ExternalLink, Phone } from 'lucide-react';
import { useCart } from '../context/CartContext';
import { RippleButton } from '../components/ui/ripple-button';
import { Button } from '../components/ui/button';
import { Card, CardContent } from '../components/ui/card';
import { VehicleDock } from '../components/VehicleDock';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from '../components/ui/accordion';

type VehicleSize = 'small' | 'medium' | 'large';

const packages = [
  {
    id: 'basic',
    name: 'Basic Detail',
    icon: Sparkles,
    description: 'Essential maintenance for everyday shine.',
    duration: '2–3 hrs',
    features: [
      'Hand wash & dry',
      'Wheel & tire clean',
      'Interior vacuum & wipe-down'
    ],
    pricing: {
      small: 99,
      medium: 119,
      large: 139
    },
    color: '#8cc0d6'
  },
  {
    id: 'standard',
    name: 'Standard Detail',
    icon: Droplet,
    description: 'Full-service refresh inside & out.',
    duration: '4 hrs',
    features: [
      'Everything in Basic',
      'Clay-bar treatment',
      'Machine polish',
      'Engine bay clean'
    ],
    pricing: {
      small: 189,
      medium: 229,
      large: 269
    },
    color: '#56070f',
    popular: true
  },
  {
    id: 'premium',
    name: 'Premium Detail',
    icon: Shield,
    description: 'Ultimate protection & showroom finish.',
    duration: '6 hrs',
    features: [
      'Everything in Standard',
      'Paint correction & ceramic coating',
      'Interior shampoo & odor removal',
      '6-month protection guarantee'
    ],
    pricing: {
      small: 349,
      medium: 429,
      large: 509
    },
    color: '#1a3a52'
  }
];

const additionalServices = [
  { id: 'headlight', name: 'Headlight Restoration', icon: Lightbulb, price: 75, duration: '45 min' },
  { id: 'engine-bay', name: 'Engine Bay Detail', icon: Wind, price: 100, duration: '1 hr' },
  { id: 'pet-hair-removal', name: 'Pet Hair Removal', icon: PawPrint, price: 80, duration: '1 hr' },
  { id: 'water-spot-removal', name: 'Water Spot Removal', icon: Droplet, price: 90, duration: '1.5 hr' },
  { id: 'scratch-removal', name: 'Scratch Removal', icon: AlertCircle, price: 150, duration: '2 hr' },
  { id: 'clay-bar-treatment', name: 'Clay Bar Treatment', icon: Waves, price: 85, duration: '1 hr' },
  { id: 'trim-restoration', name: 'Trim Restoration', icon: Paintbrush, price: 70, duration: '45 min' },
  { id: 'wheel-ceramic', name: 'Wheel Ceramic Coating', icon: Car, price: 200, duration: '2 hr' },
  { id: 'leather-repair', name: 'Leather Repair', icon: Scissors, price: 150, duration: '2 hr' },
  { id: 'odor-elimination', name: 'Odor Elimination', icon: Wind, price: 125, duration: '2 hr' },
  { id: 'ceramic-coating', name: 'Ceramic Coating', icon: Shield, price: 500, duration: '4–6 hr' },
  { id: 'ac-sanitization', name: 'Climate Control Sanitization', icon: ThermometerSun, price: 70, duration: '45 min' }
];

const vehicleSizes = [
  { id: 'small' as VehicleSize, label: 'Small', examples: 'Sedan / Coupe' },
  { id: 'medium' as VehicleSize, label: 'Medium', examples: 'SUV / Crossover' },
  { id: 'large' as VehicleSize, label: 'Large', examples: 'Truck / Van' }
];

export function Packages() {
  const [selectedSize, setSelectedSize] = useState<VehicleSize>('small');
  const { items, addItem, removeItem, openDock } = useCart();

  // Auto-open the Vehicle Dock when this page loads
  useEffect(() => {
    openDock();
  }, []);

  const isInCart = (itemId: string) => {
    return items.some(item => item.id === itemId);
  };

  const handleAddPackage = (pkg: typeof packages[0]) => {
    const packageId = `${pkg.id}-${selectedSize}`;
    if (isInCart(packageId)) {
      removeItem(packageId);
    } else {
      addItem({
        id: packageId,
        name: `${pkg.name} - ${vehicleSizes.find(s => s.id === selectedSize)?.label}`,
        price: pkg.pricing[selectedSize],
        type: 'package'
      });
    }
  };

  const toggleService = (service: typeof additionalServices[0]) => {
    if (isInCart(service.id)) {
      removeItem(service.id);
    } else {
      addItem({
        id: service.id,
        name: service.name,
        price: service.price,
        type: 'service'
      });
    }
  };

  return (
    <>
      <VehicleDock />
      <div className="min-h-screen pt-20 pb-32 md:pb-24 lg:pr-[360px] bg-gradient-to-b from-white via-[#f8f8f8] to-white">
        {/* Header */}
      <section className="bg-gradient-to-br from-[#10150f] to-[#1a1f1a] py-16 md:py-20 px-6 sm:px-8 lg:px-12">
        <div className="max-w-6xl mx-auto text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <h1 className="text-3xl sm:text-4xl md:text-5xl text-white mb-4">
              Our Detailing Packages
            </h1>
            <p className="text-base sm:text-lg text-gray-300 max-w-2xl mx-auto">
              Choose the perfect service for your vehicle size and condition.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Vehicle Size Selector */}
      <section className="pt-10 pb-14 md:pt-12 md:pb-16 lg:pt-16 lg:pb-20 px-6 md:px-8 lg:px-10 bg-gradient-to-b from-[#f8f8f8] to-white border-b border-gray-200 shadow-sm">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-6">
            <h2 className="text-xl sm:text-2xl text-[#10150f] mb-2">
              Select Your Vehicle Size
            </h2>
            <p className="text-sm text-gray-600">Watch prices update automatically below ↓</p>
          </div>
          
          <motion.div 
            className="grid grid-cols-1 gap-y-8 gap-x-6 max-w-4xl mx-auto [@media(min-width:1164px)]:grid-cols-3 [@media(min-width:769px)and(max-width:1163px)]:grid-cols-3"
            layout
          >
            {vehicleSizes.map((size, index) => (
              <motion.button
                key={size.id}
                onClick={() => setSelectedSize(size.id)}
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                className={`p-5 rounded-xl border-2 transition-all duration-300 min-h-[100px] flex items-center justify-center ${
                  selectedSize === size.id
                    ? 'border-[#56070f] bg-[#56070f]/5 shadow-lg'
                    : 'border-gray-200 bg-white hover:border-[#8cc0d6] hover:shadow-md'
                } ${
                  index === 2 ? '[@media(min-width:769px)and(max-width:1163px)]:col-span-3' : ''
                }`}
              >
                <div className="text-center w-full">
                  <h3 className={`text-lg mb-1 transition-colors line-clamp-2 ${
                    selectedSize === size.id ? 'text-[#56070f]' : 'text-[#10150f]'
                  }`}>
                    {size.label}
                  </h3>
                  <p className="text-xs text-gray-500 line-clamp-2">{size.examples}</p>
                </div>
              </motion.button>
            ))}
          </motion.div>

          {/* Vehicle Size Guide */}
          <div className="max-w-4xl mx-auto mt-6">
            <Accordion type="single" collapsible>
              <AccordionItem value="size-guide" className="border rounded-lg px-4 bg-white">
                <AccordionTrigger className="text-sm hover:no-underline">
                  <div className="flex items-center gap-2">
                    <Car className="w-4 h-4 text-[#8cc0d6]" />
                    <span>Vehicle Size Guide - Find Your Vehicle</span>
                  </div>
                </AccordionTrigger>
                <AccordionContent>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-2">
                    {/* Small Vehicles */}
                    <div>
                      <p className="text-xs text-[#56070f] mb-2">Small Vehicles</p>
                      <ul className="text-xs text-gray-600 space-y-1">
                        <li>• Honda Civic</li>
                        <li>• Toyota Corolla</li>
                        <li>• Mazda3</li>
                        <li>• BMW 3 Series</li>
                        <li>• Audi A4</li>
                        <li>• Ford Focus</li>
                        <li>• Volkswagen Jetta</li>
                      </ul>
                    </div>

                    {/* Medium Vehicles */}
                    <div>
                      <p className="text-xs text-[#56070f] mb-2">Medium Vehicles</p>
                      <ul className="text-xs text-gray-600 space-y-1">
                        <li>• Honda CR-V</li>
                        <li>• Toyota RAV4</li>
                        <li>• Mazda CX-5</li>
                        <li>• Jeep Grand Cherokee</li>
                        <li>• Tesla Model Y</li>
                        <li>• Ford Explorer</li>
                        <li>• Nissan Rogue</li>
                      </ul>
                    </div>

                    {/* Large Vehicles */}
                    <div>
                      <p className="text-xs text-[#56070f] mb-2">Large Vehicles</p>
                      <ul className="text-xs text-gray-600 space-y-1">
                        <li>• Ford F-150</li>
                        <li>• Chevy Silverado</li>
                        <li>• Ram 1500</li>
                        <li>• GMC Yukon</li>
                        <li>• Chevy Suburban</li>
                        <li>• Toyota Tundra</li>
                        <li>• Ford Expedition</li>
                      </ul>
                    </div>
                  </div>

                  {/* Still Not Sure */}
                  <div className="mt-4 pt-4 border-t">
                    <div className="flex flex-col sm:flex-row items-center justify-between gap-3 bg-[#f8f8f8] rounded-lg p-3">
                      <p className="text-xs text-gray-600 text-center sm:text-left">
                        <strong>Still not sure?</strong> We're here to help!
                      </p>
                      <a
                        href="tel:+1234567890"
                        className="inline-flex items-center gap-2 text-xs bg-[#56070f] text-white px-4 py-2 rounded-lg hover:bg-[#6e0912] transition-colors whitespace-nowrap"
                      >
                        <Phone className="w-3 h-3" />
                        Give Us a Call
                      </a>
                    </div>
                  </div>
                </AccordionContent>
              </AccordionItem>
            </Accordion>
          </div>
        </div>
      </section>

      {/* Main Content */}
      <section className="py-12 md:py-16 px-6 sm:px-8 lg:px-12 overflow-visible">
        <div className="max-w-7xl mx-auto">
          {/* Detail Packages */}
          <div className="mb-16 overflow-visible">
            <h2 className="text-2xl sm:text-3xl text-[#10150f] text-center mb-8">
              Detail Packages
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 pt-6 overflow-visible">
              {packages.map((pkg, index) => {
                const Icon = pkg.icon;
                const inCart = isInCart(`${pkg.id}-${selectedSize}`);

                return (
                  <motion.div
                    key={pkg.id}
                    initial={{ opacity: 0, y: 30 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.5, delay: index * 0.1 }}
                    className="relative pt-6"
                  >
                    {pkg.popular && (
                      <div className="absolute top-0 left-1/2 -translate-x-1/2 z-20">
                        <span className="bg-[#56070f] text-white px-4 py-1.5 rounded-full text-sm shadow-lg whitespace-nowrap">
                          Most Popular
                        </span>
                      </div>
                    )}

                    <Card className={`h-full transition-all flex flex-col group relative ${
                      inCart ? 'ring-2 shadow-xl' : 'hover:shadow-xl hover:border-[#8cc0d6]'
                    }`} style={inCart ? { ringColor: pkg.color } : {}}>
                      <CardContent className="p-0 flex flex-col h-full">
                        {/* Header */}
                        <div 
                          className={`p-6 pb-4 text-center relative overflow-hidden ${pkg.id === 'premium' ? 'bg-gradient-to-br from-[#1a3a52] to-[#0f2540]' : ''}`}
                          style={pkg.id !== 'premium' ? { backgroundColor: `${pkg.color}10` } : {}}
                        >
                          <motion.div
                            className="w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform duration-300"
                            style={{ backgroundColor: pkg.id === 'premium' ? '#8cc0d6' : pkg.color }}
                            animate={inCart ? { scale: [1, 1.1, 1] } : {}}
                            transition={{ duration: 0.5, repeat: inCart ? Infinity : 0, repeatDelay: 2 }}
                          >
                            <Icon className={`w-8 h-8 transition-transform duration-300 group-hover:rotate-[5deg] ${pkg.id === 'premium' ? 'text-[#10150f]' : 'text-white'}`} />
                          </motion.div>
                          <h3 className={`text-2xl mb-2 ${pkg.id === 'premium' ? 'text-white' : 'text-[#10150f]'}`}>
                            {pkg.name}
                          </h3>
                          <p className={`text-sm mb-4 ${pkg.id === 'premium' ? 'text-gray-300' : 'text-gray-600'}`}>{pkg.description}</p>
                          
                          {/* Price with animation */}
                          <motion.div 
                            className="flex items-baseline justify-center gap-2"
                            key={selectedSize}
                            initial={{ scale: 1.2, opacity: 0 }}
                            animate={{ scale: 1, opacity: 1 }}
                            transition={{ duration: 0.3, type: "spring" }}
                          >
                            <span className={`text-4xl ${pkg.id === 'premium' ? 'text-white' : ''}`} style={pkg.id !== 'premium' ? { color: pkg.color } : {}}>
                              ${pkg.pricing[selectedSize]}
                            </span>
                          </motion.div>
                          
                          <p className={`text-xs mt-2 ${pkg.id === 'premium' ? 'text-gray-400' : 'text-gray-500'}`}>{pkg.duration}</p>
                          
                          {/* Size indicator */}
                          <div className={`absolute top-2 right-2 backdrop-blur-sm px-2 py-1 rounded-full text-xs ${pkg.id === 'premium' ? 'bg-white/20 text-white' : 'bg-white/80 text-[#10150f]'}`}>
                            {vehicleSizes.find(s => s.id === selectedSize)?.label}
                          </div>
                        </div>

                        {/* Features */}
                        <div className="p-6 pt-4 flex-grow flex flex-col">
                          <ul className="space-y-3 mb-6 flex-grow">
                            {pkg.features.map((feature, idx) => (
                              <li key={idx} className="flex items-start gap-2 text-sm group/item">
                                <Check className="w-4 h-4 text-[#8cc0d6] flex-shrink-0 mt-0.5 transition-transform duration-300 group-hover/item:rotate-[5deg]" />
                                <span className="text-gray-700">{feature}</span>
                              </li>
                            ))}
                          </ul>

                          <RippleButton
                            onClick={() => handleAddPackage(pkg)}
                            className={`w-full transition-all shadow-md hover:shadow-lg ${
                              inCart
                                ? 'bg-green-600 hover:bg-green-700'
                                : 'bg-[#56070f] hover:bg-[#6e0912]'
                            }`}
                          >
                            {inCart ? (
                              <>
                                <Check className="w-4 h-4 mr-2" />
                                Added to Cart
                              </>
                            ) : (
                              <>
                                <Plus className="w-4 h-4 mr-2" />
                                Add to Cart
                              </>
                            )}
                          </RippleButton>
                        </div>
                      </CardContent>
                    </Card>
                  </motion.div>
                );
              })}
            </div>
          </div>

          {/* Additional Services */}
          <div className="border-t border-gray-200 pt-16">
            <h2 className="text-2xl sm:text-3xl text-[#10150f] text-center mb-8">
              Additional Services
            </h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {additionalServices.map((service, index) => {
                const Icon = service.icon;
                const inCart = isInCart(service.id);

                return (
                  <motion.div
                    key={service.id}
                    initial={{ opacity: 0, y: 30 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.5, delay: index * 0.05 }}
                  >
                    <Card className={`h-full transition-all group ${
                      inCart ? 'ring-2 ring-[#8cc0d6] shadow-xl' : 'hover:shadow-xl hover:border-[#8cc0d6]'
                    }`}>
                      <CardContent className="p-5">
                        <motion.div 
                          className="w-12 h-12 bg-[#8cc0d6]/10 rounded-lg flex items-center justify-center mb-3 group-hover:scale-110 transition-transform duration-300"
                          animate={inCart ? { scale: [1, 1.1, 1] } : {}}
                          transition={{ duration: 0.5, repeat: inCart ? Infinity : 0, repeatDelay: 2 }}
                        >
                          <Icon className="w-6 h-6 text-[#8cc0d6] transition-transform duration-300 group-hover:rotate-[5deg]" />
                        </motion.div>
                        
                        <h3 className="text-base text-[#10150f] mb-2">
                          {service.name}
                        </h3>
                        
                        <div className="flex items-center justify-between mb-3">
                          <span className="text-xl text-[#56070f]">
                            ${service.price}
                          </span>
                          <span className="text-xs text-gray-500">{service.duration}</span>
                        </div>

                        <RippleButton
                          onClick={() => toggleService(service)}
                          size="sm"
                          className={`w-full transition-all shadow-md hover:shadow-lg ${
                            inCart
                              ? 'bg-green-600 hover:bg-green-700'
                              : 'bg-[#56070f] hover:bg-[#6e0912]'
                          }`}
                        >
                          {inCart ? (
                            <>
                              <Check className="w-4 h-4 mr-1" />
                              Added
                            </>
                          ) : (
                            <>
                              <Plus className="w-4 h-4 mr-1" />
                              Add
                            </>
                          )}
                        </RippleButton>
                      </CardContent>
                    </Card>
                  </motion.div>
                );
              })}
            </div>
          </div>

          {/* Floating Summary Bar - Hidden on desktop (using VehicleDock instead) */}
          {items.length > 0 && (
            <motion.div
              initial={{ opacity: 0, y: 100 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 100 }}
              transition={{ type: "spring", stiffness: 300, damping: 30 }}
              className="hidden fixed bottom-16 md:bottom-0 left-0 right-0 bg-gradient-to-r from-[#10150f] via-[#1a1514] to-[#10150f] border-t border-white/10 backdrop-blur-lg p-4 md:p-6 z-40 shadow-2xl"
            >
              <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4">
                <div className="flex items-center gap-4 text-white">
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 bg-[#8cc0d6] rounded-full flex items-center justify-center">
                      <span className="text-[#10150f] text-sm">{items.length}</span>
                    </div>
                    <span className="text-sm text-gray-400">
                      {items.length} {items.length === 1 ? 'item' : 'items'} selected
                    </span>
                  </div>
                  <div className="h-6 w-px bg-white/20" />
                  <div>
                    <p className="text-xs text-gray-400">Total</p>
                    <motion.p 
                      className="text-2xl md:text-3xl text-[#8cc0d6]"
                      key={items.reduce((sum, item) => sum + item.price, 0)}
                      initial={{ scale: 1.2 }}
                      animate={{ scale: 1 }}
                      transition={{ type: "spring", stiffness: 500 }}
                    >
                      ${items.reduce((sum, item) => sum + item.price, 0)}
                    </motion.p>
                  </div>
                </div>
                <Button
                  onClick={() => window.location.hash = 'booking'}
                  className="bg-[#8cc0d6] hover:bg-[#7ab5cc] text-[#10150f] px-6 md:px-8 py-5 md:py-6 shadow-lg hover:shadow-xl transition-all relative overflow-hidden group w-full sm:w-auto"
                >
                  <span className="relative z-10 flex items-center justify-center">
                    Proceed to Booking
                    <ArrowRight className="w-5 h-5 ml-2 group-hover:translate-x-1 transition-transform" />
                  </span>
                  <span className="absolute inset-0 -translate-x-full group-hover:translate-x-full transition-transform duration-700 bg-gradient-to-r from-transparent via-white/40 to-transparent skew-x-12"></span>
                </Button>
              </div>
            </motion.div>
          )}
        </div>
      </section>
      </div>
    </>
  );
}
