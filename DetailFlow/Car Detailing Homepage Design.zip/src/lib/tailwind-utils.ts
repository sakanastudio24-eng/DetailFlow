/**
 * Tailwind CSS Utility Functions
 * 
 * Type-safe utilities for working with Tailwind CSS classes
 */

import { type ClassValue, clsx } from 'clsx';
import { twMerge } from 'tailwind-merge';

/**
 * Combines class names with proper merging of Tailwind classes
 * 
 * @example
 * cn('px-4 py-2', 'px-6') // Returns: 'px-6 py-2'
 * cn('text-red-500', condition && 'text-blue-500') // Conditional classes
 */
export function cn(...inputs: ClassValue[]): string {
  return twMerge(clsx(inputs));
}

/**
 * Brand color utilities
 */
export const brandColors = {
  deepRed: {
    DEFAULT: '#56070f',
    bg: 'bg-deepRed',
    text: 'text-deepRed',
    border: 'border-deepRed',
    hover: 'hover:bg-deepRed',
  },
  brandBlack: {
    DEFAULT: '#10150f',
    bg: 'bg-brandBlack',
    text: 'text-brandBlack',
    border: 'border-brandBlack',
    hover: 'hover:bg-brandBlack',
  },
  waterBlue: {
    DEFAULT: '#8cc0d6',
    bg: 'bg-waterBlue',
    text: 'text-waterBlue',
    border: 'border-waterBlue',
    hover: 'hover:bg-waterBlue',
  },
  neutralGray: {
    DEFAULT: '#f8f8f8',
    bg: 'bg-neutralGray',
    text: 'text-neutralGray',
    border: 'border-neutralGray',
    hover: 'hover:bg-neutralGray',
  },
  premiumBlue: {
    DEFAULT: '#1a3a52',
    bg: 'bg-premiumBlue',
    text: 'text-premiumBlue',
    border: 'border-premiumBlue',
    hover: 'hover:bg-premiumBlue',
  },
} as const;

/**
 * Responsive breakpoint utilities
 */
export const breakpoints = {
  sm: 640,
  md: 768,
  lg: 1024,
  xl: 1280,
  '2xl': 1536,
} as const;

/**
 * Check if current viewport matches a breakpoint
 * 
 * @example
 * const isMobile = isBreakpoint('sm') // true if width <= 640px
 */
export function isBreakpoint(breakpoint: keyof typeof breakpoints): boolean {
  if (typeof window === 'undefined') return false;
  return window.innerWidth <= breakpoints[breakpoint];
}

/**
 * Animation presets for common patterns
 */
export const animations = {
  fadeIn: 'animate-fadeIn',
  fadeUp: 'animate-fadeUp',
  fadeDown: 'animate-fadeDown',
  slideInLeft: 'animate-slideInLeft',
  slideInRight: 'animate-slideInRight',
  float: 'animate-float',
  glow: 'animate-glow',
  shimmer: 'animate-shimmer',
  ripple: 'animate-ripple',
  bubble: 'animate-bubble',
  pulse: 'animate-pulse',
  pulseSlow: 'animate-pulse-slow',
  spin: 'animate-spin',
  spinSlow: 'animate-spin-slow',
  wiggle: 'animate-wiggle',
  scaleIn: 'animate-scaleIn',
  ping: 'animate-ping',
  bounceSlow: 'animate-bounce-slow',
} as const;

/**
 * Shadow presets
 */
export const shadows = {
  soft: 'shadow-soft',
  softLg: 'shadow-soft-lg',
  glowBlue: 'shadow-glow-blue',
  glowRed: 'shadow-glow-red',
  glass: 'shadow-glass',
  float: 'shadow-float',
} as const;

/**
 * Glass morphism presets
 */
export const glass = {
  default: 'glass',
  dark: 'glass-dark',
  light: 'glass-light',
} as const;

/**
 * Button variants
 */
export const buttonVariants = {
  primary: cn(
    'btn-primary',
    'inline-flex items-center justify-center',
    'transition-all duration-300',
    'focus:outline-none focus:ring-2 focus:ring-deepRed focus:ring-offset-2'
  ),
  secondary: cn(
    'btn-secondary',
    'inline-flex items-center justify-center',
    'transition-all duration-300',
    'focus:outline-none focus:ring-2 focus:ring-waterBlue focus:ring-offset-2'
  ),
  outline: cn(
    'px-8 py-3',
    'border-2 border-deepRed',
    'text-deepRed',
    'rounded-lg',
    'font-semibold',
    'transition-all duration-300',
    'hover:bg-deepRed hover:text-white',
    'focus:outline-none focus:ring-2 focus:ring-deepRed focus:ring-offset-2'
  ),
  ghost: cn(
    'px-8 py-3',
    'text-brandBlack',
    'rounded-lg',
    'font-semibold',
    'transition-all duration-300',
    'hover:bg-neutralGray',
    'focus:outline-none focus:ring-2 focus:ring-waterBlue focus:ring-offset-2'
  ),
} as const;

/**
 * Card variants
 */
export const cardVariants = {
  glass: 'card-glass',
  default: cn(
    'bg-white',
    'rounded-2xl',
    'p-6',
    'shadow-soft',
    'transition-all duration-300',
    'hover:shadow-soft-lg hover:-translate-y-1'
  ),
  bordered: cn(
    'bg-white',
    'rounded-2xl',
    'p-6',
    'border-2 border-neutralGray',
    'transition-all duration-300',
    'hover:border-waterBlue'
  ),
} as const;

/**
 * Container variants for consistent spacing
 */
export const containers = {
  default: 'max-w-7xl mx-auto px-4 sm:px-6 lg:px-8',
  narrow: 'max-w-4xl mx-auto px-4 sm:px-6 lg:px-8',
  wide: 'max-w-[1920px] mx-auto px-4 sm:px-6 lg:px-8',
  full: 'w-full px-4 sm:px-6 lg:px-8',
} as const;

/**
 * Typography variants
 */
export const typography = {
  hero: 'text-hero font-heading',
  display: 'text-display font-heading',
  heading: 'text-heading font-heading',
  h1: 'text-4xl md:text-5xl lg:text-6xl font-heading font-bold',
  h2: 'text-3xl md:text-4xl lg:text-5xl font-heading font-semibold',
  h3: 'text-2xl md:text-3xl lg:text-4xl font-heading font-semibold',
  h4: 'text-xl md:text-2xl font-heading font-medium',
  body: 'text-base md:text-lg font-body',
  small: 'text-sm font-body',
  tiny: 'text-xs font-body',
} as const;

/**
 * Transition presets
 */
export const transitions = {
  default: 'transition-all duration-300 ease-smooth',
  fast: 'transition-all duration-150 ease-smooth',
  slow: 'transition-all duration-500 ease-smooth',
  bounce: 'transition-all duration-300 ease-bounce-in',
} as const;

/**
 * Z-index layers
 */
export const zIndex = {
  base: 'z-0',
  dropdown: 'z-10',
  sticky: 'z-20',
  fixed: 'z-30',
  modalBackdrop: 'z-40',
  modal: 'z-50',
  popover: 'z-60',
  tooltip: 'z-70',
} as const;

/**
 * Gradient utilities
 */
export const gradients = {
  premium: 'bg-gradient-to-br from-premiumBlue to-premiumDark',
  red: 'bg-gradient-to-r from-deepRed to-deepRed-700',
  blue: 'bg-gradient-to-r from-waterBlue to-premiumBlue',
  textBlue: 'text-gradient-blue',
  textRed: 'text-gradient-red',
} as const;

/**
 * Grid layouts
 */
export const grids = {
  auto: 'grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6',
  autoWide: 'grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6',
  twoCol: 'grid grid-cols-1 lg:grid-cols-2 gap-8',
  threeCol: 'grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8',
  fourCol: 'grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6',
} as const;

/**
 * Flexbox layouts
 */
export const flex = {
  center: 'flex items-center justify-center',
  between: 'flex items-center justify-between',
  start: 'flex items-center justify-start',
  end: 'flex items-center justify-end',
  col: 'flex flex-col',
  colCenter: 'flex flex-col items-center justify-center',
} as const;
