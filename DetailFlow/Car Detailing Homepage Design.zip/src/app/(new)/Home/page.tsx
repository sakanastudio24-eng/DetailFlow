import { HeroSection } from '@/src/components/sections/HeroSection';
import { ServicesTeaser } from '@/src/components/sections/ServicesTeaser';
import { BeforeAfterSection } from '@/src/components/sections/BeforeAfterSection';
import { ReasonsSection } from '@/src/components/sections/ReasonsSection';
import { CTASection } from '@/src/components/sections/CTASection';

export default function Home() {
  return (
    <main className="bg-neutralGray">
      <HeroSection />
      <ServicesTeaser />
      <BeforeAfterSection />
      <ReasonsSection />
      <CTASection />
    </main>
  );
}
