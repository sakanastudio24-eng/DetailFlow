import type { Config } from 'tailwindcss';
import plugin from 'tailwindcss/plugin';

const config: Config = {
  content: [
    './app/**/*.{js,ts,jsx,tsx,mdx}',
    './src/**/*.{js,ts,jsx,tsx,mdx}',
    './components/**/*.{js,ts,jsx,tsx,mdx}',
    './pages/**/*.{js,ts,jsx,tsx,mdx}',
    './context/**/*.{js,ts,jsx,tsx,mdx}',
  ],
  darkMode: ['class'],
  theme: {
    extend: {
      // ============================================================================
      // BRAND COLORS
      // ============================================================================
      colors: {
        // Primary Brand Colors
        deepRed: {
          DEFAULT: '#56070f',
          50: '#fef2f2',
          100: '#fee2e3',
          200: '#fccacc',
          300: '#f9a4a8',
          400: '#f4717a',
          500: '#ea4350',
          600: '#d6232f',
          700: '#b31824',
          800: '#941721',
          900: '#7c1821',
          950: '#56070f',
        },
        brandBlack: {
          DEFAULT: '#10150f',
          50: '#f6f6f6',
          100: '#e7e7e7',
          200: '#d1d1d1',
          300: '#b0b0b0',
          400: '#888888',
          500: '#6d6d6d',
          600: '#5d5d5d',
          700: '#4f4f4f',
          800: '#454545',
          900: '#3d3d3d',
          950: '#10150f',
        },
        waterBlue: {
          DEFAULT: '#8cc0d6',
          50: '#f2f9fc',
          100: '#e3f2f8',
          200: '#c1e4f1',
          300: '#8cc0d6',
          400: '#63aece',
          500: '#4395bc',
          600: '#33789f',
          700: '#2b6181',
          800: '#28526b',
          900: '#26455a',
          950: '#192d3c',
        },
        neutralGray: {
          DEFAULT: '#f8f8f8',
          50: '#ffffff',
          100: '#fefefe',
          200: '#fcfcfc',
          300: '#f8f8f8',
          400: '#f0f0f0',
          500: '#e8e8e8',
          600: '#d1d1d1',
          700: '#b0b0b0',
          800: '#888888',
          900: '#6d6d6d',
          950: '#4f4f4f',
        },
        premiumBlue: {
          DEFAULT: '#1a3a52',
          50: '#f3f7fa',
          100: '#e3ebf2',
          200: '#cddce9',
          300: '#abc5d9',
          400: '#82a6c5',
          500: '#668bb4',
          600: '#5373a1',
          700: '#455e8d',
          800: '#3d5175',
          900: '#354462',
          950: '#1a3a52',
        },
        premiumDark: '#0f2540',
      },

      // ============================================================================
      // TYPOGRAPHY
      // ============================================================================
      fontFamily: {
        heading: ['Manrope', 'system-ui', 'sans-serif'],
        body: ['Outfit', 'system-ui', 'sans-serif'],
        sans: ['Outfit', 'system-ui', 'sans-serif'],
        display: ['Manrope', 'system-ui', 'sans-serif'],
      },
      fontSize: {
        // Custom sizes for responsive design
        'hero': ['clamp(2.5rem, 5vw, 4.5rem)', { lineHeight: '1.1', fontWeight: '800' }],
        'display': ['clamp(2rem, 4vw, 3.5rem)', { lineHeight: '1.2', fontWeight: '700' }],
        'heading': ['clamp(1.5rem, 3vw, 2.5rem)', { lineHeight: '1.3', fontWeight: '600' }],
      },

      // ============================================================================
      // SPACING & SIZING
      // ============================================================================
      spacing: {
        '18': '4.5rem',
        '88': '22rem',
        '100': '25rem',
        '128': '32rem',
      },
      maxWidth: {
        '8xl': '88rem',
        '9xl': '96rem',
      },

      // ============================================================================
      // BORDERS & RADIUS
      // ============================================================================
      borderRadius: {
        'xl': '1rem',
        '2xl': '1.5rem',
        '3xl': '2rem',
        '4xl': '2.5rem',
      },

      // ============================================================================
      // SHADOWS
      // ============================================================================
      boxShadow: {
        'soft': '0 6px 24px rgba(0, 0, 0, 0.08)',
        'soft-lg': '0 10px 40px rgba(0, 0, 0, 0.12)',
        'glow-blue': '0 0 20px rgba(140, 192, 214, 0.5)',
        'glow-red': '0 0 20px rgba(86, 7, 15, 0.5)',
        'glass': '0 8px 32px rgba(0, 0, 0, 0.1)',
        'float': '0 20px 60px rgba(0, 0, 0, 0.15)',
      },

      // ============================================================================
      // BACKDROP BLUR
      // ============================================================================
      backdropBlur: {
        xs: '2px',
        '3xl': '64px',
      },

      // ============================================================================
      // ANIMATIONS & KEYFRAMES
      // ============================================================================
      keyframes: {
        // Fade & Slide
        fadeUp: {
          '0%': { opacity: '0', transform: 'translateY(30px)' },
          '100%': { opacity: '1', transform: 'translateY(0)' },
        },
        fadeDown: {
          '0%': { opacity: '0', transform: 'translateY(-30px)' },
          '100%': { opacity: '1', transform: 'translateY(0)' },
        },
        fadeIn: {
          '0%': { opacity: '0' },
          '100%': { opacity: '1' },
        },
        slideInLeft: {
          '0%': { transform: 'translateX(-100%)' },
          '100%': { transform: 'translateX(0)' },
        },
        slideInRight: {
          '0%': { transform: 'translateX(100%)' },
          '100%': { transform: 'translateX(0)' },
        },
        
        // Effects
        float: {
          '0%, 100%': { transform: 'translateY(0)' },
          '50%': { transform: 'translateY(-20px)' },
        },
        glow: {
          '0%, 100%': { opacity: '0.5' },
          '50%': { opacity: '1' },
        },
        shimmer: {
          '0%': { transform: 'translateX(-100%)' },
          '100%': { transform: 'translateX(100%)' },
        },
        ripple: {
          '0%': { transform: 'scale(0)', opacity: '0.6' },
          '100%': { transform: 'scale(4)', opacity: '0' },
        },
        bubble: {
          '0%, 100%': { transform: 'translateY(0) scale(1)', opacity: '0.6' },
          '50%': { transform: 'translateY(-20px) scale(1.1)', opacity: '0.8' },
        },
        pulse: {
          '0%, 100%': { opacity: '1' },
          '50%': { opacity: '0.5' },
        },
        bounce: {
          '0%, 100%': { transform: 'translateY(-5%)', animationTimingFunction: 'cubic-bezier(0.8, 0, 1, 1)' },
          '50%': { transform: 'translateY(0)', animationTimingFunction: 'cubic-bezier(0, 0, 0.2, 1)' },
        },
        
        // Spins & Rotations
        spin: {
          '0%': { transform: 'rotate(0deg)' },
          '100%': { transform: 'rotate(360deg)' },
        },
        wiggle: {
          '0%, 100%': { transform: 'rotate(-3deg)' },
          '50%': { transform: 'rotate(3deg)' },
        },
        
        // Scale
        scaleIn: {
          '0%': { transform: 'scale(0.95)', opacity: '0' },
          '100%': { transform: 'scale(1)', opacity: '1' },
        },
        ping: {
          '75%, 100%': { transform: 'scale(2)', opacity: '0' },
        },
      },
      animation: {
        // Fade & Slide
        fadeUp: 'fadeUp 0.8s ease-out forwards',
        fadeDown: 'fadeDown 0.8s ease-out forwards',
        fadeIn: 'fadeIn 0.6s ease-out forwards',
        slideInLeft: 'slideInLeft 0.6s ease-out forwards',
        slideInRight: 'slideInRight 0.6s ease-out forwards',
        
        // Effects
        float: 'float 6s ease-in-out infinite',
        glow: 'glow 2s ease-in-out infinite',
        shimmer: 'shimmer 3s linear infinite',
        ripple: 'ripple 600ms ease-out',
        bubble: 'bubble 3s ease-in-out infinite',
        pulse: 'pulse 2s cubic-bezier(0.4, 0, 0.6, 1) infinite',
        'pulse-slow': 'pulse 3s cubic-bezier(0.4, 0, 0.6, 1) infinite',
        
        // Spins & Rotations
        spin: 'spin 1s linear infinite',
        'spin-slow': 'spin 3s linear infinite',
        'spin-slower': 'spin 6s linear infinite',
        wiggle: 'wiggle 1s ease-in-out infinite',
        
        // Scale
        scaleIn: 'scaleIn 0.5s ease-out forwards',
        ping: 'ping 1s cubic-bezier(0, 0, 0.2, 1) infinite',
        'bounce-slow': 'bounce 2s infinite',
      },

      // ============================================================================
      // TRANSITIONS
      // ============================================================================
      transitionDuration: {
        '400': '400ms',
        '600': '600ms',
        '800': '800ms',
        '900': '900ms',
      },
      transitionTimingFunction: {
        'bounce-in': 'cubic-bezier(0.68, -0.55, 0.265, 1.55)',
        'smooth': 'cubic-bezier(0.4, 0, 0.2, 1)',
      },

      // ============================================================================
      // Z-INDEX
      // ============================================================================
      zIndex: {
        '60': '60',
        '70': '70',
        '80': '80',
        '90': '90',
        '100': '100',
      },

      // ============================================================================
      // ASPECT RATIOS
      // ============================================================================
      aspectRatio: {
        '4/3': '4 / 3',
        '21/9': '21 / 9',
      },
    },
  },

  // ============================================================================
  // PLUGINS
  // ============================================================================
  plugins: [
    // Custom utilities plugin
    plugin(function({ addUtilities, addComponents, theme }) {
      // Glass morphism utilities
      addUtilities({
        '.glass': {
          background: 'rgba(255, 255, 255, 0.1)',
          backdropFilter: 'blur(10px)',
          border: '1px solid rgba(255, 255, 255, 0.2)',
        },
        '.glass-dark': {
          background: 'rgba(0, 0, 0, 0.4)',
          backdropFilter: 'blur(10px)',
          border: '1px solid rgba(255, 255, 255, 0.1)',
        },
        '.glass-light': {
          background: 'rgba(255, 255, 255, 0.6)',
          backdropFilter: 'blur(10px)',
          border: '1px solid rgba(255, 255, 255, 0.3)',
        },
      });

      // Text gradient utilities
      addUtilities({
        '.text-gradient-blue': {
          backgroundImage: 'linear-gradient(135deg, #8cc0d6 0%, #1a3a52 100%)',
          WebkitBackgroundClip: 'text',
          WebkitTextFillColor: 'transparent',
          backgroundClip: 'text',
        },
        '.text-gradient-red': {
          backgroundImage: 'linear-gradient(135deg, #56070f 0%, #d6232f 100%)',
          WebkitBackgroundClip: 'text',
          WebkitTextFillColor: 'transparent',
          backgroundClip: 'text',
        },
      });

      // Scrollbar utilities
      addUtilities({
        '.scrollbar-hide': {
          '-ms-overflow-style': 'none',
          'scrollbar-width': 'none',
          '&::-webkit-scrollbar': {
            display: 'none',
          },
        },
        '.scrollbar-thin': {
          'scrollbar-width': 'thin',
          'scrollbar-color': `${theme('colors.waterBlue.DEFAULT')} transparent`,
          '&::-webkit-scrollbar': {
            width: '8px',
            height: '8px',
          },
          '&::-webkit-scrollbar-thumb': {
            backgroundColor: theme('colors.waterBlue.DEFAULT'),
            borderRadius: '4px',
          },
          '&::-webkit-scrollbar-track': {
            backgroundColor: 'transparent',
          },
        },
      });

      // Component-level utilities
      addComponents({
        '.btn-primary': {
          padding: '0.75rem 2rem',
          backgroundColor: theme('colors.deepRed.DEFAULT'),
          color: theme('colors.white'),
          borderRadius: theme('borderRadius.lg'),
          fontWeight: theme('fontWeight.semibold'),
          transition: 'all 0.3s ease',
          '&:hover': {
            backgroundColor: theme('colors.deepRed.700'),
            transform: 'translateY(-2px)',
            boxShadow: theme('boxShadow.lg'),
          },
        },
        '.btn-secondary': {
          padding: '0.75rem 2rem',
          backgroundColor: theme('colors.waterBlue.DEFAULT'),
          color: theme('colors.white'),
          borderRadius: theme('borderRadius.lg'),
          fontWeight: theme('fontWeight.semibold'),
          transition: 'all 0.3s ease',
          '&:hover': {
            backgroundColor: theme('colors.waterBlue.600'),
            transform: 'translateY(-2px)',
            boxShadow: theme('boxShadow.lg'),
          },
        },
        '.card-glass': {
          background: 'rgba(255, 255, 255, 0.05)',
          backdropFilter: 'blur(10px)',
          borderRadius: theme('borderRadius.2xl'),
          border: '1px solid rgba(255, 255, 255, 0.1)',
          padding: theme('spacing.6'),
          transition: 'all 0.3s ease',
          '&:hover': {
            background: 'rgba(255, 255, 255, 0.1)',
            transform: 'translateY(-4px)',
            boxShadow: theme('boxShadow.glass'),
          },
        },
      });
    }),

    // Add plugin for container queries (optional)
    require('@tailwindcss/container-queries'),
  ],
};

export default config;
