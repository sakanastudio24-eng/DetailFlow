import { useEffect, useRef, useState } from 'react';

/**
 * Hook to reveal elements on scroll using Intersection Observer
 * @param threshold - Percentage of element visibility before triggering (0-1)
 * @param rootMargin - Margin around the viewport for early/late triggering
 */
export function useRevealOnScroll(
  threshold: number = 0.1,
  rootMargin: string = '0px'
) {
  const ref = useRef<HTMLElement>(null);
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          // Optionally disconnect after first reveal
          observer.disconnect();
        }
      },
      { threshold, rootMargin }
    );

    if (ref.current) {
      observer.observe(ref.current);
    }

    return () => observer.disconnect();
  }, [threshold, rootMargin]);

  return { ref, isVisible };
}

/**
 * Animation variants for motion components
 */
export const fadeUpVariant = {
  hidden: { opacity: 0, y: 30 },
  visible: { opacity: 1, y: 0 },
};

export const fadeInVariant = {
  hidden: { opacity: 0 },
  visible: { opacity: 1 },
};

export const scaleInVariant = {
  hidden: { opacity: 0, scale: 0.9 },
  visible: { opacity: 1, scale: 1 },
};
