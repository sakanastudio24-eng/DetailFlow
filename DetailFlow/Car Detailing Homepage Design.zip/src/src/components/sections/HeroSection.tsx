'use client';

import { useState, useEffect, useCallback, memo } from 'react';
import { motion, AnimatePresence, Variants } from 'motion/react';
import { ArrowRight, Shield, Clock, Award, Sparkles, LucideIcon } from 'lucide-react';

// ============================================================================
// TYPES & INTERFACES
// ============================================================================

interface CarouselImage {
  url: string;
  alt: string;
}

interface FeatureCard {
  icon: LucideIcon;
  title: string;
  description: string;
}

// ============================================================================
// CONSTANTS
// ============================================================================

const CAROUSEL_INTERVAL = 5000; // 5 seconds
const ANIMATION_DURATION = 1500; // 1.5 seconds

const carouselImages: readonly CarouselImage[] = [
  {
    url: 'https://images.unsplash.com/photo-1633014332834-c94559ff5439?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjYXIlMjBkZXRhaWxpbmclMjBpbnRlcmlvcnxlbnwxfHx8fDE3NjEyNzc4NTB8MA&ixlib=rb-4.1.0&q=80&w=1080',
    alt: 'Professional car interior detailing'
  },
  {
    url: 'https://images.unsplash.com/photo-1754369764475-033c33421843?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxsdXh1cnklMjBjYXIlMjB3YXNofGVufDF8fHx8MTc2MTM4MjQ0Mnww&ixlib=rb-4.1.0&q=80&w=1080',
    alt: 'Luxury car wash service'
  },
  {
    url: 'https://images.unsplash.com/photo-1730068001928-f0983eb1ce94?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjYXIlMjBwb2xpc2hpbmclMjBkZXRhaWx8ZW58MXx8fHwxNzYxMzg1NDA5fDA&ixlib=rb-4.1.0&q=80&w=1080',
    alt: 'Car polishing and detailing'
  }
] as const;

const featureCards: readonly FeatureCard[] = [
  {
    icon: Shield,
    title: 'Premium Products',
    description: 'Top-grade professional supplies'
  },
  {
    icon: Award,
    title: 'Certified Pros',
    description: 'Experienced detailers'
  },
  {
    icon: Clock,
    title: 'Flexible Scheduling',
    description: 'Same-day appointments'
  },
  {
    icon: Sparkles,
    title: 'Satisfaction Guarantee',
    description: 'Re-do or refund promise'
  }
] as const;

// ============================================================================
// ANIMATION VARIANTS
// ============================================================================

const containerVariants: Variants = {
  hidden: { opacity: 0, y: 30 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.8 }
  }
};

const trustBadgeVariants: Variants = {
  hidden: { opacity: 0, y: 20 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.6, delay: 0.4 }
  }
};

const featureGridVariants: Variants = {
  hidden: { opacity: 0, y: 30 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.8, delay: 0.2 }
  }
};

const scrollIndicatorVariants: Variants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: { duration: 1, delay: 1 }
  }
};

// ============================================================================
// SUB-COMPONENTS
// ============================================================================

interface CarouselIndicatorsProps {
  total: number;
  current: number;
  onSelect: (index: number) => void;
}

const CarouselIndicators = memo<CarouselIndicatorsProps>(({ total, current, onSelect }) => (
  <div className="absolute bottom-24 left-1/2 -translate-x-1/2 flex gap-2 z-10">
    {Array.from({ length: total }).map((_, index) => (
      <button
        key={`carousel-indicator-${index}`}
        onClick={() => onSelect(index)}
        className={`w-2 h-2 rounded-full transition-all ${
          index === current ? 'bg-waterBlue w-8' : 'bg-white/30'
        }`}
        aria-label={`Go to slide ${index + 1}`}
        aria-current={index === current ? 'true' : 'false'}
      />
    ))}
  </div>
));

CarouselIndicators.displayName = 'CarouselIndicators';

interface FeatureCardProps {
  feature: FeatureCard;
}

const FeatureCardComponent = memo<FeatureCardProps>(({ feature }) => {
  const Icon = feature.icon;
  
  return (
    <div className="bg-white/5 backdrop-blur-md border border-white/10 rounded-xl p-4 md:p-6 hover:bg-white/10 transition-all group">
      <div className="w-10 h-10 md:w-12 md:h-12 bg-waterBlue/20 rounded-full flex items-center justify-center mb-3 md:mb-4 mx-auto group-hover:scale-110 transition-transform">
        <Icon 
          className="w-5 h-5 md:w-6 md:h-6 text-waterBlue transition-transform duration-300 group-hover:rotate-[5deg]" 
          aria-hidden="true"
        />
      </div>
      <h4 className="text-white mb-1 md:mb-2 font-heading">{feature.title}</h4>
      <p className="text-gray-400 text-sm font-body">{feature.description}</p>
    </div>
  );
});

FeatureCardComponent.displayName = 'FeatureCard';

const ScrollIndicator = memo(() => (
  <motion.div
    variants={scrollIndicatorVariants}
    initial="hidden"
    animate="visible"
    className="hidden lg:block absolute bottom-8 left-1/2 -translate-x-1/2"
    aria-hidden="true"
  >
    <motion.div
      animate={{ y: [0, 10, 0] }}
      transition={{ duration: 1.5, repeat: Infinity, ease: 'easeInOut' }}
      className="w-6 h-10 border-2 border-white/30 rounded-full flex items-start justify-center p-2"
    >
      <div className="w-1 h-2 bg-waterBlue rounded-full" />
    </motion.div>
  </motion.div>
));

ScrollIndicator.displayName = 'ScrollIndicator';

// ============================================================================
// MAIN COMPONENT
// ============================================================================

export function HeroSection() {
  const [currentSlide, setCurrentSlide] = useState<number>(0);

  // Memoized callback for changing slides
  const handleSlideChange = useCallback((index: number) => {
    setCurrentSlide(index);
  }, []);

  // Memoized callback for booking
  const handleBookNow = useCallback(() => {
    // In Next.js App Router, you might use useRouter instead
    // For now, using hash navigation to maintain compatibility
    if (typeof window !== 'undefined') {
      window.location.hash = 'booking';
    }
  }, []);

  // Memoized callback for viewing services
  const handleViewServices = useCallback(() => {
    if (typeof window !== 'undefined') {
      window.location.hash = 'packages';
    }
  }, []);

  // Auto-advance carousel
  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % carouselImages.length);
    }, CAROUSEL_INTERVAL);

    return () => clearInterval(interval);
  }, []);

  // Preload next image for smoother transitions
  useEffect(() => {
    const nextSlide = (currentSlide + 1) % carouselImages.length;
    const img = new Image();
    img.src = carouselImages[nextSlide].url;
  }, [currentSlide]);

  return (
    <section
      className="relative min-h-screen w-full overflow-hidden bg-brandBlack"
      aria-label="Hero section"
    >
      {/* Background Carousel with Dark Overlay */}
      <div className="absolute inset-0">
        <AnimatePresence mode="wait">
          <motion.div
            key={`carousel-slide-${currentSlide}`}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: ANIMATION_DURATION / 1000 }}
            className="absolute inset-0"
          >
            <img
              src={carouselImages[currentSlide].url}
              alt={carouselImages[currentSlide].alt}
              className="w-full h-full object-cover"
              loading="eager"
              decoding="async"
            />
          </motion.div>
        </AnimatePresence>
        {/* Dark Overlay */}
        <div className="absolute inset-0 bg-brandBlack/75" aria-hidden="true" />
      </div>

      {/* Content */}
      <div className="relative h-full min-h-screen md:min-h-0 md:py-16 lg:min-h-screen lg:py-0 flex flex-col items-center justify-center px-6 sm:px-8 lg:px-12">
        {/* Glass Panel Container */}
        <div className="max-w-5xl mx-auto w-full text-center pt-24 md:pt-8 lg:pt-12 pb-32 md:pb-8 lg:pb-16 backdrop-blur-[8px] bg-white/[0.06] rounded-3xl p-6 md:p-8 lg:p-12 border border-white/10">
          {/* Main Content */}
          <motion.div
            variants={containerVariants}
            initial="hidden"
            animate="visible"
          >
            {/* Main Headline */}
            <h1 className="text-4xl sm:text-5xl md:text-5xl lg:text-7xl text-white mb-4 md:mb-6 leading-tight font-heading font-extrabold">
              Premium Auto Detailing,
              <br />
              <span className="text-waterBlue">Done Right</span>
            </h1>

            <p className="text-lg sm:text-xl text-gray-300 mb-6 md:mb-8 max-w-2xl mx-auto font-body">
              Restore your vehicle's shine with expert care, premium products, and guaranteed results.
            </p>

            {/* CTAs */}
            <div className="flex flex-col sm:flex-row gap-4 mb-4 md:mb-6 justify-center relative">
              <button
                onClick={handleBookNow}
                className="group bg-deepRed hover:bg-[#6e0912] text-white px-8 py-4 md:py-6 text-lg rounded-lg shadow-xl hover:shadow-2xl transition-all relative overflow-hidden"
                aria-label="Book your detail appointment"
                type="button"
              >
                <span className="relative z-10 flex items-center justify-center">
                  Book Your Detail
                  <ArrowRight 
                    className="w-5 h-5 ml-2 group-hover:translate-x-1 transition-transform" 
                    aria-hidden="true"
                  />
                </span>
                <span 
                  className="absolute inset-0 -translate-x-full group-hover:translate-x-full transition-transform duration-700 bg-gradient-to-r from-transparent via-white/30 to-transparent skew-x-12"
                  aria-hidden="true"
                />
              </button>
              
              <button
                onClick={handleViewServices}
                className="bg-white text-brandBlack hover:bg-white/90 px-8 py-4 md:py-6 text-lg rounded-lg transition-all shadow-lg hover:shadow-xl border-2 border-white"
                aria-label="View our services"
                type="button"
              >
                View Services
              </button>
            </div>

            {/* Trust Badge */}
            <motion.div
              variants={trustBadgeVariants}
              initial="hidden"
              animate="visible"
              className="inline-flex items-center gap-2 bg-waterBlue/10 border border-waterBlue/30 rounded-full px-4 py-2 mb-8 md:mb-10 lg:mb-16"
            >
              <Award className="w-4 h-4 text-waterBlue" aria-hidden="true" />
              <span className="text-sm text-waterBlue">Trusted by 5,000+ Car Owners</span>
            </motion.div>

            {/* Feature Icons Grid */}
            <motion.div
              variants={featureGridVariants}
              initial="hidden"
              animate="visible"
              className="grid grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6 max-w-4xl mx-auto"
            >
              {featureCards.map((feature) => (
                <FeatureCardComponent
                  key={feature.title}
                  feature={feature}
                />
              ))}
            </motion.div>
          </motion.div>
        </div>
      </div>

      {/* Carousel Indicators */}
      <CarouselIndicators
        total={carouselImages.length}
        current={currentSlide}
        onSelect={handleSlideChange}
      />

      {/* Scroll Indicator */}
      <ScrollIndicator />
    </section>
  );
}

// ============================================================================
// EXPORTS
// ============================================================================

export type { CarouselImage, FeatureCard };
