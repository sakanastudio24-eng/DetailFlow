'use client';

import { motion } from 'motion/react';
import { Sparkles, Droplet, Shield, Zap, ArrowRight } from 'lucide-react';

const services = [
  {
    title: 'Exterior Detailing',
    description: 'Hand wash, wax, and polish to restore your vehicle shine',
    icon: Sparkles,
    image: 'https://images.unsplash.com/photo-1760827797819-4361cd5cd353?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjYXIlMjB3YXNoJTIwcHJvZmVzc2lvbmFsfGVufDF8fHx8MTc2MTM3MDg3Nnww&ixlib=rb-4.1.0&q=80&w=1080',
    features: ['Hand Wash & Dry', 'Wax Application', 'Tire Shine', 'Window Cleaning']
  },
  {
    title: 'Interior Detailing',
    description: 'Deep clean and restoration of your vehicle interior',
    icon: Droplet,
    image: 'https://images.unsplash.com/photo-1656077885491-3922185f3932?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjYXIlMjBpbnRlcmlvciUyMGNsZWFuaW5nfGVufDF8fHx8MTc2MTM3MjYwM3ww&ixlib=rb-4.1.0&q=80&w=1080',
    features: ['Vacuum & Shampoo', 'Leather Treatment', 'Odor Removal', 'Dashboard Detail']
  },
  {
    title: 'Paint Protection',
    description: 'Ceramic coating and paint correction for lasting protection',
    icon: Shield,
    image: 'https://images.unsplash.com/photo-1629281066736-ff3a1e6b36d8?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxsdXh1cnklMjBjYXIlMjBkZXRhaWxpbmd8ZW58MXx8fHwxNzYxMjUyNTUxfDA&ixlib=rb-4.1.0&q=80&w=1080',
    features: ['Ceramic Coating', 'Paint Correction', 'Scratch Removal', 'UV Protection']
  }
];

export function ServicesTeaser() {
  return (
    <section className="relative pt-24 pb-24 bg-white">
      <div className="max-w-7xl mx-auto px-6 sm:px-8 lg:px-12 relative z-10">
        {/* Header */}
        <div className="text-center mb-16 mt-12">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <h2 className="text-3xl sm:text-4xl md:text-5xl text-brandBlack mb-4 font-heading">
              Our Services
            </h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto font-body">
              Professional detailing services tailored to your vehicle needs
            </p>
          </motion.div>
        </div>

        {/* Services Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6 lg:gap-x-6 lg:gap-y-8 mb-12">
          {services.map((service, index) => {
            const Icon = service.icon;
            return (
              <motion.div
                key={service.title}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
              >
                <div className="group h-full overflow-hidden hover:shadow-2xl transition-all duration-300 rounded-xl bg-white border border-gray-200">
                  {/* Image */}
                  <div className="relative aspect-[3/2] overflow-hidden">
                    <img
                      src={service.image}
                      alt={service.title}
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
                    
                    {/* Icon Badge */}
                    <div className="absolute top-4 right-4 w-12 h-12 bg-waterBlue rounded-full flex items-center justify-center group-hover:scale-110 transition-transform duration-300">
                      <Icon className="w-6 h-6 text-white transition-transform duration-300 group-hover:rotate-[5deg]" />
                    </div>
                  </div>

                  <div className="p-6">
                    {/* Title */}
                    <h3 className="text-xl text-brandBlack mb-2 line-clamp-2 font-heading">
                      {service.title}
                    </h3>
                    <p className="text-gray-600 mb-4 text-sm font-body">
                      {service.description}
                    </p>
                    
                    {/* Features List */}
                    <ul className="space-y-2 mb-6">
                      {service.features.map((feature, idx) => (
                        <li key={idx} className="flex items-center gap-2 text-sm text-gray-700 font-body">
                          <div className="w-1.5 h-1.5 bg-waterBlue rounded-full" />
                          {feature}
                        </li>
                      ))}
                    </ul>

                    {/* CTA */}
                    <button
                      className="w-full sm:w-auto text-deepRed hover:text-[#6e0912] flex items-center justify-center sm:justify-start gap-2 text-sm transition-colors group font-body"
                    >
                      Learn More
                      <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                    </button>
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>

        {/* At-Home Service CTA */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="bg-gradient-to-br from-[#1a3a52] to-[#0f2540] rounded-2xl p-8 md:p-12 text-center relative overflow-hidden"
        >
          {/* Decorative elements */}
          <motion.div
            className="absolute top-0 right-0 w-64 h-64 bg-waterBlue/10 rounded-full blur-3xl"
            animate={{ scale: [1, 1.2, 1], opacity: [0.3, 0.5, 0.3] }}
            transition={{ duration: 8, repeat: Infinity }}
          />
          
          <div className="relative z-10">
            <div className="inline-flex items-center gap-2 bg-waterBlue/20 text-waterBlue px-4 py-2 rounded-full text-sm mb-4">
              <Zap className="w-4 h-4" />
              Premium At-Home Service
            </div>
            <h3 className="text-2xl md:text-3xl text-white mb-4 font-heading">
              We Come to You
            </h3>
            <p className="text-gray-300 mb-6 max-w-2xl mx-auto font-body">
              Experience premium detailing at your home or office. Book your service today and let us transform your ride.
            </p>
            <button
              className="inline-flex items-center gap-2 bg-waterBlue hover:bg-[#7ab5cc] text-brandBlack px-8 py-4 rounded-lg transition-all shadow-lg hover:shadow-xl group"
            >
              Book Your Service
              <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
            </button>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
