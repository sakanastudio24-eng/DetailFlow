'use client';

import { useState, useRef, useEffect } from 'react';
import { motion } from 'motion/react';
import { ChevronLeft, ChevronRight } from 'lucide-react';

export function BeforeAfterSection() {
  const [sliderPosition, setSliderPosition] = useState(50);
  const containerRef = useRef<HTMLDivElement>(null);

  const animateToPosition = (targetPosition: number) => {
    const clampedPosition = targetPosition === 0 ? 2 : targetPosition === 100 ? 98 : targetPosition;
    setSliderPosition(clampedPosition);
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    if (!containerRef.current) return;
    
    const rect = containerRef.current.getBoundingClientRect();
    const x = e.touches[0].clientX - rect.left;
    const percentage = (x / rect.width) * 100;
    
    const clampedPercentage = Math.min(Math.max(percentage, 2), 98);
    setSliderPosition(clampedPercentage);
  };

  useEffect(() => {
    const handleGlobalTouchEnd = () => {
      if (containerRef.current) {
        containerRef.current.removeEventListener('touchend', handleGlobalTouchEnd);
      }
    };

    if (containerRef.current) {
      containerRef.current.addEventListener('touchend', handleGlobalTouchEnd);
    }

    return () => {
      if (containerRef.current) {
        containerRef.current.removeEventListener('touchend', handleGlobalTouchEnd);
      }
    };
  }, []);

  return (
    <section className="py-16 md:py-24 px-4 bg-white">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="text-center mb-12">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <h2 className="text-deepRed mb-4 font-heading">
              Before & After
            </h2>
            <p className="text-gray-600 max-w-2xl mx-auto font-body">
              Slide to see the Cruzn Clean difference.
            </p>
          </motion.div>
        </div>

        {/* Slider Container */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="max-w-[960px] mx-auto"
        >
          <div
            ref={containerRef}
            className="relative w-full aspect-[16/9] select-none"
            onTouchMove={handleTouchMove}
          >
            {/* Image Container */}
            <div 
              className="absolute inset-0 rounded-xl overflow-hidden cursor-ew-resize"
              style={{
                border: '1px solid rgba(255, 255, 255, 0.15)',
                boxShadow: '0 4px 8px rgba(0, 0, 0, 0.1)',
              }}
            >
              {/* Before Image */}
              <div className="absolute inset-0">
                <img
                  src="https://images.unsplash.com/photo-1704906654369-091b259fc086?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkaXJ0eSUyMGNhciUyMGV4dGVyaW9yfGVufDF8fHx8MTc2MTQ2NzQ5N3ww&ixlib=rb-4.1.0&q=80&w=1080"
                  alt="Before - Dirty car"
                  className="w-full h-full object-cover"
                  draggable={false}
                />
                <div className="absolute top-4 left-4 bg-black/60 backdrop-blur-sm text-white px-4 py-2 rounded-lg font-body">
                  Before
                </div>
              </div>

              {/* After Image */}
              <div
                className="absolute inset-0"
                style={{
                  clipPath: `inset(0 ${100 - sliderPosition}% 0 0)`,
                }}
              >
                <img
                  src="https://images.unsplash.com/photo-1648468092334-1efcf9620346?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjbGVhbiUyMHNoaW55JTIwY2FyJTIwZGV0YWlsfGVufDF8fHx8MTc2MTQ2NzQ5N3ww&ixlib=rb-4.1.0&q=80&w=1080"
                  alt="After - Clean shiny car"
                  className="w-full h-full object-cover"
                  draggable={false}
                />
                <div className="absolute top-4 right-4 bg-deepRed/80 backdrop-blur-sm text-white px-4 py-2 rounded-lg font-body">
                  After
                </div>
              </div>

              {/* Divider Line */}
              <div
                className="absolute top-0 bottom-0 bg-waterBlue shadow-lg"
                style={{
                  left: `${sliderPosition}%`,
                  transform: 'translateX(-50%)',
                  width: '2px',
                }}
              />
            </div>

            {/* Draggable Handle */}
            <motion.div
              className="absolute top-1/2 cursor-ew-resize z-10"
              style={{
                left: `${sliderPosition}%`,
                transform: 'translate(-50%, -50%)',
              }}
              animate={{ left: `${sliderPosition}%` }}
              transition={{ type: 'spring', stiffness: 300, damping: 30 }}
              onTouchStart={handleTouchMove}
              whileHover={{ scale: 1.15 }}
              whileTap={{ scale: 0.9 }}
            >
              <div className="absolute inset-0 -inset-4 cursor-ew-resize" />
              
              <div 
                className="rounded-full bg-white border-2 border-waterBlue shadow-lg flex items-center justify-center relative"
                style={{
                  width: '28px',
                  height: '28px',
                }}
              >
                <div className="flex items-center gap-px">
                  <ChevronLeft className="w-3 h-3 text-waterBlue" strokeWidth={2.5} />
                  <ChevronRight className="w-3 h-3 text-waterBlue" strokeWidth={2.5} />
                </div>
              </div>
            </motion.div>
          </div>

          {/* Before / After Buttons */}
          <motion.div
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            transition={{ delay: 0.4 }}
            className="flex items-center justify-center gap-4 mt-6"
          >
            <motion.button
              onClick={() => animateToPosition(0)}
              className="px-6 py-2 rounded-lg bg-brandBlack text-white border border-brandBlack hover:bg-transparent hover:text-brandBlack transition-colors"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              Before
            </motion.button>
            <motion.button
              onClick={() => animateToPosition(100)}
              className="px-6 py-2 rounded-lg bg-deepRed text-white border border-deepRed hover:bg-transparent hover:text-deepRed transition-colors"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              After
            </motion.button>
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
}