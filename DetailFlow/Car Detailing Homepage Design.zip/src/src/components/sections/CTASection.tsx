'use client';

import { motion } from 'motion/react';
import { ArrowRight, Calendar } from 'lucide-react';

export function CTASection() {
  return (
    <section className="relative py-20 md:py-32 bg-gradient-to-br from-deepRed to-[#6e0912] overflow-hidden">
      {/* Decorative background elements */}
      <motion.div
        className="absolute top-0 left-0 w-96 h-96 bg-waterBlue/10 rounded-full blur-3xl"
        animate={{ scale: [1, 1.3, 1], opacity: [0.2, 0.4, 0.2] }}
        transition={{ duration: 10, repeat: Infinity }}
      />
      <motion.div
        className="absolute bottom-0 right-0 w-96 h-96 bg-white/5 rounded-full blur-3xl"
        animate={{ scale: [1.3, 1, 1.3], opacity: [0.3, 0.5, 0.3] }}
        transition={{ duration: 12, repeat: Infinity }}
      />

      <div className="max-w-5xl mx-auto px-6 sm:px-8 lg:px-12 text-center relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
        >
          {/* Badge */}
          <div className="inline-flex items-center gap-2 bg-white/10 backdrop-blur-sm border border-white/20 text-white px-4 py-2 rounded-full text-sm mb-6">
            <Calendar className="w-4 h-4" />
            Book Today, Shine Tomorrow
          </div>

          {/* Headline */}
          <h2 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl text-white mb-6 font-heading">
            Ready to Transform Your Ride?
          </h2>

          <p className="text-lg sm:text-xl text-white/90 mb-10 max-w-2xl mx-auto font-body">
            Join thousands of satisfied customers and experience premium auto detailing that exceeds expectations.
          </p>

          {/* CTAs */}
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="group bg-white text-deepRed hover:bg-neutralGray px-8 py-4 rounded-lg shadow-xl hover:shadow-2xl transition-all inline-flex items-center justify-center gap-2"
            >
              <span className="font-heading">Book Your Detail</span>
              <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
            </motion.button>
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="bg-transparent text-white hover:bg-white/10 px-8 py-4 rounded-lg border-2 border-white transition-all"
            >
              Get a Quote
            </motion.button>
          </div>

          {/* Trust indicator */}
          <motion.p
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            transition={{ delay: 0.4 }}
            className="text-white/70 text-sm mt-8 font-body"
          >
            ⭐⭐⭐⭐⭐ Rated 4.9/5 from 2,500+ reviews
          </motion.p>
        </motion.div>
      </div>
    </section>
  );
}
