'use client';

import { motion } from 'motion/react';
import { Shield, MapPin, CloudRain, Award, Clock, ThumbsUp } from 'lucide-react';

const reasons = [
  {
    icon: MapPin,
    title: 'Mobile Service',
    description: 'We come to your home or office, saving you time and hassle.'
  },
  {
    icon: Shield,
    title: 'Premium Products',
    description: 'Only the best professional-grade supplies for your vehicle.'
  },
  {
    icon: CloudRain,
    title: 'All-Weather Policy',
    description: 'Service guaranteed rain or shine with flexible rescheduling.'
  },
  {
    icon: Award,
    title: 'Quality Guarantee',
    description: '100% satisfaction or we re-do the service at no extra charge.'
  },
  {
    icon: Clock,
    title: 'Flexible Scheduling',
    description: 'Same-day and weekend appointments available for your convenience.'
  },
  {
    icon: ThumbsUp,
    title: 'Expert Team',
    description: 'Certified professionals with years of detailing experience.'
  }
];

export function ReasonsSection() {
  return (
    <section className="py-16 md:py-24 bg-neutralGray">
      <div className="max-w-7xl mx-auto px-6 sm:px-8 lg:px-12">
        {/* Header */}
        <div className="text-center mb-16">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <h2 className="text-3xl sm:text-4xl md:text-5xl text-brandBlack mb-4 font-heading">
              Why Choose Cruzn Clean
            </h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto font-body">
              Experience the difference with our commitment to quality, convenience, and customer satisfaction.
            </p>
          </motion.div>
        </div>

        {/* Reasons Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {reasons.map((reason, index) => {
            const Icon = reason.icon;
            return (
              <motion.div
                key={reason.title}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                className="group bg-white rounded-xl p-6 shadow-soft hover:shadow-xl transition-all duration-300"
              >
                <div className="w-14 h-14 bg-waterBlue/10 rounded-full flex items-center justify-center mb-4 group-hover:bg-waterBlue/20 transition-colors">
                  <Icon className="w-7 h-7 text-waterBlue transition-transform duration-300 group-hover:scale-110 group-hover:rotate-[5deg]" />
                </div>
                <h3 className="text-xl text-brandBlack mb-2 font-heading">
                  {reason.title}
                </h3>
                <p className="text-gray-600 font-body">
                  {reason.description}
                </p>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
