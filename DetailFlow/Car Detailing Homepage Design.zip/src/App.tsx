/*
 * ============================================================================
 * CRUZN CLEAN - AUTOMOTIVE DETAILING WEBSITE
 * ============================================================================
 * 
 * SITEMAP & PAGE CONTENT OVERVIEW
 * --------------------------------
 * 
 * 1. HOME PAGE (#home)
 *    Route: /pages/Home.tsx
 *    Keywords: Automotive detailing, car wash, mobile detailing, premium car care,
 *              vehicle cleaning, professional detailing, showroom finish, expert service,
 *              ceramic coating, paint protection, interior cleaning, exterior wash
 *    Sections: Hero banner, Services overview, Before/After slider
 * 
 * 2. SERVICES/PACKAGES PAGE (#packages)
 *    Route: /pages/Packages.tsx
 *    Keywords: Basic Detail, Standard Detail, Premium Detail, detailing packages,
 *              service tiers, pricing, vehicle size, small car, medium SUV, large truck,
 *              wash and wax, interior vacuum, exterior polish, ceramic coating,
 *              paint correction, headlight restoration, engine bay detail,
 *              odor removal, pet hair removal, leather conditioning
 *    Sections: Three-tier pricing (Basic/Standard/Premium), Add-on services,
 *              Vehicle size calculator, Package comparisons, FAQ integration
 * 
 * 3. GALLERY PAGE (#gallery)
 *    Route: /pages/GalleryPage.tsx
 *    Keywords: Before and after, transformation, results, portfolio, work samples,
 *              car photos, detailing results, ceramic coating shine, paint correction,
 *              interior restoration, exterior detailing, customer vehicles
 *    Sections: Photo grid, Before/After comparisons, Customer testimonials
 * 
 * 4. BOOKING PAGE (#booking)
 *    Route: /pages/Booking.tsx
 *    Keywords: Book appointment, schedule service, online booking, appointment calendar,
 *              customer details, vehicle information, package selection, add-ons,
 *              date picker, time slots, contact information, vehicle make, vehicle model,
 *              vehicle year, ZIP code, special requests, terms of service, privacy policy,
 *              instant confirmation, email receipt, reschedule anytime, setmore booking
 *    Sections: Three-step booking process (Details/Enhancements/Schedule),
 *              Package selector, Vehicle size guide, Enhancement add-ons,
 *              Customer form, Vehicle info form, Setmore calendar integration,
 *              Order summary sidebar, Progress indicator
 * 
 * 5. QUOTE/REQUEST PAGE (#quote)
 *    Route: /pages/RequestQuote.tsx
 *    Keywords: Free quote, estimate, custom quote, pricing estimate, request service,
 *              contact form, get pricing, vehicle details, service inquiry,
 *              multiple vehicles, fleet service, commercial detailing
 *    Sections: Quote request form, Vehicle details, Service selection,
 *              Special requirements, Contact preferences
 * 
 * 6. FAQ PAGE (#faq)
 *    Route: /pages/FAQ.tsx
 *    Keywords: Frequently asked questions, help center, common questions, answers,
 *              booking information, service details, pricing questions, payment methods,
 *              service area, mobile detailing, weather policy, cancellation policy,
 *              water requirements, power requirements, appointment duration,
 *              multiple cars, fleet service, gift certificates, referral program,
 *              eco-friendly products, pet-safe cleaning, ceramic coating warranty,
 *              paint protection, headlight restoration, same-day service
 *    Categories: Booking & Scheduling, Service Details, Pricing & Payment,
 *                Service Area & Logistics, Special Services
 *    Sections: Categorized accordion FAQ, Quick contact CTA
 * 
 * 7. CONTACT PAGE (#contact)
 *    Route: /pages/Contact.tsx
 *    Keywords: Contact us, get in touch, customer service, phone number, email,
 *              business hours, location, message form, inquiry, support
 *    Sections: Contact form, Business information, Hours of operation,
 *              Service area map, Contact methods
 * 
 * 8. TERMS OF SERVICE PAGE (#terms)
 *    Route: /pages/TermsOfService.tsx
 *    Keywords: Terms and conditions, legal terms, service agreement, user agreement,
 *              liability, disclaimer, usage terms, booking terms, cancellation policy,
 *              payment terms, service guarantee, warranty, refund policy
 *    Sections: Legal terms and conditions, Service policies, User responsibilities
 * 
 * 9. PRIVACY POLICY PAGE (#privacy)
 *    Route: /pages/PrivacyPolicy.tsx
 *    Keywords: Privacy policy, data protection, personal information, data collection,
 *              cookies, user privacy, information security, GDPR, data usage,
 *              third-party sharing, contact information storage
 *    Sections: Data collection practices, Information usage, User rights,
 *              Cookie policy, Contact data
 * 
 * 10. STYLE GUIDE PAGE (#styleguide) - Internal/Development
 *     Route: /pages/StyleGuide.tsx
 *     Keywords: Design system, brand colors, typography, components, UI elements,
 *               Manrope font, Outfit font, brand black, deep red, water blue,
 *               neutral gray, button styles, card components
 *     Sections: Color palette, Typography samples, Component library,
 *               Spacing system, Icon set
 * 
 * ============================================================================
 * GLOBAL NAVIGATION STRUCTURE
 * ============================================================================
 * 
 * Desktop Top Navigation:
 * - Home, Services (Packages), Gallery, Quote, Phone Number, Book Now CTA,
 *   FAQ Icon, Cart/Vehicle Dock Icon
 * 
 * Mobile Bottom Navigation:
 * - Home, Services, Gallery, Quote, Book (5-icon navigation bar)
 * 
 * Footer Navigation:
 * - Quick Links: Home, Services, Gallery, Book Now
 * - Information: About, FAQ, Contact
 * - Legal: Privacy Policy, Terms of Service
 * - Contact Info: Phone, Email, Address, Business Hours
 * - Social Media: Facebook, Instagram, Twitter
 * 
 * ============================================================================
 * KEY FEATURES & FUNCTIONALITY
 * ============================================================================
 * 
 * - Hash-based routing (SPA with URL fragments)
 * - Multi-vehicle cart system (VehicleDock component)
 * - Sticky mobile CTA (Book Now button)
 * - Help modal with quick actions
 * - Responsive design (Desktop 1440px / Tablet 768px / Mobile 390px)
 * - Wave dividers between sections
 * - Fade-up animations on scroll
 * - Water ripple button effects
 * - Setmore calendar integration for bookings
 * - Before/After image sliders
 * - Vehicle size guide with 21 popular vehicles
 * - Dark mode sections (Premium package branding)
 * - Frosted glass UI elements
 * - Manrope typography (headers) + Outfit (body text)
 * 
 * ============================================================================
 * BRAND COLORS
 * ============================================================================
 * 
 * Primary Colors:
 * - Deep Red: #56070f (primary CTA, accents)
 * - Brand Black: #10150f (headers, dark sections)
 * - Water Blue: #8cc0d6 (service highlights, interactive elements)
 * - Neutral Gray: #f8f8f8 (backgrounds, subtle sections)
 * 
 * Premium Package Special:
 * - Dark Blue Gradient: #1a3a52 to #0f2540 (Premium Detail package only)
 * 
 * ============================================================================
 * SERVICE PACKAGES
 * ============================================================================
 * 
 * 1. BASIC DETAIL ($99 base)
 *    - Essential maintenance, everyday shine
 *    - 2-3 hours duration
 *    - Exterior wash, interior vacuum, windows, tire shine
 * 
 * 2. STANDARD DETAIL ($189 base)
 *    - Full-service refresh inside & out
 *    - 4 hours duration
 *    - Everything in Basic + clay bar, wax, deep interior clean,
 *      leather conditioning, door jambs
 * 
 * 3. PREMIUM DETAIL ($349 base)
 *    - Ultimate protection & showroom finish
 *    - 6 hours duration
 *    - Everything in Standard + paint sealant, engine bay detail,
 *      paint decontamination, trim restoration, premium protection
 * 
 * VEHICLE SIZE MULTIPLIERS:
 * - Small (Sedan/Coupe): 1.0x
 * - Medium (SUV/Crossover): 1.2x
 * - Large (Truck/Van): 1.4x
 * 
 * ADD-ON SERVICES:
 * - Ceramic Coating: $500
 * - Headlight Restoration: $75
 * - Air Freshening Treatment (Ozone): $125
 * - Engine Bay Detail: $100
 * 
 * ============================================================================
 */

import { useState, useEffect } from 'react';
import { Navigation } from './components/Navigation';
import { Footer } from './components/Footer';
import { StickyMobileCTA } from './components/StickyMobileCTA';
import { HelpModal } from './components/HelpModal';
import { Home } from './pages/Home';
import { Packages } from './pages/Packages';
import { GalleryPage } from './pages/GalleryPage';
import { Contact } from './pages/Contact';
import { StyleGuide } from './pages/StyleGuide';
import { RequestQuote } from './pages/RequestQuote';
import { Booking } from './pages/Booking';
import { TermsOfService } from './pages/TermsOfService';
import { PrivacyPolicy } from './pages/PrivacyPolicy';
import { FAQ } from './pages/FAQ';
import { CartProvider } from './context/CartContext';

export default function App() {
  const [currentPage, setCurrentPage] = useState('home');

  // Suppress CSS access errors from external stylesheets
  useEffect(() => {
    const originalError = console.error;
    const originalWarn = console.warn;
    
    // Suppress console errors
    console.error = (...args) => {
      if (
        typeof args[0] === 'string' &&
        (args[0].includes('cssRules') || 
         args[0].includes('CSSStyleSheet') ||
         args[0].includes('Could not access stylesheet') ||
         args[0].includes('SecurityError'))
      ) {
        return;
      }
      originalError.apply(console, args);
    };

    // Suppress console warnings
    console.warn = (...args) => {
      if (
        typeof args[0] === 'string' &&
        (args[0].includes('cssRules') || 
         args[0].includes('CSSStyleSheet') ||
         args[0].includes('Could not access stylesheet'))
      ) {
        return;
      }
      originalWarn.apply(console, args);
    };

    // Suppress unhandled SecurityError rejections
    const handleError = (event: ErrorEvent) => {
      if (
        event.message.includes('cssRules') ||
        event.message.includes('CSSStyleSheet') ||
        event.message.includes('Could not access stylesheet') ||
        event.message.includes('SecurityError')
      ) {
        event.preventDefault();
        return false;
      }
    };

    window.addEventListener('error', handleError);

    return () => {
      console.error = originalError;
      console.warn = originalWarn;
      window.removeEventListener('error', handleError);
    };
  }, []);

  // Handle hash-based navigation
  useEffect(() => {
    const hash = window.location.hash.slice(1);
    if (hash && ['home', 'packages', 'gallery', 'contact', 'quote', 'booking', 'faq', 'styleguide', 'terms', 'privacy'].includes(hash)) {
      setCurrentPage(hash);
    }
  }, []);

  // Listen for hash changes to sync navigation state
  useEffect(() => {
    const handleHashChange = () => {
      const hash = window.location.hash.slice(1);
      if (hash && ['home', 'packages', 'gallery', 'contact', 'quote', 'booking', 'faq', 'styleguide', 'terms', 'privacy'].includes(hash)) {
        setCurrentPage(hash);
        window.scrollTo({ top: 0, behavior: 'smooth' });
      } else if (!hash || hash === '') {
        setCurrentPage('home');
        window.location.hash = 'home';
      }
    };

    window.addEventListener('hashchange', handleHashChange);
    return () => window.removeEventListener('hashchange', handleHashChange);
  }, []);

  const handleNavigate = (page: string) => {
    setCurrentPage(page);
    window.location.hash = page;
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const renderPage = () => {
    switch (currentPage) {
      case 'home':
        return <Home />;
      case 'packages':
        return <Packages />;
      case 'gallery':
        return <GalleryPage />;
      case 'contact':
        return <Contact />;
      case 'quote':
        return <RequestQuote />;
      case 'booking':
        return <Booking />;
      case 'faq':
        return <FAQ />;
      case 'styleguide':
        return <StyleGuide />;
      case 'terms':
        return <TermsOfService />;
      case 'privacy':
        return <PrivacyPolicy />;
      default:
        return <Home />;
    }
  };

  return (
    <CartProvider>
      <div className="min-h-screen bg-white overflow-x-hidden">
        {/* Navigation */}
        <Navigation currentPage={currentPage} onNavigate={handleNavigate} isHomePage={currentPage === 'home'} />

        {/* Page Content */}
        {renderPage()}

        {/* Sticky Mobile CTA */}
        <StickyMobileCTA 
          onBookNow={() => handleNavigate('booking')} 
          hideOnPages={['booking', 'quote']}
        />

        {/* Help Modal */}
        <HelpModal />

        {/* Footer */}
        <Footer />
      </div>
    </CartProvider>
  );
}
