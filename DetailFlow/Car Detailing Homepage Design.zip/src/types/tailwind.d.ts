/**
 * Tailwind CSS Type Definitions for Cruzn Clean
 * 
 * This file provides TypeScript type safety for custom Tailwind utilities
 * and ensures proper autocomplete in your IDE.
 */

declare module 'tailwindcss/lib/util/flattenColorPalette' {
  export default function flattenColorPalette(colors: object): Record<string, string>;
}

declare module 'tailwindcss/plugin' {
  import { PluginAPI } from 'tailwindcss/types/config';
  
  function plugin(
    handler: (api: PluginAPI) => void,
    config?: any
  ): { handler: (api: PluginAPI) => void; config?: any };
  
  export default plugin;
}

// Extend the default Tailwind theme types
declare module 'tailwindcss/types/config' {
  export interface CustomColors {
    deepRed: string | Record<string, string>;
    brandBlack: string | Record<string, string>;
    waterBlue: string | Record<string, string>;
    neutralGray: string | Record<string, string>;
    premiumBlue: string | Record<string, string>;
    premiumDark: string;
  }

  export interface CustomFontFamily {
    heading: string[];
    body: string[];
    display: string[];
  }

  export interface CustomBoxShadow {
    soft: string;
    'soft-lg': string;
    'glow-blue': string;
    'glow-red': string;
    glass: string;
    float: string;
  }
}

// Custom CSS class types for better autocomplete
export type GlassVariant = 'glass' | 'glass-dark' | 'glass-light';
export type TextGradient = 'text-gradient-blue' | 'text-gradient-red';
export type ScrollbarVariant = 'scrollbar-hide' | 'scrollbar-thin';

// Component button variants
export type ButtonVariant = 'btn-primary' | 'btn-secondary';
export type CardVariant = 'card-glass';

// Brand color variants
export type BrandColor = 
  | 'deepRed'
  | 'brandBlack'
  | 'waterBlue'
  | 'neutralGray'
  | 'premiumBlue'
  | 'premiumDark';

// Animation variants
export type AnimationVariant =
  | 'fadeUp'
  | 'fadeDown'
  | 'fadeIn'
  | 'slideInLeft'
  | 'slideInRight'
  | 'float'
  | 'glow'
  | 'shimmer'
  | 'ripple'
  | 'bubble'
  | 'pulse'
  | 'pulse-slow'
  | 'spin'
  | 'spin-slow'
  | 'spin-slower'
  | 'wiggle'
  | 'scaleIn'
  | 'ping'
  | 'bounce-slow';

// Helper type for className prop
export type ClassName = string | undefined | null | false;
export type ClassNameValue = ClassName | ClassName[];
