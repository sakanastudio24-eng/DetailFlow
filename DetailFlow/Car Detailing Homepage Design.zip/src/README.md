# Cruzn Clean - Next.js Export

A premium car detailing website built with Next.js, TypeScript, and Tailwind CSS.

## 🚀 Quick Start

### Requirements
- Node.js >= 18
- npm or yarn

### Installation

1. Clone or extract this project
2. Install dependencies:

```bash
npm install
```

3. Run the development server:

```bash
npm run dev
```

4. Open [http://localhost:3000](http://localhost:3000) in your browser

## 📦 Project Structure

```
/
├── app/
│   ├── (new)/
│   │   └── Home/
│   │       └── page.tsx          # Main home page
│   └── globals.css               # Global styles
├── src/
│   ├── components/
│   │   └── sections/
│   │       ├── HeroSection.tsx
│   │       ├── ServicesTeaser.tsx
│   │       ├── BeforeAfterSection.tsx
│   │       ├── ReasonsSection.tsx
│   │       └── CTASection.tsx
│   └── lib/
│       ├── animations.ts         # Animation utilities & hooks
│       └── utils.ts              # Helper functions
├── tailwind.config.js            # Tailwind configuration
├── tsconfig.json                 # TypeScript configuration
├── postcss.config.js             # PostCSS configuration
└── package.json
```

## 🎨 Design System

### Colors
- **Deep Red**: `#56070f` - Primary brand color
- **Brand Black**: `#10150f` - Dark backgrounds
- **Water Blue**: `#8cc0d6` - Accent color
- **Neutral Gray**: `#f8f8f8` - Light backgrounds
- **Premium Blue**: `#1a3a52` - Premium package accent

### Typography
- **Headings**: Manrope (weights: 500-800)
- **Body**: Outfit (weights: 300-700)

### Spacing Scale
- 8px, 12px, 16px, 24px, 32px, 48px, 64px

### Border Radius
- `xl`: 1rem
- `2xl`: 1.5rem

## 🛠️ Available Scripts

```bash
# Development
npm run dev

# Production build
npm run build

# Start production server
npm run start

# Lint code
npm run lint
```

## 📱 Responsive Breakpoints

- **Mobile**: 390px (base)
- **Tablet**: 768px (md:)
- **Desktop**: 1440px (lg:, xl:)

## ✨ Features

### Sections Included

1. **Hero Section** - Full-screen carousel hero with glassmorphic panel
2. **Services Teaser** - Three service cards with hover effects
3. **Before & After** - Interactive image slider comparison
4. **Reasons Section** - Six reasons to choose Cruzn Clean
5. **CTA Section** - Call-to-action with gradient background

### Animations
- Fade-up on scroll reveals
- Hover effects on cards and buttons
- Carousel transitions
- Interactive slider for before/after

### Accessibility
- Semantic HTML5 elements
- ARIA labels where appropriate
- Focus-visible styles
- High contrast ratios

## 🔧 Customization

### Changing Colors
Edit `tailwind.config.js` in the `extend.colors` section.

### Adding Sections
Create new components in `/src/components/sections/` and import them in `/app/(new)/Home/page.tsx`.

### Modifying Animations
Edit keyframes and animation timings in `tailwind.config.js` under `extend.keyframes` and `extend.animation`.

## 📸 Image Assets

All images are currently sourced from Unsplash. Replace with your own images by:

1. Adding images to `/public/images/`
2. Updating image paths in component files
3. Using format: `/images/your-image.jpg`

## 🌐 Environment

No environment variables are required for the static UI. If you add external APIs or services, create a `.env.local` file.

## 📄 License

This project is for Cruzn Clean business use.

## 🤝 Support

For questions or issues, contact your development team.

---

Built with ❤️ using Next.js, TypeScript, and Tailwind CSS
