import { useEffect, useState } from 'react';
import { motion } from 'motion/react';
import { Calendar, ArrowRight } from 'lucide-react';
import { RippleButton } from './ui/ripple-button';

interface StickyMobileCTAProps {
  onBookNow?: () => void;
  hideOnPages?: string[];
}

export function StickyMobileCTA({ onBookNow, hideOnPages = [] }: StickyMobileCTAProps) {
  const [isNearFooter, setIsNearFooter] = useState(false);
  const [currentHash, setCurrentHash] = useState('');

  const handleClick = () => {
    if (onBookNow) {
      onBookNow();
    } else {
      window.location.hash = 'booking';
    }
  };

  // Track current hash
  useEffect(() => {
    const updateHash = () => {
      setCurrentHash(window.location.hash.replace('#', '') || 'home');
    };
    
    updateHash(); // Initial check
    window.addEventListener('hashchange', updateHash);
    
    return () => window.removeEventListener('hashchange', updateHash);
  }, []);

  // Detect when footer is in view
  useEffect(() => {
    const handleScroll = () => {
      const footer = document.querySelector('footer');
      if (!footer) return;

      const footerRect = footer.getBoundingClientRect();
      const windowHeight = window.innerHeight;
      
      // Hide button when footer is 150px from bottom of viewport
      setIsNearFooter(footerRect.top < windowHeight - 150);
    };

    window.addEventListener('scroll', handleScroll);
    handleScroll(); // Initial check

    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Don't show on booking page or specified pages
  if (hideOnPages.includes(currentHash) || currentHash === 'booking') {
    return null;
  }

  return (
    <motion.div
      initial={{ opacity: 1, y: 0 }}
      animate={{ 
        opacity: isNearFooter ? 0 : 1,
        y: isNearFooter ? 20 : 0
      }}
      transition={{ duration: 0.3 }}
      className="lg:hidden fixed bottom-6 left-0 right-0 z-[45] flex justify-center pointer-events-none"
    >
      <RippleButton
        onClick={handleClick}
        className="w-[85%] max-w-md bg-[#56070f] hover:bg-[#6e0912] text-white py-5 rounded-full shadow-2xl flex items-center justify-center gap-2 pointer-events-auto"
      >
        <Calendar className="w-5 h-5" />
        <span className="text-base">Book Now</span>
        <ArrowRight className="w-5 h-5" />
      </RippleButton>
    </motion.div>
  );
}
