import { motion, AnimatePresence } from 'motion/react';
import { Car, Truck, Plus, Edit2, Trash2, ChevronDown, ChevronUp, X } from 'lucide-react';
import { useCart, Vehicle } from '../context/CartContext';
import { Button } from './ui/button';
import { Card, CardContent } from './ui/card';
import { useState } from 'react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from './ui/dialog';
import { Input } from './ui/input';
import { Label } from './ui/label';

interface VehicleDockProps {
  onBookAll?: () => void;
}

export function VehicleDock({ onBookAll }: VehicleDockProps) {
  const { 
    vehicles, 
    activeVehicleId, 
    setActiveVehicle, 
    addVehicle, 
    removeVehicle, 
    updateVehicle,
    getVehicleTotal,
    getTotalPrice,
    isDockOpen,
    closeDock
  } = useCart();

  const [isExpanded, setIsExpanded] = useState(true);
  const [isMobileExpanded, setIsMobileExpanded] = useState(false);
  const [editingVehicle, setEditingVehicle] = useState<Vehicle | null>(null);
  const [vehicleForm, setVehicleForm] = useState({ name: '', make: '', model: '', year: '' });

  const handleEditVehicle = (vehicle: Vehicle) => {
    setEditingVehicle(vehicle);
    setVehicleForm({
      name: vehicle.name,
      make: vehicle.make || '',
      model: vehicle.model || '',
      year: vehicle.year || ''
    });
  };

  const handleSaveVehicle = () => {
    if (editingVehicle) {
      updateVehicle(editingVehicle.id, vehicleForm);
      setEditingVehicle(null);
    }
  };

  const handleAddVehicle = () => {
    addVehicle();
  };

  const getVehicleIcon = (vehicle: Vehicle) => {
    const vehicleType = vehicle.make?.toLowerCase() || '';
    if (vehicleType.includes('truck') || vehicleType.includes('f-150') || vehicleType.includes('ram')) {
      return Truck;
    }
    return Car;
  };

  const getVehicleDisplay = (vehicle: Vehicle) => {
    if (vehicle.make && vehicle.model) {
      return `${vehicle.make} ${vehicle.model}${vehicle.year ? ` (${vehicle.year})` : ''}`;
    }
    return vehicle.name;
  };

  const hasItems = vehicles.some(v => v.items.length > 0);

  // Don't render if dock is not open
  if (!isDockOpen) {
    return null;
  }

  return (
    <>
      {/* Desktop Dock - Right Side */}
      <div className="hidden lg:block fixed right-0 top-20 bottom-0 z-30 pointer-events-none">
        <motion.div
          initial={{ x: 360 }}
          animate={{ x: 0 }}
          exit={{ x: 360 }}
          transition={{ type: "spring", stiffness: 300, damping: 30 }}
          className="h-full pointer-events-auto"
        >
          <div className="h-full flex flex-col bg-white/95 backdrop-blur-lg border-l border-gray-200 shadow-2xl w-[360px]">
            {/* Header */}
            <div className="p-4 bg-gradient-to-r from-[#10150f] to-[#1a1514] border-b border-white/10">
              <div className="flex items-center justify-between mb-2">
                <h3 className="text-lg text-white flex items-center gap-2">
                  <Car className="w-5 h-5 text-[#8cc0d6]" />
                  Vehicle Dock
                </h3>
                <button
                  onClick={() => closeDock()}
                  className="text-white/60 hover:text-white transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
              <p className="text-xs text-gray-400">
                {vehicles.length} {vehicles.length === 1 ? 'vehicle' : 'vehicles'} • ${getTotalPrice()}
              </p>
            </div>

            {/* Vehicle List */}
            <div className="flex-1 overflow-y-auto p-4 space-y-3">
              <AnimatePresence>
                {vehicles.map((vehicle) => {
                  const Icon = getVehicleIcon(vehicle);
                  const isActive = vehicle.id === activeVehicleId;
                  const total = getVehicleTotal(vehicle.id);

                  return (
                    <motion.div
                      key={vehicle.id}
                      initial={{ opacity: 0, x: 20 }}
                      animate={{ opacity: 1, x: 0 }}
                      exit={{ opacity: 0, x: -20 }}
                      transition={{ duration: 0.2 }}
                    >
                      <Card
                        className={`cursor-pointer transition-all ${
                          isActive 
                            ? 'ring-2 ring-[#56070f] shadow-lg' 
                            : 'hover:shadow-md'
                        }`}
                        onClick={() => setActiveVehicle(vehicle.id)}
                      >
                        <CardContent className="p-4">
                          <div className="flex items-start justify-between gap-2 mb-3">
                            <div className="flex items-center gap-2 flex-1 min-w-0">
                              <div className={`w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0 ${
                                isActive ? 'bg-[#56070f]' : 'bg-[#8cc0d6]/20'
                              }`}>
                                <Icon className={`w-5 h-5 ${
                                  isActive ? 'text-white' : 'text-[#8cc0d6]'
                                }`} />
                              </div>
                              <div className="flex-1 min-w-0">
                                <h4 className="text-sm text-[#10150f] truncate">
                                  {getVehicleDisplay(vehicle)}
                                </h4>
                                <p className="text-xs text-gray-500">
                                  {vehicle.items.length} {vehicle.items.length === 1 ? 'item' : 'items'}
                                </p>
                              </div>
                            </div>
                            <div className="flex items-center gap-1 flex-shrink-0">
                              <button
                                onClick={(e) => {
                                  e.stopPropagation();
                                  handleEditVehicle(vehicle);
                                }}
                                className="p-1.5 hover:bg-gray-100 rounded transition-colors"
                              >
                                <Edit2 className="w-3.5 h-3.5 text-gray-600" />
                              </button>
                              {vehicles.length > 1 && (
                                <button
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    removeVehicle(vehicle.id);
                                  }}
                                  className="p-1.5 hover:bg-red-50 rounded transition-colors"
                                >
                                  <Trash2 className="w-3.5 h-3.5 text-red-600" />
                                </button>
                              )}
                            </div>
                          </div>

                          {/* Items List */}
                          {vehicle.items.length > 0 && (
                            <div className="space-y-1 mb-3 pl-12">
                              {vehicle.items.map((item) => (
                                <div key={item.id} className="flex items-center justify-between text-xs">
                                  <span className="text-gray-600 truncate flex-1">{item.name}</span>
                                  <span className="text-gray-900 ml-2">${item.price}</span>
                                </div>
                              ))}
                            </div>
                          )}

                          {/* Subtotal */}
                          {total > 0 && (
                            <div className="flex items-center justify-between pt-2 border-t border-gray-200">
                              <span className="text-xs text-gray-600">Subtotal</span>
                              <span className="text-sm text-[#56070f]">${total}</span>
                            </div>
                          )}
                        </CardContent>
                      </Card>
                    </motion.div>
                  );
                })}
              </AnimatePresence>

              {/* Add Vehicle Button */}
              <Button
                onClick={handleAddVehicle}
                variant="outline"
                className="w-full border-dashed border-2 border-[#8cc0d6] text-[#8cc0d6] hover:bg-[#8cc0d6]/10 hover:text-[#8cc0d6]"
              >
                <Plus className="w-4 h-4 mr-2" />
                Add Another Car
              </Button>
            </div>

            {/* Footer */}
            {hasItems && (
              <div className="p-4 border-t border-gray-200 bg-white">
                <div className="mb-3">
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-sm text-gray-600">Total</span>
                    <span className="text-2xl text-[#56070f]">${getTotalPrice()}</span>
                  </div>
                  <p className="text-xs text-gray-500">
                    {getTotalPrice() > 0 ? `${vehicles.filter(v => v.items.length > 0).length} ${vehicles.filter(v => v.items.length > 0).length === 1 ? 'vehicle' : 'vehicles'} selected` : 'No items selected'}
                  </p>
                </div>
                <Button
                  onClick={onBookAll || (() => window.location.hash = 'booking')}
                  className="w-full bg-[#56070f] hover:bg-[#6e0912] text-white shadow-lg"
                >
                  Book All Vehicles
                </Button>
              </div>
            )}
          </div>
        </motion.div>
      </div>

      {/* Mobile Dock - Bottom */}
      <div className="lg:hidden fixed bottom-0 left-0 right-0 z-40">
        <motion.div
          initial={{ y: 100 }}
          animate={{ y: 0 }}
          className="bg-white/95 backdrop-blur-lg border-t border-gray-200 shadow-2xl"
        >
          {/* Collapsed View - Horizontal Swipe List */}
          {!isMobileExpanded && (
            <div className="p-3">
              {/* Swipeable Vehicle Cards */}
              <div className="overflow-x-auto scrollbar-hide mb-3 -mx-3 px-3 snap-x snap-mandatory">
                <div className="flex gap-2 pb-2">
                  {vehicles.map((vehicle) => {
                      const Icon = getVehicleIcon(vehicle);
                      const isActive = vehicle.id === activeVehicleId;
                      const total = getVehicleTotal(vehicle.id);

                      return (
                        <motion.div
                          key={vehicle.id}
                          onClick={() => setActiveVehicle(vehicle.id)}
                          whileTap={{ scale: 0.95 }}
                          className={`flex-shrink-0 w-40 p-3 rounded-lg border-2 transition-all snap-start ${
                            isActive 
                              ? 'bg-[#56070f] border-[#56070f]' 
                              : 'bg-white border-gray-200'
                          }`}
                        >
                          <div className="flex items-center gap-2 mb-2">
                            <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                              isActive ? 'bg-white/20' : 'bg-[#8cc0d6]/20'
                            }`}>
                              <Icon className={`w-4 h-4 ${
                                isActive ? 'text-white' : 'text-[#8cc0d6]'
                              }`} />
                            </div>
                          </div>
                          <h4 className={`text-xs mb-1 truncate ${
                            isActive ? 'text-white' : 'text-[#10150f]'
                          }`}>
                            {getVehicleDisplay(vehicle)}
                          </h4>
                          <div className="flex items-center justify-between text-xs">
                            <span className={isActive ? 'text-white/80' : 'text-gray-500'}>
                              {vehicle.items.length} items
                            </span>
                            <span className={`${isActive ? 'text-white' : 'text-[#56070f]'}`}>
                              ${total}
                            </span>
                          </div>
                        </motion.div>
                      );
                    })}
                    {/* Add Vehicle Card */}
                    <button
                      onClick={handleAddVehicle}
                      className="flex-shrink-0 w-40 p-3 rounded-lg border-2 border-dashed border-[#8cc0d6] bg-[#8cc0d6]/5 flex flex-col items-center justify-center gap-2 snap-start"
                    >
                      <Plus className="w-5 h-5 text-[#8cc0d6]" />
                      <span className="text-xs text-[#8cc0d6]">Add Car</span>
                    </button>
                  </div>
                </div>

                {/* Summary Bar */}
                <div className="flex items-center justify-between gap-3">
                  <button
                    onClick={() => setIsMobileExpanded(true)}
                    className="flex items-center gap-2 text-sm text-gray-600"
                  >
                    <span>View All</span>
                    <ChevronUp className="w-4 h-4" />
                  </button>
                  <div className="flex items-center gap-3">
                    <div className="text-right">
                      <p className="text-xs text-gray-500">Total</p>
                      <p className="text-lg text-[#56070f]">${getTotalPrice()}</p>
                    </div>
                    {hasItems && (
                      <Button
                        onClick={onBookAll || (() => window.location.hash = 'booking')}
                        className="bg-[#56070f] hover:bg-[#6e0912] text-white px-6"
                      >
                        Book Now
                      </Button>
                    )}
                  </div>
                </div>
              </div>
            )}

            {/* Expanded View */}
            {isMobileExpanded && (
              <div className="max-h-[70vh] overflow-hidden flex flex-col">
                <div className="p-4 border-b border-gray-200 flex items-center justify-between">
                  <h3 className="text-lg text-[#10150f]">Vehicle Dock</h3>
                  <button
                    onClick={() => setIsMobileExpanded(false)}
                    className="p-2 hover:bg-gray-100 rounded-full transition-colors"
                  >
                    <ChevronDown className="w-5 h-5 text-gray-600" />
                  </button>
                </div>
                
                <div className="flex-1 overflow-y-auto p-4 space-y-3">
                  {vehicles.map((vehicle) => {
                    const Icon = getVehicleIcon(vehicle);
                    const isActive = vehicle.id === activeVehicleId;
                    const total = getVehicleTotal(vehicle.id);

                    return (
                      <Card
                        key={vehicle.id}
                        className={`${
                          isActive ? 'ring-2 ring-[#56070f]' : ''
                        }`}
                        onClick={() => setActiveVehicle(vehicle.id)}
                      >
                        <CardContent className="p-3">
                          <div className="flex items-center justify-between gap-2 mb-2">
                            <div className="flex items-center gap-2 flex-1 min-w-0">
                              <Icon className="w-5 h-5 text-[#8cc0d6] flex-shrink-0" />
                              <div className="flex-1 min-w-0">
                                <h4 className="text-sm text-[#10150f] truncate">
                                  {getVehicleDisplay(vehicle)}
                                </h4>
                                <p className="text-xs text-gray-500">
                                  {vehicle.items.length} items • ${total}
                                </p>
                              </div>
                            </div>
                            <div className="flex items-center gap-1 flex-shrink-0">
                              <button
                                onClick={(e) => {
                                  e.stopPropagation();
                                  handleEditVehicle(vehicle);
                                }}
                                className="p-1.5 hover:bg-gray-100 rounded"
                              >
                                <Edit2 className="w-3.5 h-3.5 text-gray-600" />
                              </button>
                              {vehicles.length > 1 && (
                                <button
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    removeVehicle(vehicle.id);
                                  }}
                                  className="p-1.5 hover:bg-red-50 rounded"
                                >
                                  <Trash2 className="w-3.5 h-3.5 text-red-600" />
                                </button>
                              )}
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    );
                  })}
                  
                  <Button
                    onClick={handleAddVehicle}
                    variant="outline"
                    className="w-full border-dashed"
                  >
                    <Plus className="w-4 h-4 mr-2" />
                    Add Another Car
                  </Button>
                </div>

                {hasItems && (
                  <div className="p-4 border-t border-gray-200 bg-white">
                    <Button
                      onClick={onBookAll || (() => window.location.hash = 'booking')}
                      className="w-full bg-[#56070f] hover:bg-[#6e0912] text-white"
                    >
                      Book All Vehicles - ${getTotalPrice()}
                    </Button>
                  </div>
                )}
              </div>
            )}
          </motion.div>
      </div>

      {/* Edit Vehicle Dialog */}
      <Dialog open={editingVehicle !== null} onOpenChange={(open) => !open && setEditingVehicle(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Edit Vehicle Details</DialogTitle>
            <DialogDescription>
              Add your vehicle information for a more personalized experience.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div>
              <Label htmlFor="name">Display Name</Label>
              <Input
                id="name"
                placeholder="e.g., My Car, Dad's Truck"
                value={vehicleForm.name}
                onChange={(e) => setVehicleForm(prev => ({ ...prev, name: e.target.value }))}
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="make">Make</Label>
                <Input
                  id="make"
                  placeholder="e.g., Toyota"
                  value={vehicleForm.make}
                  onChange={(e) => setVehicleForm(prev => ({ ...prev, make: e.target.value }))}
                />
              </div>
              <div>
                <Label htmlFor="model">Model</Label>
                <Input
                  id="model"
                  placeholder="e.g., Camry"
                  value={vehicleForm.model}
                  onChange={(e) => setVehicleForm(prev => ({ ...prev, model: e.target.value }))}
                />
              </div>
            </div>
            <div>
              <Label htmlFor="year">Year</Label>
              <Input
                id="year"
                placeholder="e.g., 2020"
                value={vehicleForm.year}
                onChange={(e) => setVehicleForm(prev => ({ ...prev, year: e.target.value }))}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setEditingVehicle(null)}>
              Cancel
            </Button>
            <Button onClick={handleSaveVehicle} className="bg-[#56070f] hover:bg-[#6e0912]">
              Save Changes
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
