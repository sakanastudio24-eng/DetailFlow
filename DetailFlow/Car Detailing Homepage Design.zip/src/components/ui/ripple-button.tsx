import * as React from "react";
import { Button, buttonVariants } from "./button";
import { useRipple } from "./use-ripple";
import { cn } from "./utils";
import { VariantProps } from "class-variance-authority@0.7.1";

function RippleButton({
  className,
  variant,
  size,
  onClick,
  children,
  ...props
}: React.ComponentProps<"button"> &
  VariantProps<typeof buttonVariants>) {
  const { ripples, addRipple } = useRipple();

  const handleClick = (e: React.MouseEvent<HTMLButtonElement>) => {
    addRipple(e);
    onClick?.(e);
  };

  return (
    <button
      className={cn(buttonVariants({ variant, size, className }), "relative overflow-hidden")}
      onClick={handleClick}
      {...props}
    >
      {children}
      {ripples.map((ripple) => (
        <span
          key={ripple.id}
          className="absolute rounded-full bg-white/40 pointer-events-none animate-ripple"
          style={{
            left: ripple.x,
            top: ripple.y,
            width: ripple.size,
            height: ripple.size,
          }}
        />
      ))}
    </button>
  );
}

export { RippleButton };
