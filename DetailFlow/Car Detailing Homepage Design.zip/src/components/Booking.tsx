import { motion } from 'motion/react';
import { Calendar, Shield, CheckCircle2 } from 'lucide-react';
import { useState } from 'react';

export function Booking() {
  const [selectedPackage, setSelectedPackage] = useState<'basic' | 'standard' | 'premium'>('standard');

  const packages = [
    { id: 'basic' as const, name: 'Basic', price: '$89' },
    { id: 'standard' as const, name: 'Standard', price: '$189' },
    { id: 'premium' as const, name: 'Premium', price: '$349' }
  ];

  return (
    <section id="booking" className="relative py-24 px-4 bg-gradient-to-b from-[#1a3a52] to-[#0f2540] overflow-hidden">
      {/* Subtle background elements */}
      <motion.div
        className="absolute top-20 right-10 w-72 h-72 bg-[#8cc0d6]/10 rounded-full blur-3xl"
        animate={{ 
          scale: [1, 1.2, 1],
          opacity: [0.3, 0.5, 0.3]
        }}
        transition={{ duration: 8, repeat: Infinity }}
      />
      <motion.div
        className="absolute bottom-20 left-10 w-72 h-72 bg-[#8cc0d6]/10 rounded-full blur-3xl"
        animate={{ 
          scale: [1, 1.3, 1],
          opacity: [0.2, 0.4, 0.2]
        }}
        transition={{ duration: 10, repeat: Infinity }}
      />

      <div className="max-w-5xl mx-auto relative z-10">
        {/* Section Header - Responsive */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-8 md:mb-12"
        >
          <h2 className="text-3xl sm:text-4xl md:text-5xl text-white mb-3 md:mb-4 px-4">
            Book Your Detail Appointment
          </h2>
          <p className="text-base sm:text-lg md:text-xl text-gray-300 max-w-2xl mx-auto px-4">
            Choose your package and a time that fits your schedule. We come to you!
          </p>
        </motion.div>

        {/* Package Filter Buttons - Stack on mobile */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.1 }}
          className="flex flex-col sm:flex-row flex-wrap justify-center gap-3 mb-6 md:mb-8 px-4"
        >
          {packages.map((pkg) => (
            <button
              key={pkg.id}
              onClick={() => setSelectedPackage(pkg.id)}
              className={`
                w-full sm:w-auto px-6 md:px-8 py-4 md:py-4 rounded-xl transition-all duration-300
                ${selectedPackage === pkg.id
                  ? 'bg-[#8cc0d6] text-[#10150f] shadow-lg scale-105'
                  : 'bg-white/10 backdrop-blur-sm border-2 border-white/20 text-white hover:border-[#8cc0d6] hover:bg-white/20 hover:shadow-md'
                }
              `}
            >
              <div className="flex flex-row sm:flex-col items-center justify-between sm:justify-center gap-2 sm:gap-1">
                <span className="font-medium text-base md:text-sm">{pkg.name}</span>
                <span className={`text-base md:text-sm ${selectedPackage === pkg.id ? 'text-[#10150f]/80' : 'text-gray-300'}`}>
                  {pkg.price}
                </span>
              </div>
            </button>
          ))}
        </motion.div>

        {/* Calendar Widget Container */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="relative mb-8"
        >
          {/* Decorative frame */}
          <div className="absolute inset-0 bg-gradient-to-br from-[#8cc0d6]/20 via-transparent to-[#8cc0d6]/20 rounded-xl blur-xl" />
          
          {/* Main calendar container - Single column on mobile */}
          <div className="relative bg-white/95 backdrop-blur-md border border-white/30 rounded-xl shadow-2xl p-4 md:p-6 lg:p-8">
            {/* Selected package indicator - Stack on mobile */}
            <div className="mb-4 md:mb-6 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 md:gap-4">
              <div className="flex items-center gap-3">
                <div className="w-3 h-3 bg-[#8cc0d6] rounded-full animate-pulse" />
                <span className="text-sm md:text-base text-gray-700">
                  Selected: <strong className="text-[#1a3a52]">{packages.find(p => p.id === selectedPackage)?.name} Detail</strong>
                </span>
              </div>
              <div className="flex items-center gap-2 text-xs md:text-sm text-gray-600">
                <Calendar className="w-4 h-4 text-[#8cc0d6]" />
                <span className="hidden sm:inline">Available slots update in real-time</span>
                <span className="sm:hidden">Real-time availability</span>
              </div>
            </div>

            {/* Setmore Embed Placeholder - Responsive height */}
            <div className="relative min-h-[400px] sm:min-h-[500px] md:min-h-[600px] bg-gradient-to-br from-gray-50 to-white rounded-xl border-2 border-dashed border-gray-300 flex items-center justify-center overflow-hidden">
              {/* Water ripple effect */}
              <motion.div
                className="absolute inset-0 bg-gradient-to-br from-[#8cc0d6]/5 to-transparent"
                animate={{
                  scale: [1, 1.05, 1],
                  opacity: [0.3, 0.5, 0.3]
                }}
                transition={{ duration: 3, repeat: Infinity }}
              />
              
              {/* Placeholder content - Responsive */}
              <div className="relative z-10 text-center p-4 sm:p-6 md:p-8">
                <Calendar className="w-16 sm:w-20 h-16 sm:h-20 text-[#8cc0d6]/40 mx-auto mb-4 md:mb-6" />
                <h3 className="text-xl sm:text-2xl text-gray-400 mb-2 md:mb-3">
                  Setmore Calendar Widget
                </h3>
                <p className="text-sm sm:text-base text-gray-500 mb-4 max-w-md mx-auto px-2">
                  Your interactive booking calendar will appear here. Customers can select dates, times, and complete their booking instantly.
                </p>
                <div className="inline-block px-4 sm:px-6 py-2 bg-[#8cc0d6]/10 text-[#8cc0d6] rounded-lg text-sm">
                  Embed your Setmore widget here
                </div>
                
                {/* Visual calendar mockup - Responsive */}
                <div className="mt-6 md:mt-8 grid grid-cols-7 gap-1 sm:gap-2 max-w-sm sm:max-w-md mx-auto">
                  {Array.from({ length: 28 }).map((_, i) => (
                    <div
                      key={i}
                      className={`
                        aspect-square rounded-md sm:rounded-lg flex items-center justify-center text-xs sm:text-sm
                        ${i % 7 === 0 || i % 7 === 6 ? 'bg-gray-100 text-gray-400' : 'bg-white border border-gray-200 text-gray-600'}
                        ${i === 15 ? 'bg-[#56070f] text-white' : ''}
                      `}
                    >
                      {i + 1}
                    </div>
                  ))}
                </div>
              </div>

              {/* Iframe placeholder for actual Setmore integration */}
              {/* Uncomment and add your Setmore URL when ready:
              <iframe
                src="YOUR_SETMORE_BOOKING_URL"
                className="w-full h-full min-h-[600px] border-0 rounded-xl"
                title="Book Appointment"
              />
              */}
            </div>
          </div>
        </motion.div>

        {/* Confirm Appointment Button - Larger on mobile */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.3 }}
          className="text-center px-4"
        >
          <button
            className="group relative w-full sm:w-auto px-8 sm:px-12 py-5 sm:py-5 bg-[#8cc0d6] text-[#10150f] rounded-xl shadow-lg overflow-hidden transition-all duration-300 hover:shadow-2xl hover:scale-105"
          >
            {/* Water ripple effect on hover */}
            <motion.div
              className="absolute inset-0 bg-gradient-to-r from-transparent via-[#10150f]/10 to-transparent"
              initial={{ x: '-100%', y: '-100%' }}
              whileHover={{ 
                x: '100%',
                y: '100%',
                transition: { 
                  duration: 0.8,
                  ease: 'easeInOut'
                }
              }}
            />
            
            {/* Multiple ripple layers */}
            <span className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-500">
              <span className="absolute inset-0 bg-gradient-radial from-white/10 via-transparent to-transparent animate-ping" />
            </span>

            <span className="relative z-10 flex items-center justify-center gap-3 text-base sm:text-lg">
              <CheckCircle2 className="w-5 h-5 sm:w-6 sm:h-6" />
              Confirm Appointment
            </span>
          </button>

          {/* Reassurance Text - Stack on mobile */}
          <div className="mt-6 flex flex-col sm:flex-row items-center justify-center gap-3 sm:gap-4 text-xs sm:text-sm text-gray-600">
            <div className="flex items-center gap-2">
              <Shield className="w-4 h-4 text-[#8cc0d6]" />
              <span>All bookings confirmed instantly</span>
            </div>
            <span className="hidden md:inline text-gray-300">•</span>
            <div className="flex items-center gap-2">
              <svg className="w-4 h-4 text-[#8cc0d6]" viewBox="0 0 24 24" fill="none" stroke="currentColor">
                <rect x="2" y="5" width="20" height="14" rx="2" strokeWidth="2"/>
                <path d="M2 10h20" strokeWidth="2"/>
              </svg>
              <span>Payment handled securely through Square</span>
            </div>
          </div>

          {/* Additional info badges */}
          <div className="mt-8 flex flex-wrap justify-center gap-4">
            <div className="flex items-center gap-2 px-4 py-2 bg-green-50 text-green-700 rounded-lg">
              <CheckCircle2 className="w-4 h-4" />
              <span className="text-sm">Instant confirmation</span>
            </div>
            <div className="flex items-center gap-2 px-4 py-2 bg-blue-50 text-blue-700 rounded-lg">
              <Calendar className="w-4 h-4" />
              <span className="text-sm">Flexible rescheduling</span>
            </div>
            <div className="flex items-center gap-2 px-4 py-2 bg-purple-50 text-purple-700 rounded-lg">
              <Shield className="w-4 h-4" />
              <span className="text-sm">Satisfaction guaranteed</span>
            </div>
          </div>
        </motion.div>

        {/* Business Hours Info */}
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.4 }}
          className="mt-12 p-6 bg-[#f8f8f8] rounded-xl border border-gray-200"
        >
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-center">
            <div>
              <h4 className="text-sm uppercase tracking-wide text-gray-500 mb-2">Monday - Friday</h4>
              <p className="text-lg text-[#10150f]">8:00 AM - 6:00 PM</p>
            </div>
            <div>
              <h4 className="text-sm uppercase tracking-wide text-gray-500 mb-2">Saturday</h4>
              <p className="text-lg text-[#10150f]">9:00 AM - 5:00 PM</p>
            </div>
            <div>
              <h4 className="text-sm uppercase tracking-wide text-gray-500 mb-2">Sunday</h4>
              <p className="text-lg text-gray-400">Closed</p>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
