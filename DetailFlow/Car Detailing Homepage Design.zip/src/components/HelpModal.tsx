import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { HelpCircle, X, ExternalLink, Clock, Droplet, CreditCard, Car, ChevronDown, ChevronUp } from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from './ui/dialog';
import { Button } from './ui/button';
import { RippleButton } from './ui/ripple-button';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from './ui/tooltip';

// Top 5 most asked questions
const topFAQs = [
  {
    question: 'How long does a detail take?',
    answer: 'Timing varies by package: Basic Detail takes 2-3 hours, Standard Detail takes about 4 hours, and Premium Detail takes 6+ hours. We recommend allowing extra time for larger vehicles or heavily soiled interiors.',
    icon: Clock
  },
  {
    question: 'Do I need to provide water or power on-site?',
    answer: 'No! We are completely self-contained. Our mobile units come equipped with their own water tanks (up to 50 gallons) and generators. All we need is a flat parking space near your vehicle.',
    icon: Droplet
  },
  {
    question: 'What forms of payment do you accept?',
    answer: 'We accept all major credit cards (Visa, Mastercard, American Express, Discover), debit cards, cash, Venmo, Zelle, and Apple Pay. Payment is due upon completion of service.',
    icon: CreditCard
  },
  {
    question: 'Can I book multiple cars at once?',
    answer: 'Absolutely! Our multi-vehicle booking system allows you to add multiple cars to your appointment. Each vehicle can have its own package and add-ons.',
    icon: Car
  },
  {
    question: 'Do I need to clean my car before you arrive?',
    answer: 'Not at all! That\'s our job. However, please remove all personal belongings, valuables, and loose items from the vehicle to help us work faster.',
    icon: Car
  }
];

export function HelpModal() {
  const [isOpen, setIsOpen] = useState(false);
  const [expandedIndex, setExpandedIndex] = useState<number | null>(null);

  const toggleExpand = (index: number) => {
    setExpandedIndex(expandedIndex === index ? null : index);
  };

  const handleViewFullFAQ = () => {
    setIsOpen(false);
    setExpandedIndex(null);
    window.location.hash = 'faq';
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleOpenChange = (open: boolean) => {
    setIsOpen(open);
    if (!open) {
      // Reset expanded state when closing
      setTimeout(() => setExpandedIndex(null), 200);
    }
  };

  // Don't show on FAQ page
  const currentHash = window.location.hash.replace('#', '');
  if (currentHash === 'faq') {
    return null;
  }

  return (
    <>
      {/* Floating Help Button */}
      <TooltipProvider>
        <Tooltip delayDuration={200}>
          <TooltipTrigger asChild>
            <div className="fixed top-1/2 -translate-y-1/2 right-6 lg:bottom-8 lg:top-auto lg:translate-y-0 lg:right-8 z-50">
              {/* Pulse Ring */}
              <motion.div
                className="absolute inset-0 rounded-full bg-[#8cc0d6]"
                animate={{
                  scale: [1, 1.3, 1],
                  opacity: [0.6, 0, 0.6],
                }}
                transition={{
                  duration: 2,
                  repeat: Infinity,
                  ease: "easeInOut",
                }}
              />
              
              {/* Main Button */}
              <motion.button
                onClick={() => setIsOpen(true)}
                className="relative w-14 h-14 lg:w-16 lg:h-16 bg-[#8cc0d6] hover:bg-[#7ab0c6] text-white rounded-full shadow-lg hover:shadow-xl transition-all duration-300 flex items-center justify-center group"
                whileHover={{ scale: 1.1, rotate: 5 }}
                whileTap={{ scale: 0.95 }}
                initial={{ opacity: 0, y: 100 }}
                animate={{ 
                  opacity: 1, 
                  y: [100, 0, -10, 0],
                }}
                transition={{ 
                  duration: 0.7, 
                  delay: 0.5,
                  times: [0, 0.7, 0.85, 1]
                }}
              >
                <HelpCircle className="w-7 h-7 lg:w-8 lg:h-8 transition-transform duration-300 group-hover:rotate-[15deg]" />
                
                {/* FAQ Count Badge */}
                <motion.div
                  className="absolute -top-1 -right-1 w-5 h-5 bg-[#56070f] text-white rounded-full flex items-center justify-center text-xs shadow-md"
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{ delay: 0.8, type: "spring", stiffness: 500 }}
                >
                  {topFAQs.length}
                </motion.div>
              </motion.button>
            </div>
          </TooltipTrigger>
          <TooltipContent side="left" className="bg-[#10150f] text-white border-[#8cc0d6]/30">
            <p>Need Help?</p>
          </TooltipContent>
        </Tooltip>
      </TooltipProvider>

      {/* Help Modal */}
      <Dialog open={isOpen} onOpenChange={handleOpenChange}>
        <DialogContent className="max-w-2xl w-[95vw] h-auto max-h-[85vh] sm:max-h-[80vh] overflow-hidden flex flex-col p-0 gap-0">
          <DialogHeader className="px-4 sm:px-6 pt-4 sm:pt-6 pb-3 sm:pb-4 border-b border-gray-200 flex-shrink-0">
            <div className="flex items-center gap-2 sm:gap-3 mb-1 sm:mb-2">
              <div className="w-8 h-8 sm:w-10 sm:h-10 bg-[#8cc0d6]/10 rounded-full flex items-center justify-center flex-shrink-0">
                <HelpCircle className="w-4 h-4 sm:w-5 sm:h-5 text-[#8cc0d6]" />
              </div>
              <DialogTitle className="text-xl sm:text-2xl text-[#10150f]">
                Quick Help
              </DialogTitle>
            </div>
            <DialogDescription className="text-sm sm:text-base text-gray-600">
              Top questions from our customers
            </DialogDescription>
          </DialogHeader>

          {/* Scrollable Content */}
          <div className="flex-1 overflow-y-auto px-4 sm:px-6 py-3 sm:py-4">
            <div className="space-y-2 sm:space-y-3">
              {topFAQs.map((faq, index) => {
                const Icon = faq.icon;
                const isExpanded = expandedIndex === index;

                return (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.05 }}
                    className="border border-gray-200 rounded-lg overflow-hidden hover:border-[#8cc0d6]/50 transition-colors"
                  >
                    <button
                      onClick={() => toggleExpand(index)}
                      className="w-full p-3 sm:p-4 flex items-start gap-2 sm:gap-3 text-left hover:bg-gray-50 transition-colors"
                    >
                      <div className="w-7 h-7 sm:w-8 sm:h-8 rounded-full bg-[#8cc0d6]/10 flex items-center justify-center flex-shrink-0 mt-0.5">
                        <Icon className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-[#8cc0d6]" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <h3 className="text-xs sm:text-sm text-[#10150f] pr-6 sm:pr-8 leading-snug">
                          {faq.question}
                        </h3>
                      </div>
                      <div className="flex-shrink-0">
                        {isExpanded ? (
                          <ChevronUp className="w-4 h-4 sm:w-5 sm:h-5 text-gray-400" />
                        ) : (
                          <ChevronDown className="w-4 h-4 sm:w-5 sm:h-5 text-gray-400" />
                        )}
                      </div>
                    </button>
                    
                    <AnimatePresence>
                      {isExpanded && (
                        <motion.div
                          initial={{ height: 0, opacity: 0 }}
                          animate={{ height: 'auto', opacity: 1 }}
                          exit={{ height: 0, opacity: 0 }}
                          transition={{ duration: 0.2 }}
                          className="overflow-hidden"
                        >
                          <div className="px-3 pb-3 sm:px-4 sm:pb-4 pl-11 sm:pl-15">
                            <p className="text-xs sm:text-sm text-gray-600 leading-relaxed">
                              {faq.answer}
                            </p>
                          </div>
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </motion.div>
                );
              })}
            </div>

            {/* Need More Help Section */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.3 }}
              className="mt-4 sm:mt-6 p-3 sm:p-4 bg-gradient-to-r from-[#8cc0d6]/10 to-[#56070f]/10 rounded-lg border border-[#8cc0d6]/30"
            >
              <h4 className="text-xs sm:text-sm text-[#10150f] mb-1 sm:mb-2">
                Still have questions?
              </h4>
              <p className="text-xs text-gray-600 mb-2 sm:mb-3">
                Visit our full FAQ page for more detailed answers or call us at{' '}
                <a href="tel:+15551234567" className="text-[#56070f] hover:underline font-medium">
                  (555) 123-4567
                </a>
              </p>
              <div className="flex flex-col sm:flex-row gap-2">
                <RippleButton
                  onClick={handleViewFullFAQ}
                  className="flex-1 bg-[#56070f] hover:bg-[#6e0912] text-white text-xs sm:text-sm py-2 sm:py-2.5"
                >
                  View Full FAQ
                  <ExternalLink className="w-3 h-3 sm:w-3.5 sm:h-3.5 ml-1 sm:ml-2" />
                </RippleButton>
                <RippleButton
                  onClick={() => {
                    handleOpenChange(false);
                    window.location.hash = 'booking';
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }}
                  variant="outline"
                  className="flex-1 border-[#8cc0d6] text-[#8cc0d6] hover:bg-[#8cc0d6]/10 text-xs sm:text-sm py-2 sm:py-2.5"
                >
                  Book Now
                </RippleButton>
              </div>
            </motion.div>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}
