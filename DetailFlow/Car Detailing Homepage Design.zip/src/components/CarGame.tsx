import { useState, useEffect, useRef, useCallback } from 'react';
import { X, Truck, Trophy, Zap } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface CarGameProps {
  onClose: () => void;
}

export function CarGame({ onClose }: CarGameProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [score, setScore] = useState(0);
  const [gameOver, setGameOver] = useState(false);
  const [gameStarted, setGameStarted] = useState(false);
  const [showVictory, setShowVictory] = useState(false);
  const [highScore, setHighScore] = useState(() => {
    const saved = localStorage.getItem('cruznCleanHighScore');
    return saved ? parseInt(saved, 10) : 0;
  });
  
  const gameStateRef = useRef({
    truck: { x: 60, y: 0, width: 32, height: 16, velocityY: 0, isJumping: false },
    obstacles: [] as Array<{ x: number; y: number; width: number; height: number; type: 'pothole' | 'puddle' }>,
    bubbles: [] as Array<{ x: number; y: number; size: number; floatSpeed: number }>,
    score: 0,
    speed: 3,
    frameCount: 0,
    groundY: 0
  });

  const jump = useCallback(() => {
    const state = gameStateRef.current;
    if (!state.truck.isJumping && gameStarted && !gameOver) {
      state.truck.velocityY = -11;
      state.truck.isJumping = true;
    }
  }, [gameStarted, gameOver]);

  const startGame = useCallback(() => {
    setGameOver(false);
    setScore(0);
    setShowVictory(false);
    setGameStarted(true);
    const state = gameStateRef.current;
    state.truck.y = 0;
    state.truck.velocityY = 0;
    state.truck.isJumping = false;
    state.obstacles = [];
    state.bubbles = [];
    state.score = 0;
    state.speed = 3;
    state.frameCount = 0;
  }, []);

  useEffect(() => {
    const handleKeyPress = (e: KeyboardEvent) => {
      if (e.code === 'Space' || e.code === 'ArrowUp') {
        e.preventDefault();
        if (!gameStarted) {
          startGame();
        } else {
          jump();
        }
      }
      if (e.code === 'Escape') {
        onClose();
      }
    };

    window.addEventListener('keydown', handleKeyPress);
    return () => window.removeEventListener('keydown', handleKeyPress);
  }, [jump, gameStarted, startGame, onClose]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Disable image smoothing for pixel art
    ctx.imageSmoothingEnabled = false;

    const resizeCanvas = () => {
      canvas.width = 800;
      canvas.height = 400;
      gameStateRef.current.groundY = canvas.height - 60;
    };

    resizeCanvas();

    let animationFrameId: number;

    // 8-bit pixel art truck
    const drawPixelTruck = (x: number, y: number) => {
      const pixelSize = 2;
      
      // Truck bed (longer, lower)
      ctx.fillStyle = '#DC143C';
      ctx.fillRect(x, y + 12, 20, 8);
      
      // Truck bed liner detail
      ctx.fillStyle = '#8B0000';
      ctx.fillRect(x + 2, y + 14, 16, 2);
      
      // Cab (taller, more squared)
      ctx.fillStyle = '#DC143C';
      ctx.fillRect(x + 20, y + 6, 14, 14);
      
      // Roof
      ctx.fillStyle = '#DC143C';
      ctx.fillRect(x + 20, y + 4, 14, 4);
      
      // Windshield
      ctx.fillStyle = '#87CEEB';
      ctx.fillRect(x + 22, y + 8, 6, 6);
      
      // Windshield frame
      ctx.fillStyle = '#000000';
      ctx.fillRect(x + 22, y + 8, 6, 1);
      ctx.fillRect(x + 22, y + 8, 1, 6);
      
      // Front bumper/grille
      ctx.fillStyle = '#696969';
      ctx.fillRect(x + 34, y + 14, 2, 6);
      
      // Grille detail
      ctx.fillStyle = '#000000';
      ctx.fillRect(x + 34, y + 16, 2, 1);
      ctx.fillRect(x + 34, y + 18, 2, 1);
      
      // Headlight
      ctx.fillStyle = '#FFD700';
      ctx.fillRect(x + 33, y + 15, 2, 2);
      
      // Wheels (black)
      ctx.fillStyle = '#000000';
      // Rear wheel
      ctx.fillRect(x + 6, y + 20, 6, 6);
      // Front wheel
      ctx.fillRect(x + 24, y + 20, 6, 6);
      
      // Wheel centers (silver)
      ctx.fillStyle = '#C0C0C0';
      ctx.fillRect(x + 8, y + 22, 2, 2);
      ctx.fillRect(x + 26, y + 22, 2, 2);
      
      // Tire details
      ctx.fillStyle = '#333333';
      ctx.fillRect(x + 7, y + 21, 1, 1);
      ctx.fillRect(x + 7, y + 23, 1, 1);
      ctx.fillRect(x + 25, y + 21, 1, 1);
      ctx.fillRect(x + 25, y + 23, 1, 1);
      
      // Company text on truck bed - larger and better spaced
      ctx.fillStyle = '#FFFFFF';
      ctx.font = 'bold 8px monospace';
      ctx.letterSpacing = '2px';
      ctx.fillText('C C', x + 3, y + 18);
    };

    // 8-bit pothole
    const drawPixelPothole = (x: number, y: number) => {
      const pixelSize = 2;
      
      // Dark hole
      ctx.fillStyle = '#1a1a1a';
      ctx.fillRect(x + 4, y, pixelSize * 8, pixelSize * 3);
      
      // Cracks around it
      ctx.fillStyle = '#333333';
      // Top crack
      ctx.fillRect(x, y - pixelSize, pixelSize * 2, pixelSize);
      ctx.fillRect(x + pixelSize * 3, y - pixelSize * 2, pixelSize * 2, pixelSize);
      // Bottom crack
      ctx.fillRect(x + pixelSize * 10, y + pixelSize * 2, pixelSize * 2, pixelSize);
      ctx.fillRect(x + pixelSize * 14, y + pixelSize, pixelSize * 2, pixelSize);
      
      // Danger indicator (red pixels)
      ctx.fillStyle = '#DC143C';
      ctx.fillRect(x + 2, y - pixelSize, pixelSize, pixelSize);
      ctx.fillRect(x + pixelSize * 12, y + pixelSize * 3, pixelSize, pixelSize);
    };

    // 8-bit water puddle
    const drawPixelPuddle = (x: number, y: number) => {
      const pixelSize = 2;
      
      // Water (cyan gradient effect)
      ctx.fillStyle = '#4DA6FF';
      ctx.fillRect(x + 4, y, pixelSize * 10, pixelSize * 2);
      
      ctx.fillStyle = '#87CEEB';
      ctx.fillRect(x + 6, y + pixelSize, pixelSize * 6, pixelSize);
      
      // Shine/highlights (white)
      ctx.fillStyle = '#FFFFFF';
      ctx.fillRect(x + 8, y, pixelSize, pixelSize);
      ctx.fillRect(x + 12, y, pixelSize, pixelSize);
      
      // Water splash pixels
      ctx.fillStyle = '#4DA6FF';
      ctx.fillRect(x + 2, y + pixelSize, pixelSize, pixelSize);
      ctx.fillRect(x + pixelSize * 15, y + pixelSize, pixelSize, pixelSize);
    };

    // 8-bit soap bubble
    const drawPixelBubble = (x: number, y: number, size: number) => {
      const pixelSize = 2;
      const radius = Math.floor(size / 4);
      
      // Outer circle (cyan)
      ctx.fillStyle = 'rgba(135, 206, 235, 0.6)';
      for (let i = -radius; i <= radius; i++) {
        for (let j = -radius; j <= radius; j++) {
          if (i * i + j * j <= radius * radius) {
            ctx.fillRect(x + i * pixelSize, y + j * pixelSize, pixelSize, pixelSize);
          }
        }
      }
      
      // Highlight (white)
      ctx.fillStyle = 'rgba(255, 255, 255, 0.8)';
      ctx.fillRect(x - pixelSize * 2, y - pixelSize * 2, pixelSize * 2, pixelSize * 2);
    };

    // 8-bit cloud
    const drawPixelCloud = (x: number, y: number, offset: number) => {
      const pixelSize = 3;
      ctx.fillStyle = 'rgba(255, 255, 255, 0.7)';
      
      // Simple blocky cloud
      ctx.fillRect(x + offset, y, pixelSize * 4, pixelSize * 2);
      ctx.fillRect(x + offset + pixelSize, y - pixelSize, pixelSize * 2, pixelSize);
      ctx.fillRect(x + offset - pixelSize, y + pixelSize, pixelSize * 6, pixelSize);
    };

    const checkCollision = (truck: typeof gameStateRef.current.truck, obstacle: typeof gameStateRef.current.obstacles[0]) => {
      // Truck hitbox (adjusted for pixel art - truck is 32px wide, 16px tall + 8px offset)
      const truckLeft = truck.x + 4; // Small padding from left edge
      const truckRight = truck.x + truck.width - 4; // Small padding from right edge
      const truckBottom = gameStateRef.current.groundY - truck.y;
      const truckTop = truckBottom - 24; // Total height including visual offset
      
      // Obstacle hitbox
      const obsLeft = obstacle.x + 6; // Padding to make collision more forgiving
      const obsRight = obstacle.x + obstacle.width - 6;
      const obsTop = obstacle.y - obstacle.height;
      const obsBottom = obstacle.y;
      
      // AABB collision detection
      return (
        truckRight > obsLeft &&
        truckLeft < obsRight &&
        truckBottom > obsTop &&
        truckTop < obsBottom
      );
    };

    const gameLoop = () => {
      if (!gameStarted || gameOver) {
        animationFrameId = requestAnimationFrame(gameLoop);
        return;
      }

      const state = gameStateRef.current;
      const canvas = canvasRef.current;
      if (!canvas) return;

      // 8-bit sky gradient
      const gradient = ctx.createLinearGradient(0, 0, 0, canvas.height);
      gradient.addColorStop(0, '#5C9EE8');
      gradient.addColorStop(1, '#87CEEB');
      ctx.fillStyle = gradient;
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      // Draw pixel clouds
      const cloudOffset = (state.frameCount * 0.3) % 850;
      drawPixelCloud(cloudOffset - 50, 30, 0);
      drawPixelCloud(cloudOffset + 200, 50, 0);
      drawPixelCloud(cloudOffset + 450, 40, 0);

      // 8-bit road
      ctx.fillStyle = '#4A4A4A';
      ctx.fillRect(0, state.groundY, canvas.width, 60);
      
      // Road edge
      ctx.fillStyle = '#696969';
      ctx.fillRect(0, state.groundY, canvas.width, 4);
      
      // Pixelated dashed lines
      const dashWidth = 20;
      const dashGap = 15;
      ctx.fillStyle = '#FFD700';
      for (let i = -((state.frameCount * state.speed) % (dashWidth + dashGap)); i < canvas.width; i += dashWidth + dashGap) {
        ctx.fillRect(i, state.groundY + 25, dashWidth, 4);
      }

      // Update truck physics
      state.truck.velocityY += 0.6;
      state.truck.y += state.truck.velocityY;

      if (state.truck.y >= 0) {
        state.truck.y = 0;
        state.truck.velocityY = 0;
        state.truck.isJumping = false;
      }

      // Draw player truck
      const truckY = state.groundY - state.truck.y - state.truck.height - 8;
      drawPixelTruck(state.truck.x, truckY);

      // Spawn obstacles
      state.frameCount++;
      if (state.frameCount % 110 === 0) {
        const type = Math.random() > 0.5 ? 'pothole' : 'puddle';
        state.obstacles.push({
          x: canvas.width,
          y: state.groundY,
          width: 32,
          height: type === 'pothole' ? 8 : 6, // Increased height for better collision
          type
        });
      }

      // Spawn bubbles
      if (state.frameCount % 25 === 0) {
        state.bubbles.push({
          x: canvas.width,
          y: 50 + Math.random() * (state.groundY - 100),
          size: 12 + Math.random() * 8,
          floatSpeed: 0.3 + Math.random() * 0.5
        });
      }

      // Update and draw bubbles
      state.bubbles = state.bubbles.filter(bubble => {
        bubble.x -= state.speed * 0.6;
        bubble.y -= bubble.floatSpeed;
        drawPixelBubble(bubble.x, bubble.y, bubble.size);
        return bubble.x > -20 && bubble.y > -20;
      });

      // Update and draw obstacles
      state.obstacles = state.obstacles.filter(obstacle => {
        obstacle.x -= state.speed;

        if (obstacle.type === 'pothole') {
          drawPixelPothole(obstacle.x, obstacle.y);
        } else {
          drawPixelPuddle(obstacle.x, obstacle.y);
        }

        if (checkCollision(state.truck, obstacle)) {
          setGameOver(true);
          if (state.score > highScore) {
            setHighScore(state.score);
            localStorage.setItem('cruznCleanHighScore', state.score.toString());
          }
        }

        return obstacle.x > -50;
      });

      // Update score
      state.score = Math.floor(state.frameCount / 10);
      setScore(state.score);

      // Victory at 100 points
      if (state.score >= 100 && !showVictory) {
        setShowVictory(true);
        setGameOver(true);
        if (state.score > highScore) {
          setHighScore(state.score);
          localStorage.setItem('cruznCleanHighScore', state.score.toString());
        }
      }

      // Increase speed
      if (state.frameCount % 350 === 0 && state.speed < 6) {
        state.speed += 0.25;
      }

      animationFrameId = requestAnimationFrame(gameLoop);
    };

    gameLoop();

    return () => {
      cancelAnimationFrame(animationFrameId);
    };
  }, [gameStarted, gameOver, showVictory, highScore]);

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 bg-black/90 backdrop-blur-sm z-50 flex items-center justify-center p-4"
        style={{ imageRendering: 'pixelated' }}
      >
        <motion.div
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          exit={{ scale: 0.9, opacity: 0 }}
          className="bg-black rounded-lg shadow-2xl overflow-hidden max-w-4xl w-full border-4 border-[#DC143C]"
        >
          {/* 8-bit Header */}
          <div className="bg-gradient-to-r from-[#DC143C] to-[#8B0000] px-6 py-3 flex items-center justify-between border-b-4 border-black relative overflow-hidden">
            {/* Retro scanline effect */}
            <div className="absolute inset-0 opacity-10 pointer-events-none" style={{
              backgroundImage: 'repeating-linear-gradient(0deg, transparent, transparent 2px, black 2px, black 4px)'
            }}></div>
            
            <div className="flex items-center gap-4 relative z-10">
              <div className="w-12 h-12 bg-[#FFD700] rounded flex items-center justify-center border-2 border-black">
                <Truck className="w-7 h-7 text-[#DC143C]" style={{ filter: 'drop-shadow(1px 1px 0 black)' }} />
              </div>
              <div>
                <h2 className="text-white text-xl uppercase tracking-wider" style={{ 
                  fontFamily: 'monospace',
                  textShadow: '2px 2px 0 black'
                }}>
                  BRIAN'S DELIVERY
                </h2>
                <p className="text-[#FFD700] text-xs uppercase" style={{ fontFamily: 'monospace' }}>
                  8-BIT EDITION
                </p>
              </div>
            </div>
            <button
              onClick={onClose}
              className="text-white hover:text-[#FFD700] transition-colors relative z-10"
              aria-label="Close game"
            >
              <X className="w-7 h-7" style={{ filter: 'drop-shadow(2px 2px 0 black)' }} />
            </button>
          </div>

          {/* 8-bit Score Bar */}
          <div className="bg-black px-6 py-4 flex items-center justify-between border-b-4 border-[#DC143C]">
            <div className="flex items-center gap-8">
              <div>
                <div className="text-[#FFD700] text-xs uppercase tracking-wider mb-1" style={{ fontFamily: 'monospace' }}>
                  DISTANCE
                </div>
                <div className="text-white text-3xl" style={{ 
                  fontFamily: 'monospace',
                  textShadow: '3px 3px 0 #DC143C'
                }}>
                  {score.toString().padStart(3, '0')}
                </div>
              </div>
              <div className="w-px h-12 bg-[#DC143C]"></div>
              <div>
                <div className="text-[#FFD700] text-xs uppercase tracking-wider mb-1 flex items-center gap-2" style={{ fontFamily: 'monospace' }}>
                  <Trophy className="w-4 h-4" /> HI-SCORE
                </div>
                <div className="text-[#87CEEB] text-3xl" style={{ 
                  fontFamily: 'monospace',
                  textShadow: '3px 3px 0 #1a4d7a'
                }}>
                  {highScore.toString().padStart(3, '0')}
                </div>
              </div>
              <div className="w-px h-12 bg-[#DC143C]"></div>
              <div className="flex items-center gap-2">
                <Zap className="w-5 h-5 text-[#FFD700]" />
                <div className="text-white text-sm" style={{ fontFamily: 'monospace' }}>
                  {score >= 100 ? 'ARRIVED' : `${Math.floor((score / 100) * 10)}/10 PTS`}
                </div>
              </div>
            </div>
          </div>

          {/* Game Canvas */}
          <div className="relative bg-black flex items-center justify-center p-6">
            <div className="relative">
              <canvas
                ref={canvasRef}
                onClick={() => {
                  if (!gameStarted) {
                    startGame();
                  } else {
                    jump();
                  }
                }}
                className="cursor-pointer border-4 border-[#4A4A4A] shadow-2xl"
                style={{ imageRendering: 'pixelated' }}
              />
              
              {/* CRT effect overlay */}
              <div className="absolute inset-0 pointer-events-none opacity-20" style={{
                backgroundImage: 'repeating-linear-gradient(0deg, transparent, transparent 2px, rgba(0,0,0,0.3) 2px, rgba(0,0,0,0.3) 4px)',
                borderRadius: '4px'
              }}></div>
            </div>

            {/* Start Screen */}
            {!gameStarted && !gameOver && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="absolute inset-0 bg-black/95 flex items-center justify-center m-6"
              >
                <div className="text-center text-white px-6 max-w-md">
                  <motion.div
                    animate={{ scale: [1, 1.1, 1] }}
                    transition={{ duration: 1, repeat: Infinity }}
                    className="text-6xl mb-6 text-[#FFD700]" 
                    style={{ 
                      fontFamily: 'monospace',
                      textShadow: '4px 4px 0 #DC143C, -2px -2px 0 #87CEEB'
                    }}
                  >
                    READY?
                  </motion.div>
                  <p className="text-lg mb-8 text-[#87CEEB] uppercase" style={{ fontFamily: 'monospace' }}>
                    BRIAN'S ON THE WAY!<br />
                    HELP HIM DODGE POTHOLES
                  </p>
                  <motion.button
                    onClick={startGame}
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    className="px-12 py-4 bg-[#DC143C] hover:bg-[#FF1744] text-white rounded border-4 border-white transition-colors text-2xl uppercase shadow-xl"
                    style={{ 
                      fontFamily: 'monospace',
                      textShadow: '2px 2px 0 black'
                    }}
                  >
                    START
                  </motion.button>
                  <p className="mt-6 text-sm text-gray-400 uppercase" style={{ fontFamily: 'monospace' }}>
                    PRESS SPACE OR CLICK TO JUMP
                  </p>
                </div>
              </motion.div>
            )}

            {/* Victory Screen */}
            {showVictory && (
              <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                className="absolute inset-0 bg-gradient-to-br from-[#FFD700] to-[#FF8C00] flex items-center justify-center m-6"
              >
                <div className="text-center px-6">
                  <motion.div
                    initial={{ y: -50, opacity: 0 }}
                    animate={{ y: 0, opacity: 1 }}
                    transition={{ type: "spring", delay: 0.2 }}
                    className="text-8xl mb-6"
                    style={{
                      fontFamily: 'monospace',
                      color: '#000',
                      textShadow: '6px 6px 0 #DC143C'
                    }}
                  >
                    VICTORY
                  </motion.div>
                  <h3 className="text-5xl mb-4 text-black uppercase" style={{ 
                    fontFamily: 'monospace',
                    textShadow: '3px 3px 0 white'
                  }}>
                    CAR ARRIVED!
                  </h3>
                  <p className="text-2xl mb-8 text-[#8B0000] uppercase" style={{ fontFamily: 'monospace' }}>
                    TIME TO MAKE IT SHINE!
                  </p>
                  <div className="flex gap-4 justify-center flex-wrap">
                    <motion.button
                      onClick={startGame}
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                      className="px-8 py-4 bg-black text-[#FFD700] rounded border-4 border-black transition-all text-xl uppercase"
                      style={{ fontFamily: 'monospace' }}
                    >
                      PLAY AGAIN
                    </motion.button>
                    <motion.button
                      onClick={onClose}
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                      className="px-8 py-4 bg-white text-black rounded border-4 border-black transition-all text-xl uppercase"
                      style={{ fontFamily: 'monospace' }}
                    >
                      EXIT
                    </motion.button>
                  </div>
                </div>
              </motion.div>
            )}

            {/* Game Over Screen */}
            {gameOver && !showVictory && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="absolute inset-0 bg-black/95 flex items-center justify-center m-6"
              >
                <div className="text-center text-white px-6">
                  <motion.div
                    animate={{ rotate: [0, -5, 5, -5, 5, 0] }}
                    transition={{ duration: 0.5 }}
                    className="text-7xl mb-6 text-[#DC143C]"
                    style={{ 
                      fontFamily: 'monospace',
                      textShadow: '5px 5px 0 black'
                    }}
                  >
                    CRASH!
                  </motion.div>
                  <p className="text-3xl mb-4 text-[#FFD700] uppercase" style={{ fontFamily: 'monospace' }}>
                    DISTANCE: {score}
                  </p>
                  <p className="text-lg mb-8 text-[#87CEEB] uppercase" style={{ fontFamily: 'monospace' }}>
                    {score >= 50 ? "SO CLOSE! TRY AGAIN!" : "KEEP PRACTICING!"}
                  </p>
                  <div className="flex gap-4 justify-center flex-wrap">
                    <motion.button
                      onClick={startGame}
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                      className="px-8 py-4 bg-[#DC143C] hover:bg-[#FF1744] text-white rounded border-4 border-white transition-all text-xl uppercase"
                      style={{ fontFamily: 'monospace' }}
                    >
                      RETRY
                    </motion.button>
                    <motion.button
                      onClick={onClose}
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                      className="px-8 py-4 bg-gray-700 hover:bg-gray-600 text-white rounded border-4 border-gray-500 transition-all text-xl uppercase"
                      style={{ fontFamily: 'monospace' }}
                    >
                      QUIT
                    </motion.button>
                  </div>
                </div>
              </motion.div>
            )}
          </div>

          {/* 8-bit Instructions Footer */}
          {gameStarted && !gameOver && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-[#DC143C] px-6 py-3 text-center border-t-4 border-black"
            >
              <div className="text-white text-sm uppercase flex items-center justify-center gap-3" style={{ fontFamily: 'monospace' }}>
                <span>CONTROLS:</span>
                <kbd className="px-3 py-1 bg-black rounded text-[#FFD700] border-2 border-white">SPACE</kbd>
                <span>OR</span>
                <kbd className="px-3 py-1 bg-black rounded text-[#FFD700] border-2 border-white">CLICK</kbd>
                <span>TO JUMP</span>
              </div>
            </motion.div>
          )}
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}
