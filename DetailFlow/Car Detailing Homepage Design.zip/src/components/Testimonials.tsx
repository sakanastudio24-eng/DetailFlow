import { motion } from 'motion/react';
import { Star, Quote } from 'lucide-react';

const testimonials = [
  {
    name: "Michael Chen",
    role: "Tesla Model S Owner",
    content: "DetailCraft brought my car back to showroom condition. The attention to detail is incredible, and the ceramic coating has made maintenance so much easier.",
    rating: 5
  },
  {
    name: "Sarah Johnson",
    role: "BMW X5 Owner",
    content: "I've tried several detailing services, but none compare to the quality here. My car looks better than the day I bought it. Highly recommend!",
    rating: 5
  },
  {
    name: "David Martinez",
    role: "Mercedes C-Class Owner",
    content: "Professional, thorough, and worth every penny. The team was friendly and the results speak for themselves. Will definitely be back!",
    rating: 5
  }
];

export function Testimonials() {
  return (
    <section className="relative py-24 px-4 bg-[#10150f]">
      <div className="max-w-7xl mx-auto">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl text-white mb-4">
            What Our Clients Say
          </h2>
          <p className="text-gray-400 max-w-2xl mx-auto">
            Don't just take our word for it - hear from our satisfied customers
          </p>
        </motion.div>

        {/* Testimonials Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className="bg-white/5 backdrop-blur-sm border border-white/10 rounded-xl p-8 hover:bg-white/10 transition-all group"
            >
              {/* Quote Icon */}
              <Quote className="w-10 h-10 text-[#8cc0d6] mb-4 transition-transform duration-300 group-hover:rotate-[5deg]" />

              {/* Rating */}
              <div className="flex gap-1 mb-4">
                {[...Array(testimonial.rating)].map((_, i) => (
                  <Star key={i} className="w-5 h-5 fill-[#8cc0d6] text-[#8cc0d6]" />
                ))}
              </div>

              {/* Content */}
              <p className="text-gray-300 mb-6 leading-relaxed">
                "{testimonial.content}"
              </p>

              {/* Author */}
              <div>
                <div className="text-white mb-1">{testimonial.name}</div>
                <div className="text-gray-500 text-sm">{testimonial.role}</div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
