import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Menu, X, Phone, ShoppingCart, Home, Briefcase, Image, FileText, Calendar, HelpCircle } from 'lucide-react';
import { useCart } from '../context/CartContext';
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetDescription, SheetTrigger } from './ui/sheet';
import { Button } from './ui/button';
import { RippleButton } from './ui/ripple-button';

interface NavigationProps {
  currentPage: string;
  onNavigate: (page: string) => void;
  isHomePage?: boolean;
}

export function Navigation({ currentPage, onNavigate, isHomePage = false }: NavigationProps) {
  const [scrollY, setScrollY] = useState(0);
  const [scrollDirection, setScrollDirection] = useState<'up' | 'down'>('up');
  const [lastScrollY, setLastScrollY] = useState(0);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const { items, removeItem, totalPrice, itemCount, getTotalItems, toggleDock, openDock } = useCart();

  useEffect(() => {
    const handleScroll = () => {
      const currentScrollY = window.scrollY;
      
      if (currentScrollY > lastScrollY) {
        setScrollDirection('down');
      } else {
        setScrollDirection('up');
      }
      
      setScrollY(currentScrollY);
      setLastScrollY(currentScrollY);
    };
    
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, [lastScrollY]);

  const handleNavigation = (page: string, scrollToTop: boolean = true) => {
    onNavigate(page);
    setIsMobileMenuOpen(false);
    if (scrollToTop) {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  // Calculate background opacity based on scroll
  const bgOpacity = Math.min(scrollY / 100, 1);
  const isScrolled = scrollY > 50;
  // On home page: only show when scrolling up (and not at the very top)
  // On other pages: show when scrolling up OR near the top
  const shouldShowNav = isHomePage 
    ? (scrollDirection === 'up' && scrollY > 50)
    : (scrollDirection === 'up' || scrollY <= 50);

  // Mobile opacity: start at 0 on home page, full opacity on other pages or when scrolled
  const mobileOpacity = isHomePage ? bgOpacity : 1;

  return (
    <>
      <nav
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ease-out ${
          shouldShowNav ? 'md:translate-y-0 md:opacity-100' : 'md:-translate-y-full md:opacity-0'
        }`}
        style={{
          backgroundColor: `rgba(140, 192, 214, ${bgOpacity})`,
          backdropFilter: isScrolled ? 'blur(10px)' : 'none',
          boxShadow: isScrolled ? '0 2px 10px rgba(0,0,0,0.1)' : 'none',
          opacity: window.innerWidth < 768 ? mobileOpacity : undefined
        }}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 md:px-0">
          <div className="flex items-center justify-between h-20 md:h-14 md:px-8">
            {/* Logo - Temporary Wordmark (TODO: Replace with vector logo when delivered) */}
            <div className="flex items-center">
              <h1 className="text-2xl text-[#10150f]" style={{ fontFamily: 'Manrope, sans-serif', fontWeight: 600, letterSpacing: '0.02em' }}>
                Cruzn <span className="text-white">Clean</span>
              </h1>
            </div>

          {/* Desktop Menu */}
          <div className="hidden md:flex items-center gap-6 lg:gap-8">
            <button
              onClick={() => handleNavigation('home')}
              className={`relative py-1 transition-all duration-300 group ${
                currentPage === 'home' ? 'text-[#10150f]' : 'text-[#10150f]/70 hover:text-[#10150f]'
              }`}
            >
              <span className="relative z-10">Home</span>
              <span className={`absolute -bottom-1 left-0 h-0.5 bg-[#56070f] transition-all duration-300 ease-out ${
                currentPage === 'home' ? 'w-full' : 'w-0 group-hover:w-full'
              }`}></span>
            </button>
            <button
              onClick={() => handleNavigation('packages')}
              className={`relative py-1 transition-all duration-300 group ${
                currentPage === 'packages' ? 'text-[#10150f]' : 'text-[#10150f]/70 hover:text-[#10150f]'
              }`}
            >
              <span className="relative z-10">Services</span>
              <span className={`absolute -bottom-1 left-0 h-0.5 bg-[#56070f] transition-all duration-300 ease-out ${
                currentPage === 'packages' ? 'w-full' : 'w-0 group-hover:w-full'
              }`}></span>
            </button>
            <button
              onClick={() => handleNavigation('gallery')}
              className={`relative py-1 transition-all duration-300 group ${
                currentPage === 'gallery' ? 'text-[#10150f]' : 'text-[#10150f]/70 hover:text-[#10150f]'
              }`}
            >
              <span className="relative z-10">Gallery</span>
              <span className={`absolute -bottom-1 left-0 h-0.5 bg-[#56070f] transition-all duration-300 ease-out ${
                currentPage === 'gallery' ? 'w-full' : 'w-0 group-hover:w-full'
              }`}></span>
            </button>
            <button
              onClick={() => handleNavigation('quote')}
              className={`relative py-1 transition-all duration-300 group ${
                currentPage === 'quote' ? 'text-[#10150f]' : 'text-[#10150f]/70 hover:text-[#10150f]'
              }`}
            >
              <span className="relative z-10">Quote</span>
              <span className={`absolute -bottom-1 left-0 h-0.5 bg-[#56070f] transition-all duration-300 ease-out ${
                currentPage === 'quote' ? 'w-full' : 'w-0 group-hover:w-full'
              }`}></span>
            </button>

            {/* Phone Number */}
            <a
              href="tel:+15551234567"
              className="hidden lg:flex items-center gap-2 text-[#10150f] hover:text-[#56070f] transition-colors duration-300"
            >
              <Phone className="w-4 h-4" />
              <span className="text-sm">(555) 123-4567</span>
            </a>

            {/* Book Now - Pill Button */}
            <button
              onClick={() => handleNavigation('booking')}
              className="relative px-6 lg:px-8 py-2.5 bg-[#56070f] text-white rounded-full transition-all duration-300 shadow-lg hover:shadow-xl hover:scale-105 overflow-hidden group"
            >
              <span className="relative z-10">Book Now</span>
              <span className="absolute inset-0 -translate-x-full group-hover:translate-x-full transition-transform duration-700 bg-gradient-to-r from-transparent via-white/30 to-transparent skew-x-12"></span>
            </button>
            
            {/* FAQ Icon */}
            <button
              onClick={() => handleNavigation('faq')}
              className="relative p-2 text-[#10150f] hover:text-[#56070f] transition-all duration-300 hover:scale-110 group"
              title="Frequently Asked Questions"
            >
              <HelpCircle className="w-5 h-5 transition-transform duration-300 group-hover:rotate-[5deg]" />
            </button>
            
            {/* Vehicle Dock Toggle */}
            <button 
              onClick={() => toggleDock()}
              className="relative p-2 text-[#10150f] hover:text-[#56070f] transition-all duration-300 hover:scale-110 group"
              title="My Vehicles"
            >
              <ShoppingCart className="w-5 h-5 transition-transform duration-300 group-hover:rotate-[5deg]" />
              {getTotalItems() > 0 && (
                <span className="absolute -top-1 -right-1 w-5 h-5 bg-[#56070f] text-white text-xs rounded-full flex items-center justify-center animate-pulse">
                  {getTotalItems()}
                </span>
              )}
            </button>
            
            {/* Old Cart Sheet - Kept for reference but hidden */}
            <Sheet>
              <SheetTrigger asChild>
                <button className="hidden relative p-2 text-[#10150f] hover:text-[#56070f] transition-all duration-300 hover:scale-110 group">
                  <ShoppingCart className="w-5 h-5 transition-transform duration-300 group-hover:rotate-[5deg]" />
                  {itemCount > 0 && (
                    <span className="absolute -top-1 -right-1 w-5 h-5 bg-[#56070f] text-white text-xs rounded-full flex items-center justify-center animate-pulse">
                      {itemCount}
                    </span>
                  )}
                </button>
              </SheetTrigger>
              <SheetContent>
                <SheetHeader>
                  <SheetTitle>Your Cart</SheetTitle>
                  <SheetDescription>
                    Review your selected services and proceed to booking
                  </SheetDescription>
                </SheetHeader>
                <div className="mt-6 space-y-4">
                  {items.length === 0 ? (
                    <p className="text-gray-500 text-center py-8">Your cart is empty</p>
                  ) : (
                    <>
                      {items.map(item => (
                        <div key={item.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg gap-3">
                          <div className="flex-1 min-w-0">
                            <p className="text-sm text-[#10150f] truncate">{item.name}</p>
                            <p className="text-xs text-gray-500">{item.type}</p>
                          </div>
                          <div className="flex items-center gap-3 flex-shrink-0">
                            <span className="text-[#56070f]">${item.price}</span>
                            <button
                              onClick={() => removeItem(item.id)}
                              className="text-red-500 hover:text-red-700 text-sm whitespace-nowrap"
                            >
                              Remove
                            </button>
                          </div>
                        </div>
                      ))}
                      <div className="pt-4 border-t px-1">
                        <div className="flex items-center justify-between mb-4">
                          <span className="text-lg">Total:</span>
                          <span className="text-2xl text-[#56070f]">${totalPrice}</span>
                        </div>
                        <Button 
                          className="w-full bg-[#56070f] hover:bg-[#6e0912] shadow-md hover:shadow-lg transition-all"
                          onClick={() => handleNavigation('booking', false)}
                        >
                          Proceed to Booking
                        </Button>
                      </div>
                    </>
                  )}
                </div>
              </SheetContent>
            </Sheet>
          </div>

          {/* Mobile FAQ & Vehicle Dock */}
          <div className="md:hidden flex items-center gap-1">
            <button
              onClick={() => handleNavigation('faq')}
              className="relative p-2 text-[#10150f]"
              title="FAQ"
            >
              <HelpCircle className="w-5 h-5" />
            </button>
            <button 
              onClick={() => toggleDock()}
              className="relative p-2 text-[#10150f]"
              title="My Vehicles"
            >
              <ShoppingCart className="w-5 h-5" />
              {getTotalItems() > 0 && (
                <span className="absolute -top-1 -right-1 w-5 h-5 bg-[#56070f] text-white text-xs rounded-full flex items-center justify-center">
                  {getTotalItems()}
                </span>
              )}
            </button>
            
            {/* Hidden old sheet */}
            <Sheet>
              <SheetTrigger asChild>
                <button className="hidden relative p-2 text-[#10150f]">
                  <ShoppingCart className="w-5 h-5" />
                  {itemCount > 0 && (
                    <span className="absolute -top-1 -right-1 w-5 h-5 bg-[#56070f] text-white text-xs rounded-full flex items-center justify-center">
                      {itemCount}
                    </span>
                  )}
                </button>
              </SheetTrigger>
              <SheetContent className="px-6">
                <SheetHeader>
                  <SheetTitle>Your Cart</SheetTitle>
                  <SheetDescription>
                    Review your selected services and proceed to booking
                  </SheetDescription>
                </SheetHeader>
                <div className="mt-6 space-y-4">
                  {items.length === 0 ? (
                    <p className="text-gray-500 text-center py-8">Your cart is empty</p>
                  ) : (
                    <>
                      {items.map(item => (
                        <div key={item.id} className="flex items-start justify-between p-4 bg-gray-50 rounded-lg gap-4">
                          <div className="flex-1 min-w-0">
                            <p className="text-sm text-[#10150f]">{item.name}</p>
                            <p className="text-xs text-gray-500 mt-1">{item.type}</p>
                          </div>
                          <div className="flex flex-col items-end gap-2 flex-shrink-0">
                            <span className="text-[#56070f]">${item.price}</span>
                            <button
                              onClick={() => removeItem(item.id)}
                              className="text-red-500 hover:text-red-700 text-xs"
                            >
                              Remove
                            </button>
                          </div>
                        </div>
                      ))}
                      <div className="pt-4 border-t px-2">
                        <div className="flex items-center justify-between mb-4">
                          <span className="text-lg">Total:</span>
                          <span className="text-2xl text-[#56070f]">${totalPrice}</span>
                        </div>
                        <Button 
                          className="w-full bg-[#56070f] hover:bg-[#6e0912] shadow-md hover:shadow-lg transition-all"
                          onClick={() => handleNavigation('booking', false)}
                        >
                          Proceed to Booking
                        </Button>
                      </div>
                    </>
                  )}
                </div>
              </SheetContent>
            </Sheet>
          </div>
          </div>
        </div>
      </nav>

      {/* Mobile Bottom Navigation */}
      <nav className="md:hidden fixed bottom-0 left-0 right-0 z-50 bg-white border-t border-gray-200 shadow-lg">
        <div className="grid grid-cols-5 h-16">
          <button
            onClick={() => handleNavigation('home')}
            className={`flex flex-col items-center justify-center gap-1 transition-colors ${
              currentPage === 'home' ? 'text-[#56070f]' : 'text-gray-400'
            }`}
          >
            <Home className="w-5 h-5" />
            <span className="text-xs">Home</span>
          </button>
          <button
            onClick={() => handleNavigation('packages')}
            className={`flex flex-col items-center justify-center gap-1 transition-colors ${
              currentPage === 'packages' ? 'text-[#56070f]' : 'text-gray-400'
            }`}
          >
            <Briefcase className="w-5 h-5" />
            <span className="text-xs">Services</span>
          </button>
          <button
            onClick={() => handleNavigation('gallery')}
            className={`flex flex-col items-center justify-center gap-1 transition-colors ${
              currentPage === 'gallery' ? 'text-[#56070f]' : 'text-gray-400'
            }`}
          >
            <Image className="w-5 h-5" />
            <span className="text-xs">Gallery</span>
          </button>
          <button
            onClick={() => handleNavigation('quote')}
            className={`flex flex-col items-center justify-center gap-1 transition-colors ${
              currentPage === 'quote' ? 'text-[#56070f]' : 'text-gray-400'
            }`}
          >
            <FileText className="w-5 h-5" />
            <span className="text-xs">Quote</span>
          </button>
          <button
            onClick={() => handleNavigation('booking')}
            className={`flex flex-col items-center justify-center gap-1 transition-colors ${
              currentPage === 'booking' ? 'text-[#56070f]' : 'text-gray-400'
            }`}
          >
            <Calendar className="w-5 h-5" />
            <span className="text-xs">Book</span>
          </button>
        </div>
      </nav>
    </>
  );
}
