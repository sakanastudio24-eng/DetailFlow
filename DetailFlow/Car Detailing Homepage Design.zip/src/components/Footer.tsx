import { useState, useEffect, useRef } from 'react';
import { motion } from 'motion/react';
import { Instagram, Facebook, Twitter, MapPin, Phone, Mail, Truck, HelpCircle } from 'lucide-react';
import { CarGame } from './CarGame';

export function Footer() {
  const [showGame, setShowGame] = useState(false);
  const konamiCode = useRef<string[]>([]);
  const konamiSequence = ['ArrowUp', 'ArrowUp', 'ArrowDown', 'ArrowDown'];

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      konamiCode.current.push(e.key);
      konamiCode.current = konamiCode.current.slice(-4);

      if (konamiCode.current.join(',') === konamiSequence.join(',')) {
        setShowGame(true);
        konamiCode.current = [];
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  return (
    <footer className="relative bg-[#f8f8f8] overflow-hidden">
      {/* Wave Top Divider */}
      <div className="absolute top-0 left-0 right-0 w-full overflow-hidden leading-none">
        <svg 
          className="relative block w-full h-12 md:h-16" 
          viewBox="0 0 1200 120" 
          preserveAspectRatio="none"
        >
          <path 
            d="M321.39,56.44c58-10.79,114.16-30.13,172-41.86,82.39-16.72,168.19-17.73,250.45-.39C823.78,31,906.67,72,985.66,92.83c70.05,18.48,146.53,26.09,214.34,3V0H0V27.35A600.21,600.21,0,0,0,321.39,56.44Z" 
            className="fill-white"
          />
        </svg>
      </div>

      {/* Subtle Cruzn Clean watermark pattern */}
      <div className="absolute inset-0 opacity-[0.02] pointer-events-none overflow-hidden">
        {Array.from({ length: 8 }).map((_, i) => (
          <motion.div
            key={i}
            className="absolute text-[180px] text-[#10150f] select-none"
            style={{
              top: `${(i % 2) * 50}%`,
              left: `${(i * 15) % 100}%`,
              transform: 'rotate(-15deg)'
            }}
            animate={{
              opacity: [0.02, 0.04, 0.02],
              scale: [1, 1.05, 1]
            }}
            transition={{
              duration: 8,
              repeat: Infinity,
              delay: i * 0.5
            }}
          >
            Cruzn Clean
          </motion.div>
        ))}
      </div>

      <div className="relative pt-20 md:pt-24 pb-16 px-4 pb-24 md:pb-16">
        <div className="max-w-7xl mx-auto">
          {/* 3 Column Grid */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-12 md:gap-16 mb-12">
            
            {/* Brand Column */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5 }}
              className="md:pr-8"
            >
              <h3 className="text-2xl text-[#10150f] mb-4">
                Cruzn <span className="text-[#56070f]">Clean</span>
              </h3>
              <p className="text-gray-600 mb-6 leading-relaxed">
                Mobile detailing that brings showroom shine to your driveway. Proudly serving Yorba Linda, Placentia, Brea, and surrounding areas.
              </p>
              
              {/* Social Media */}
              <div className="flex gap-4 mb-6">
                <a
                  href="https://instagram.com"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-10 h-10 rounded-full bg-gradient-to-br from-purple-600 to-pink-500 flex items-center justify-center text-white hover:scale-110 transition-transform"
                  aria-label="Instagram"
                >
                  <Instagram className="w-5 h-5" />
                </a>
                <a
                  href="https://facebook.com"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-10 h-10 rounded-full bg-[#1877f2] flex items-center justify-center text-white hover:scale-110 transition-transform"
                  aria-label="Facebook"
                >
                  <Facebook className="w-5 h-5" />
                </a>
                <a
                  href="https://twitter.com"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-10 h-10 rounded-full bg-black flex items-center justify-center text-white hover:scale-110 transition-transform"
                  aria-label="Twitter"
                >
                  <Twitter className="w-5 h-5" />
                </a>
              </div>

              {/* Business Hours */}
              <div className="mt-6">
                <h5 className="text-sm text-[#10150f] mb-3">Business Hours</h5>
                <ul className="space-y-2 text-sm text-gray-600">
                  <li>Mon - Fri: 8:00 AM - 6:00 PM</li>
                  <li>Saturday: 9:00 AM - 5:00 PM</li>
                  <li>Sunday: Closed</li>
                </ul>
              </div>
            </motion.div>

            {/* Quick Links Column */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.1 }}
              className="md:px-8"
            >
              <h4 className="text-[#10150f] mb-4">Quick Links</h4>
              <ul className="space-y-3 mb-8">
                <li>
                  <a href="#home" className="text-gray-600 hover:text-[#56070f] transition-colors inline-block">
                    Home
                  </a>
                </li>
                <li>
                  <a href="#packages" className="text-gray-600 hover:text-[#56070f] transition-colors inline-block">
                    Packages & Services
                  </a>
                </li>
                <li>
                  <a href="#gallery" className="text-gray-600 hover:text-[#56070f] transition-colors inline-block">
                    Gallery
                  </a>
                </li>
                <li>
                  <a href="#booking" className="text-gray-600 hover:text-[#56070f] transition-colors inline-block">
                    Book Now
                  </a>
                </li>
                <li>
                  <a href="#quote" className="text-gray-600 hover:text-[#56070f] transition-colors inline-block">
                    Request Quote
                  </a>
                </li>
                <li>
                  <a href="#contact" className="text-gray-600 hover:text-[#56070f] transition-colors inline-block">
                    Contact
                  </a>
                </li>
              </ul>

              {/* Need Help Section */}
              <div className="bg-gradient-to-br from-[#8cc0d6]/10 to-white border-2 border-[#8cc0d6]/20 rounded-lg p-4">
                <div className="flex items-start gap-3">
                  <div className="w-10 h-10 bg-[#8cc0d6] rounded-full flex items-center justify-center flex-shrink-0">
                    <HelpCircle className="w-5 h-5 text-white" />
                  </div>
                  <div>
                    <h5 className="text-[#10150f] mb-1">Need Help?</h5>
                    <p className="text-xs text-gray-600 mb-2">Check our FAQ for quick answers</p>
                    <a 
                      href="#faq" 
                      className="text-sm text-[#56070f] hover:text-[#6e0912] transition-colors inline-flex items-center gap-1"
                    >
                      Visit FAQ →
                    </a>
                  </div>
                </div>
              </div>
            </motion.div>

            {/* Contact Column */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.2 }}
              className="md:pl-8"
            >
              <h4 className="text-[#10150f] mb-4">Contact Us</h4>
              <ul className="space-y-4 mb-6">
                <li className="flex items-start gap-3 text-gray-600">
                  <MapPin className="w-5 h-5 text-[#56070f] mt-0.5 flex-shrink-0" />
                  <span>123 Detail Street, Auto City, AC 12345</span>
                </li>
                <li className="flex items-center gap-3">
                  <Phone className="w-5 h-5 text-[#56070f] flex-shrink-0" />
                  <a href="tel:+15551234567" className="text-gray-600 hover:text-[#56070f] transition-colors">
                    (555) 123-4567
                  </a>
                </li>
                <li className="flex items-center gap-3">
                  <Mail className="w-5 h-5 text-[#56070f] flex-shrink-0" />
                  <a href="mailto:info@cruznclean.com" className="text-gray-600 hover:text-[#56070f] transition-colors">
                    info@cruznclean.com
                  </a>
                </li>
              </ul>

              {/* CTA Button */}
              <a
                href="#booking"
                className="inline-block w-full md:w-auto px-6 py-3 bg-[#56070f] text-white rounded-lg text-center hover:bg-[#6e0912] transition-all duration-300 shadow-md hover:shadow-lg hover:scale-105"
              >
                Book Your Detail
              </a>

              {/* Desktop Only - Car Game Easter Egg */}
              <div className="hidden md:block mt-6">
                <motion.button
                  onClick={() => setShowGame(true)}
                  className="group flex items-center gap-4 text-gray-400 hover:text-[#56070f] transition-colors text-xs w-full"
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  aria-label="Play mini game"
                >
                  <motion.div
                    animate={{ x: [0, 10, 0] }}
                    transition={{ duration: 2.5, repeat: Infinity, ease: "easeInOut" }}
                  >
                    <Truck className="w-5 h-5" />
                  </motion.div>
                  <span className="opacity-60 group-hover:opacity-100 transition-opacity">
                    Play while you wait
                  </span>
                </motion.button>
                <p className="text-[10px] text-gray-300 mt-1 ml-6">
                  or press ↑↑↓↓
                </p>
              </div>
            </motion.div>
          </div>

          {/* Bottom Bar */}
          <div className="pt-8 border-t border-gray-300">
            <div className="flex flex-col items-center gap-4 text-center">
              {/* Links Row */}
              <div className="flex flex-wrap items-center justify-center gap-3 md:gap-6 text-sm">
                <a href="#privacy" className="text-gray-600 hover:text-[#56070f] transition-colors">
                  Privacy Policy
                </a>
                <span className="text-gray-300">•</span>
                <a href="#terms" className="text-gray-600 hover:text-[#56070f] transition-colors">
                  Terms of Service
                </a>
                <span className="text-gray-300">•</span>
                <a href="#faq" className="text-gray-600 hover:text-[#56070f] transition-colors">
                  FAQ
                </a>
              </div>

              {/* Copyright & Credit Row */}
              <div className="flex flex-col md:flex-row items-center gap-2 md:gap-4 text-sm">
                <p className="text-gray-600">
                  © 2025 Cruzn Clean. All rights reserved.
                </p>
                <span className="hidden md:inline text-gray-300">•</span>
                <a 
                  href="https://sakanastudio.com" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="text-gray-600 hover:text-[#8cc0d6] transition-colors flex items-center gap-1.5"
                >
                  Designed by <span className="text-[#8cc0d6]">Sakana Studio</span>
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Car Game Modal */}
      {showGame && <CarGame onClose={() => setShowGame(false)} />}
    </footer>
  );
}
