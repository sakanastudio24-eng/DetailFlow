import { motion } from 'motion/react';
import { Check } from 'lucide-react';
import { RippleButton } from './ui/ripple-button';

const packages = [
  {
    name: "Express Detail",
    price: "$89",
    duration: "1-2 hours",
    features: [
      "Exterior hand wash",
      "Wheel & tire cleaning",
      "Interior vacuum",
      "Window cleaning",
      "Dashboard wipe down"
    ],
    popular: false
  },
  {
    name: "Premium Detail",
    price: "$189",
    duration: "3-4 hours",
    features: [
      "Everything in Express",
      "Clay bar treatment",
      "Machine polish",
      "Leather conditioning",
      "Engine bay cleaning",
      "Headlight restoration"
    ],
    popular: true
  },
  {
    name: "Ultimate Detail",
    price: "$349",
    duration: "6-8 hours",
    features: [
      "Everything in Premium",
      "Ceramic coating application",
      "Paint correction",
      "Deep interior shampooing",
      "Odor elimination treatment",
      "6-month protection guarantee"
    ],
    popular: false
  }
];

export function Pricing() {
  const scrollToBooking = () => {
    const bookingSection = document.getElementById('booking');
    if (bookingSection) {
      bookingSection.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section id="pricing" className="relative py-24 px-4 bg-[#f8f8f8]">
      <div className="max-w-7xl mx-auto">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl text-[#10150f] mb-4">
            Transparent Pricing
          </h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Choose the package that fits your needs. All prices include materials and labor.
          </p>
        </motion.div>

        {/* Pricing Grid - Responsive stacking */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8 max-w-6xl mx-auto">
          {packages.map((pkg, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className={`relative rounded-2xl p-6 md:p-8 border-2 ${
                pkg.popular 
                  ? 'bg-gradient-to-br from-[#1a3a52] to-[#0f2540] border-[#1a3a52] shadow-2xl' 
                  : 'bg-white border-gray-200'
              }`}
            >
              {/* Popular Badge */}
              {pkg.popular && (
                <div className="absolute -top-4 left-1/2 -translate-x-1/2">
                  <div className="bg-[#8cc0d6] text-[#10150f] px-4 py-1 rounded-full text-sm shadow-lg">
                    Most Popular
                  </div>
                </div>
              )}

              {/* Package Name */}
              <h3 className={`text-xl md:text-2xl mb-2 ${pkg.popular ? 'text-white' : 'text-[#10150f]'}`}>
                {pkg.name}
              </h3>

              {/* Duration */}
              <p className={`text-sm mb-4 md:mb-6 ${pkg.popular ? 'text-[#8cc0d6]' : 'text-gray-500'}`}>{pkg.duration}</p>

              {/* Price */}
              <div className="mb-6 md:mb-8">
                <span className={`text-4xl md:text-5xl ${pkg.popular ? 'text-white' : 'text-[#10150f]'}`}>{pkg.price}</span>
              </div>

              {/* Features */}
              <ul className="space-y-3 md:space-y-4 mb-6 md:mb-8">
                {pkg.features.map((feature, idx) => (
                  <li key={idx} className="flex items-start gap-3 group/item">
                    <Check className={`w-5 h-5 flex-shrink-0 mt-0.5 transition-transform duration-300 group-hover/item:rotate-[5deg] ${pkg.popular ? 'text-[#8cc0d6]' : 'text-[#8cc0d6]'}`} />
                    <span className={`text-sm md:text-base ${pkg.popular ? 'text-gray-100' : 'text-gray-700'}`}>{feature}</span>
                  </li>
                ))}
              </ul>

              {/* CTA Button - Larger on mobile */}
              <RippleButton
                onClick={scrollToBooking}
                className={`w-full py-4 md:py-3 rounded-lg text-base md:text-sm transition-colors ${
                  pkg.popular
                    ? 'bg-[#8cc0d6] text-[#10150f] hover:bg-[#7ab5cc]'
                    : 'bg-[#f8f8f8] text-[#10150f] hover:bg-gray-200 border border-gray-300'
                }`}
              >
                Book Now
              </RippleButton>
            </motion.div>
          ))}
        </div>

        {/* Additional Info */}
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.4 }}
          className="text-center mt-12 text-gray-600"
        >
          <p>Prices may vary based on vehicle size and condition. Call for custom quotes.</p>
        </motion.div>
      </div>
    </section>
  );
}
