# Tailwind CSS Configuration Guide - Cruzn Clean

## Overview

This project uses **Tailwind CSS v4** with TypeScript for a fully type-safe styling experience. The configuration is optimized for the Cruzn Clean car detailing website with custom brand colors, animations, and utilities.

## Table of Contents

1. [Brand Colors](#brand-colors)
2. [Typography](#typography)
3. [Custom Utilities](#custom-utilities)
4. [Animations](#animations)
5. [Components](#components)
6. [Usage Examples](#usage-examples)

---

## Brand Colors

### Primary Colors

```typescript
// Deep Red - Primary CTA color
deepRed: '#56070f'

// Brand Black - Headers and dark sections
brandBlack: '#10150f'

// Water Blue - Interactive elements and highlights
waterBlue: '#8cc0d6'

// Neutral Gray - Backgrounds
neutralGray: '#f8f8f8'

// Premium Blue - Premium package branding
premiumBlue: '#1a3a52'
premiumDark: '#0f2540'
```

### Usage

```tsx
// Direct color classes
<div className="bg-deepRed text-white" />
<button className="bg-waterBlue hover:bg-waterBlue-600" />

// Using utility functions
import { brandColors } from '@/lib/tailwind-utils';
<div className={brandColors.deepRed.bg} />
```

### Color Scales

Each brand color has a full scale from 50-950:

```tsx
<div className="bg-deepRed-50" />    // Lightest
<div className="bg-deepRed-500" />   // Medium
<div className="bg-deepRed-950" />   // Darkest (default)
```

---

## Typography

### Font Families

```css
/* Headings */
font-heading: Manrope, system-ui, sans-serif

/* Body text */
font-body: Outfit, system-ui, sans-serif
```

### Responsive Text Sizes

```tsx
// Hero text - Automatically scales
<h1 className="text-hero">Premium Auto Detailing</h1>

// Display text
<h2 className="text-display">Our Services</h2>

// Heading text
<h3 className="text-heading">Before & After</h3>
```

### Typography Utilities

```typescript
import { typography } from '@/lib/tailwind-utils';

<h1 className={typography.h1}>Large Heading</h1>
<h2 className={typography.h2}>Medium Heading</h2>
<p className={typography.body}>Body text</p>
```

---

## Custom Utilities

### Glass Morphism

```tsx
// Standard glass effect
<div className="glass" />

// Dark glass
<div className="glass-dark" />

// Light glass
<div className="glass-light" />

// Using utility
import { glass } from '@/lib/tailwind-utils';
<div className={glass.dark} />
```

### Text Gradients

```tsx
// Blue gradient text
<h1 className="text-gradient-blue">Premium Service</h1>

// Red gradient text
<h1 className="text-gradient-red">Special Offer</h1>
```

### Scrollbar Styles

```tsx
// Hide scrollbar
<div className="scrollbar-hide overflow-x-auto" />

// Thin custom scrollbar
<div className="scrollbar-thin overflow-y-auto" />
```

### Shadows

```tsx
// Soft shadow
<div className="shadow-soft" />

// Glow effects
<div className="shadow-glow-blue" />
<div className="shadow-glow-red" />

// Glass shadow
<div className="shadow-glass" />

// Float shadow
<div className="shadow-float" />
```

---

## Animations

### Available Animations

#### Fade & Slide
```tsx
<div className="animate-fadeIn" />
<div className="animate-fadeUp" />
<div className="animate-fadeDown" />
<div className="animate-slideInLeft" />
<div className="animate-slideInRight" />
```

#### Effects
```tsx
<div className="animate-float" />        // Floating motion
<div className="animate-glow" />         // Pulsing glow
<div className="animate-shimmer" />      // Shimmer effect
<div className="animate-ripple" />       // Ripple on click
<div className="animate-bubble" />       // Bubble effect
<div className="animate-pulse" />        // Pulse
<div className="animate-pulse-slow" />   // Slow pulse
```

#### Spins & Rotations
```tsx
<div className="animate-spin" />         // Standard spin
<div className="animate-spin-slow" />    // Slow spin
<div className="animate-spin-slower" />  // Very slow spin
<div className="animate-wiggle" />       // Wiggle effect
```

#### Scale
```tsx
<div className="animate-scaleIn" />      // Scale in
<div className="animate-ping" />         // Ping effect
<div className="animate-bounce-slow" />  // Slow bounce
```

### Using Animation Utilities

```typescript
import { animations } from '@/lib/tailwind-utils';

<div className={animations.fadeUp} />
<div className={animations.float} />
```

---

## Components

### Buttons

```tsx
// Primary button
<button className="btn-primary">
  Book Now
</button>

// Secondary button
<button className="btn-secondary">
  Learn More
</button>

// Using variants
import { buttonVariants } from '@/lib/tailwind-utils';

<button className={buttonVariants.primary}>Primary</button>
<button className={buttonVariants.secondary}>Secondary</button>
<button className={buttonVariants.outline}>Outline</button>
<button className={buttonVariants.ghost}>Ghost</button>
```

### Cards

```tsx
// Glass card
<div className="card-glass">
  <h3>Premium Detail</h3>
  <p>Ultimate protection</p>
</div>

// Using variants
import { cardVariants } from '@/lib/tailwind-utils';

<div className={cardVariants.glass}>Glass Card</div>
<div className={cardVariants.default}>Default Card</div>
<div className={cardVariants.bordered}>Bordered Card</div>
```

---

## Usage Examples

### Hero Section

```tsx
import { cn, typography, animations, brandColors } from '@/lib/tailwind-utils';

function Hero() {
  return (
    <section className="relative min-h-screen bg-brandBlack">
      <div className="glass-dark p-8">
        <h1 className={cn(typography.hero, animations.fadeUp, 'text-white')}>
          Premium Auto Detailing,
          <span className="text-waterBlue"> Done Right</span>
        </h1>
        
        <button className="btn-primary animate-shimmer">
          Book Your Detail
        </button>
      </div>
    </section>
  );
}
```

### Feature Card

```tsx
import { cn, cardVariants, shadows, animations } from '@/lib/tailwind-utils';

function FeatureCard({ icon: Icon, title, description }) {
  return (
    <div className={cn(
      cardVariants.glass,
      shadows.soft,
      animations.fadeUp,
      'group hover:shadow-glow-blue'
    )}>
      <div className="bg-waterBlue/20 rounded-full p-4 mb-4">
        <Icon className="w-6 h-6 text-waterBlue group-hover:rotate-[5deg] transition-transform" />
      </div>
      <h4 className="font-heading text-white mb-2">{title}</h4>
      <p className="font-body text-gray-400">{description}</p>
    </div>
  );
}
```

### Responsive Grid

```tsx
import { grids, containers } from '@/lib/tailwind-utils';

function Services() {
  return (
    <section className={containers.default}>
      <div className={grids.threeCol}>
        {services.map(service => (
          <ServiceCard key={service.id} {...service} />
        ))}
      </div>
    </section>
  );
}
```

### Combining Utilities

```tsx
import { cn } from '@/lib/tailwind-utils';

// Merge multiple utility classes
const className = cn(
  'px-4 py-2',              // Base spacing
  'bg-deepRed',             // Background
  'text-white',             // Text color
  'rounded-lg',             // Border radius
  'shadow-soft',            // Shadow
  'hover:shadow-glow-red',  // Hover effect
  'transition-all',         // Smooth transitions
  'animate-fadeUp',         // Animation
  isActive && 'ring-2 ring-waterBlue' // Conditional
);
```

---

## Responsive Design

### Breakpoints

```typescript
sm: 640px   // Mobile landscape
md: 768px   // Tablet
lg: 1024px  // Desktop
xl: 1280px  // Large desktop
2xl: 1536px // Extra large
```

### Usage

```tsx
<div className="
  text-base      // Mobile
  md:text-lg     // Tablet
  lg:text-xl     // Desktop
  xl:text-2xl    // Large desktop
">
  Responsive Text
</div>
```

---

## Best Practices

### 1. Use Utility Functions

```tsx
// ✅ Good - Type-safe and maintainable
import { cn, buttonVariants } from '@/lib/tailwind-utils';
<button className={cn(buttonVariants.primary, className)} />

// ❌ Bad - String concatenation
<button className={'btn-primary ' + className} />
```

### 2. Component Composition

```tsx
// ✅ Good - Reusable component
function Button({ variant = 'primary', children, className, ...props }) {
  return (
    <button 
      className={cn(buttonVariants[variant], className)}
      {...props}
    >
      {children}
    </button>
  );
}
```

### 3. Consistent Spacing

```tsx
// ✅ Good - Use container utilities
import { containers } from '@/lib/tailwind-utils';
<section className={containers.default}>

// ❌ Bad - Hardcoded spacing
<section className="max-w-7xl mx-auto px-4">
```

### 4. Animation Performance

```tsx
// ✅ Good - Hardware accelerated
<div className="transform transition-transform hover:scale-105" />

// ❌ Bad - Non-hardware accelerated
<div className="transition-all hover:scale-105" />
```

---

## TypeScript Integration

### Type-Safe Classes

```typescript
import type { BrandColor, AnimationVariant } from '@/types/tailwind';

function Component({ color }: { color: BrandColor }) {
  return <div className={`bg-${color}`} />;
}
```

### Class Name Utility

```typescript
import { cn } from '@/lib/tailwind-utils';
import type { ClassNameValue } from '@/types/tailwind';

function mergeclasses(...classes: ClassNameValue[]) {
  return cn(...classes);
}
```

---

## Debugging

### View Applied Classes

```tsx
// Add data attribute to see merged classes
<div data-classes={className} className={className} />
```

### Tailwind Intellisense

Install the official VS Code extension:
- **Tailwind CSS IntelliSense** by Tailwind Labs

Add to `.vscode/settings.json`:
```json
{
  "tailwindCSS.experimental.classRegex": [
    ["cn\\(([^)]*)\\)", "(?:'|\"|`)([^\"'`]*)(?:'|\"|`)"]
  ]
}
```

---

## Migration from v3 to v4

Key differences:
- Configuration uses `@theme inline` directive
- Enhanced TypeScript support
- Better performance with JIT compilation
- Native CSS variable support

---

## Additional Resources

- [Tailwind CSS Documentation](https://tailwindcss.com)
- [Tailwind v4 Beta Docs](https://tailwindcss.com/docs/v4-beta)
- [Motion (Framer Motion) Docs](https://motion.dev)

---

**Last Updated:** February 14, 2026
