import { createContext, useContext, useState, ReactNode } from 'react';

export interface CartItem {
  id: string;
  name: string;
  price: number;
  type: 'package' | 'service';
}

export interface Vehicle {
  id: string;
  name: string;
  make?: string;
  model?: string;
  year?: string;
  items: CartItem[];
}

interface CartContextType {
  vehicles: Vehicle[];
  activeVehicleId: string | null;
  addVehicle: (vehicle?: Partial<Vehicle>) => string;
  removeVehicle: (vehicleId: string) => void;
  updateVehicle: (vehicleId: string, updates: Partial<Vehicle>) => void;
  setActiveVehicle: (vehicleId: string) => void;
  addItemToVehicle: (vehicleId: string, item: CartItem) => void;
  removeItemFromVehicle: (vehicleId: string, itemId: string) => void;
  clearVehicle: (vehicleId: string) => void;
  getVehicleTotal: (vehicleId: string) => number;
  getTotalPrice: () => number;
  getTotalItems: () => number;
  
  // Vehicle Dock visibility
  isDockOpen: boolean;
  openDock: () => void;
  closeDock: () => void;
  toggleDock: () => void;
  
  // Legacy support for existing components
  items: CartItem[];
  addItem: (item: CartItem) => void;
  removeItem: (id: string) => void;
  clearCart: () => void;
  totalPrice: number;
  itemCount: number;
}

const CartContext = createContext<CartContextType | undefined>(undefined);

export function CartProvider({ children }: { children: ReactNode }) {
  const [vehicles, setVehicles] = useState<Vehicle[]>([
    {
      id: 'vehicle-1',
      name: 'Car 1',
      items: []
    }
  ]);
  const [activeVehicleId, setActiveVehicleId] = useState<string>('vehicle-1');
  const [isDockOpen, setIsDockOpen] = useState(false);

  const addVehicle = (vehicleData?: Partial<Vehicle>): string => {
    const newId = `vehicle-${Date.now()}`;
    const newVehicle: Vehicle = {
      id: newId,
      name: vehicleData?.name || `Car ${vehicles.length + 1}`,
      make: vehicleData?.make,
      model: vehicleData?.model,
      year: vehicleData?.year,
      items: vehicleData?.items || []
    };
    setVehicles(prev => [...prev, newVehicle]);
    setActiveVehicleId(newId);
    return newId;
  };

  const removeVehicle = (vehicleId: string) => {
    setVehicles(prev => {
      const filtered = prev.filter(v => v.id !== vehicleId);
      // Ensure at least one vehicle exists
      if (filtered.length === 0) {
        return [{
          id: 'vehicle-1',
          name: 'Car 1',
          items: []
        }];
      }
      return filtered;
    });
    
    // Update active vehicle if the removed one was active
    if (activeVehicleId === vehicleId) {
      setActiveVehicleId(vehicles.find(v => v.id !== vehicleId)?.id || 'vehicle-1');
    }
  };

  const updateVehicle = (vehicleId: string, updates: Partial<Vehicle>) => {
    setVehicles(prev => prev.map(v => 
      v.id === vehicleId ? { ...v, ...updates } : v
    ));
  };

  const setActiveVehicle = (vehicleId: string) => {
    setActiveVehicleId(vehicleId);
  };

  const addItemToVehicle = (vehicleId: string, item: CartItem) => {
    setVehicles(prev => prev.map(vehicle => {
      if (vehicle.id === vehicleId) {
        const exists = vehicle.items.find(i => i.id === item.id);
        if (exists) {
          return vehicle;
        }
        return {
          ...vehicle,
          items: [...vehicle.items, item]
        };
      }
      return vehicle;
    }));
  };

  const removeItemFromVehicle = (vehicleId: string, itemId: string) => {
    setVehicles(prev => prev.map(vehicle => {
      if (vehicle.id === vehicleId) {
        return {
          ...vehicle,
          items: vehicle.items.filter(item => item.id !== itemId)
        };
      }
      return vehicle;
    }));
  };

  const clearVehicle = (vehicleId: string) => {
    setVehicles(prev => prev.map(vehicle => {
      if (vehicle.id === vehicleId) {
        return { ...vehicle, items: [] };
      }
      return vehicle;
    }));
  };

  const getVehicleTotal = (vehicleId: string): number => {
    const vehicle = vehicles.find(v => v.id === vehicleId);
    return vehicle?.items.reduce((sum, item) => sum + item.price, 0) || 0;
  };

  const getTotalPrice = (): number => {
    return vehicles.reduce((total, vehicle) => 
      total + vehicle.items.reduce((sum, item) => sum + item.price, 0), 0
    );
  };

  const getTotalItems = (): number => {
    return vehicles.reduce((total, vehicle) => total + vehicle.items.length, 0);
  };

  // Legacy support - use active vehicle's items
  const activeVehicle = vehicles.find(v => v.id === activeVehicleId) || vehicles[0];
  const items = activeVehicle?.items || [];
  
  const addItem = (item: CartItem) => {
    if (activeVehicleId) {
      addItemToVehicle(activeVehicleId, item);
    }
  };

  const removeItem = (id: string) => {
    if (activeVehicleId) {
      removeItemFromVehicle(activeVehicleId, id);
    }
  };

  const clearCart = () => {
    if (activeVehicleId) {
      clearVehicle(activeVehicleId);
    }
  };

  const totalPrice = items.reduce((sum, item) => sum + item.price, 0);
  const itemCount = items.length;

  const openDock = () => setIsDockOpen(true);
  const closeDock = () => setIsDockOpen(false);
  const toggleDock = () => setIsDockOpen(prev => !prev);

  return (
    <CartContext.Provider value={{
      vehicles,
      activeVehicleId,
      addVehicle,
      removeVehicle,
      updateVehicle,
      setActiveVehicle,
      addItemToVehicle,
      removeItemFromVehicle,
      clearVehicle,
      getVehicleTotal,
      getTotalPrice,
      getTotalItems,
      isDockOpen,
      openDock,
      closeDock,
      toggleDock,
      items,
      addItem,
      removeItem,
      clearCart,
      totalPrice,
      itemCount
    }}>
      {children}
    </CartContext.Provider>
  );
}

export function useCart() {
  const context = useContext(CartContext);
  if (!context) {
    throw new Error('useCart must be used within CartProvider');
  }
  return context;
}
